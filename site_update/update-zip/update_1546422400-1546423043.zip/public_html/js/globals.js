function serialize(obj) {
    const str = [];
    for (let p in obj)
        if (obj.hasOwnProperty(p)) {
            str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
        }
    return str.join("&");
}

function sendAjax(method, url, callback, attributes, isForm) {
    showWaiter();
    ajaxDangerReload();
    // проверю, не является ли ссылка на арртибуты ссылкой на форму
    if (attributes && attributes instanceof jQuery && attributes.is('form')) {
        attributes = attributes.serialize();
    }
    else if (isForm) {
        attributes = $(attributes).serialize();
    }
    else {
        attributes = serialize(attributes);
    }
    if (method === 'get') {
        $.ajax({
            method: method,
            data: attributes,
            url: url
        }).done(function (e) {
            deleteWaiter();
            ajaxNormalReload();
            callback(e);
        }).fail(function (e) {// noinspection JSUnresolvedVariable
            ajaxNormalReload();
            deleteWaiter();
            if (e['responseJSON']) {// noinspection JSUnresolvedVariable
                makeInformer('danger', 'Системная ошибка', e.responseJSON['message']);
            } else {
                makeInformer('danger', 'Системная ошибка', 'Критическая ошибка. Сообщите мне о ней!');
            }
            //callback(false)
        });
    }
    else if (method === 'post') {
        $.ajax({
            data: attributes,
            method: method,
            url: url
        }).done(function (e) {
            deleteWaiter();
            normalReload();
            callback(e);
        }).fail(function (e) {// noinspection JSUnresolvedVariable
            deleteWaiter();
            normalReload();
            if (e['responseJSON']) {// noinspection JSUnresolvedVariable
                makeInformer('danger', 'Системная ошибка', e.responseJSON.message);
            } else {
                makeInformer('danger', 'Системная ошибка', 'Критическая ошибка. Сообщите мне о ней!');
            }
            //callback(false)
        });
    }
}

function sendSilentAjax(method, url, callback, attributes, isForm) {
    // проверю, не является ли ссылка на арртибуты ссылкой на форму
    if (attributes && attributes instanceof jQuery && attributes.is('form')) {
        attributes = attributes.serialize();
    }
    else if (isForm) {
        attributes = $(attributes).serialize();
    }
    else {
        attributes = serialize(attributes);
    }
    if (method === 'get') {
        $.ajax({
            method: method,
            data: attributes,
            url: url
        }).done(function (e) {
            callback(e);
        }).fail(function (e) {// noinspection JSUnresolvedVariable
            if (e.responseJSON) {// noinspection JSUnresolvedVariable
                makeInformer('danger', 'Системная ошибка', e.responseJSON['message']);
            } else {
                makeInformer('danger', 'Системная ошибка', 'Критическая ошибка. Сообщите мне о ней!');
            }
            callback(false)
        });
    }
    else if (method === 'post') {
        $.ajax({
            data: attributes,
            method: method,
            url: url
        }).done(function (e) {
            callback(e);
        }).fail(function (e) {// noinspection JSUnresolvedVariable
            if (e.responseJSON) {// noinspection JSUnresolvedVariable
                makeInformer('danger', 'Системная ошибка', e.responseJSON.message);
            } else {
                makeInformer('danger', 'Системная ошибка', 'Критическая ошибка. Сообщите мне о ней!');
            }
            callback(false)
        });
    }
}

// ========================================================== ИНФОРМЕР
// СОЗДАЮ ИНФОРМЕР
function makeInformer(type, header, body) {
    if (!body)
        body = '';
    const container = $('div#alertsContentDiv');
    const informer = $('<div class="alert-wrapper"><div class="alert alert-' + type + ' alert-dismissable my-alert"><div class="panel panel-' + type + '"><div class="panel-heading">' + header + '<button type="button" class="close">&times;</button></div><div class="panel-body">' + body + '</div></div></div></div>');
    informer.find('button.close').on('click.hide', function (e) {
        e.preventDefault();
        closeAlert(informer)
    });
    container.append(informer);
    showAlert(informer)
}

// ПОКАЗЫВАЮ ИНФОРМЕР
function showAlert(alertDiv) {
    // считаю расстояние от верха страницы до места, где располагается информер
    const topShift = alertDiv[0].offsetTop;
    const elemHeight = alertDiv[0].offsetHeight;
    let shift = topShift + elemHeight;
    alertDiv.css({'top': -shift + 'px', 'opacity': '0.1'});
    // анимирую появление информера
    alertDiv.animate({
        top: 0,
        opacity: 1
    }, 500, function () {
        // запускаю таймер самоуничтожения через 5 секунд
        setTimeout(function () {
            closeAlert(alertDiv)
        }, 5000);
    });

}

// СКРЫВАЮ ИНФОРМЕР
function closeAlert(alertDiv) {
    const elemWidth = alertDiv[0].offsetWidth;
    alertDiv.animate({
        left: elemWidth
    }, 500, function () {
        alertDiv.animate({
            height: 0,
            opacity: 0
        }, 300, function () {
            alertDiv.remove();
        });
    });
}

$(function () {
    checkSoftwareUpdates();
    checkUndendedMessanges();
    //checkSystemFixes();
});

function checkSoftwareUpdates() {
    check();
    setInterval(function () {
        check()
    }, 60000);
}

function checkUndendedMessanges() {
    checkMessages();
    setInterval(function () {
        checkMessages()
    }, 60000);
}

function checkMessages() {
    sendSilentAjax('get', '/notifications/check-unsended', handleUnsanded);
}

function handleUnsanded(e) {
    if (e['status'] === 1) {
        makeInformer('info', 'Сообщения', 'Найдены неотправленные сообщения. Их нужно будет отправить вручную, когда появится подключение к интернету');
        let navbar = $('ul#w1');
        // noinspection JSValidateTypes
        if (navbar.children('li#unsendedMessangesButton').length === 0) {
            navbar.prepend('<li id="unsendedMessangesButton"><button id="sendMessavesButton" type="button" class="btn  btn-default btn-lg" data-toggle="tooltip" data-placement="bottom" title="Найдены неотправленные сообщения. Нажмите, чтобы попытаться отправить их заново."><span class="glyphicon glyphicon-bullhorn"></span></button></li>');
            $('button#sendMessavesButton').tooltip().on('click.send', function () {
                sendAjax('post', '/notify/resend', callback);
            });

            function callback(data) {
                if (data === '0') {
                    makeInformer('success', 'Успешно', 'Все сообщения успешно отправлены адресатам');
                }
                else {
                    makeInformer('warning', 'Неудача', 'Не удалось отправить сообщения. Возможно, вы используете нестабильное подключение к интернету. Попробуйте ещё раз позднее.');
                }
                checkMessages();
            }
        }
    }
    else if (e['status'] && e['status'] === 0) {
        // обновлений не найдено, убираю значок обновления, если он есть
        $('li#unsendedMessangesButton').remove();
    }
}

// function checkSystemFixes() {
//     sendAjax('post', '/check-fix', answer, []);
//
//     function answer(e) {
//     }
// }

function check() {
    sendSilentAjax('get', '/updates/check', answer);
}

function answer(e) {
    let navbar = $('ul#w1');
    if (e['status'] === 1) {
        makeInformer('info', 'Обновления', 'Найдены обновления ПО. Вы можете установить их в разделе "Управление"');
        // noinspection JSValidateTypes
        if (navbar.children('li#updatesButton').length === 0) {
            navbar.prepend('<li id="updatesButton"><a id="installUpdatesButton" href="https://dev.com/management/index" type="button" class="btn  btn-default btn-lg" data-toggle="tooltip" data-placement="bottom" title="Найдены обновнения ПО. Нажмите, чтобы установить."><span class="glyphicon glyphicon-cloud-download"></span></a></li>');
            $('button#installUpdatesButton').tooltip();
        }
    }
    else if (e['status'] && e['status'] === 0) {
        // обновлений не найдено, убираю значок обновления, если он есть
        $('li#updatesButton').remove();
    }
    else if (e['status'] === 10) {
        // noinspection JSValidateTypes
        if (navbar.children('li#no-connection').length === 0) {
            navbar.prepend('<li id="no-connection"><span id="no-connection-indicator" class="btn  btn-danger btn-lg glyphicon glyphicon-ban-circle" data-toggle="tooltip" data-placement="bottom" title="Отсутствует подключение к интернету. Обновления и отправка почты недоступны."></span></li>');
            $('span#no-connection-indicator').tooltip();
        }
    }
}

// Функция вызова пустого модального окна
function makeModal(header, text) {
    if (!text)
        text = '';
    let modal = $('<div class="modal fade mode-choose"><div class="modal-dialog  modal-lg"><div class="modal-content"><div class="modal-header">' + header + '</div><div class="modal-body">' + text + '</div><div class="modal-footer"><button class="btn btn-danger"  data-dismiss="modal" type="button" id="cancelActionButton">Отмена</button></div></div></div>');
    $('body').append(modal);
    dangerReload();
    modal.modal({
        keyboard: true,
        backdrop: 'static',
        show: true
    });
    modal.on('hidden.bs.modal', function () {
        normalReload();
        modal.remove();
        $('div.wrap div.container, div.wrap nav').removeClass('blured');
    });
    $('div.wrap div.container, div.wrap nav').addClass('blured');
    return modal;
}

function loadForm(url, modal, postUrl) {
    sendAjax('get', url, appendForm);

    function appendForm(form) {
        let ready = false;
        const frm = $(form.data);
        frm.find('button.popover-btn').popover({trigger: 'focus'});
        modal.find('div.modal-body').append(frm);
        frm.on('afterValidate', function (event, fields, errors) {
            ready = !errors.length;
        });
        frm.on('submit.test', function (e) {
            e.preventDefault();
            if (ready) {
                // отправлю форму
                // заблокирую кнопку отправки, чтобы невозможно было отправить несколько раз
                frm.find('button#addSubmit').addClass('disabled').prop('disabled', true);
                let i = 0;
                let loadedForm;
                while (frm[i]) {
                    if (frm[i].nodeName === "FORM") {
                        loadedForm = frm[i];
                        break;
                    }
                    i++;
                }
                sendAjax('post', postUrl, answerMe, loadedForm, true);

                function answerMe(e) {
                    normalReload();
                    if (e && e.status === 1) {
                        // успешно добавлено, перезагружаю страницу
                        location.reload();
                    }
                    else if (e && e.status === 0) {
                        // получаю список ошибок, вывожу его
                        let errorsList = '';
                        for (let i in e['errors']) {
                            if (e['errors'].hasOwnProperty(i))
                                errorsList += e['errors'][i] + '\n';
                        }
                        makeInformer('danger', 'Сохранение не удалось.', errorsList);
                        modal.hide();
                    }
                }
            }
        });
    }
}

function handleErrors(errors) {
    let content = '';
    for (let i in errors) {
        if (errors.hasOwnProperty(i))
            content += errors[i][0]
    }
    return content;
}

function makeNewWindow(url, link, closeCallback) {
    if (link)
        link.close();
    link = window.open(url, '_blank');
    link.focus();
    $(link).on('load', function () {
        $(link).on('unload.call', function () {
            if (closeCallback)
                closeCallback();
        })
    });
    return link;
}

function disableElement(elem, newText) {
    elem.addClass('disabled').prop('disabled', true);
    if (newText) {
        elem.attr('data-realname', elem.text()).text(newText);
    }
}

function enableElement(elem, newText) {
    elem.removeClass('disabled').prop('disabled', false);
    if (newText)
        elem.text(newText);
    else if (elem.attr('data-realname'))
        elem.text(elem.attr('data-realname'));
}

function toRubles(summ) {
    if (typeof(summ) === 'string')
        summ = summ.replace(',', '.');
    summ = parseFloat(summ);
    return parseFloat(summ.toFixed(2));
}

function ajaxDangerReload() {
    $(window).on('beforeunload.ajax', function () {
        return "Необходимо заполнить все поля на странице!";
    });
}

function ajaxNormalReload() {
    $(window).off('beforeunload.ajax');
}

function dangerReload() {
    $(window).on('beforeunload.message', function () {
        return "Необходимо заполнить все поля на странице!";
    });
}

function normalReload() {
    $(window).off('beforeunload');
}

function showWaiter() {
    let shader = $('<div class="shader"></div>');
    $('body').append(shader);
    $('div.wrap, div.flyingSumm, div.modal').addClass('blured');
    shader.showLoading();
}

function deleteWaiter() {
    $('div.wrap, div.flyingSumm, div.modal').removeClass('blured');
    let shader = $('div.shader');
    if (shader.length > 0)
        shader.hideLoading().remove();
}

function handleCashInput(input) {
    const re = /^\d+[,.]?\d{0,2}$/;
    input.on('input.int', function () {
        if ($(this).val().match(re)) {
            $(this).addClass('ready').removeClass('failed');
            $(this).parent().addClass('has-success').removeClass('has-error');
        }
        else {
            $(this).removeClass('ready').addClass('failed');
            $(this).parent().removeClass('has-success').addClass('has-error');
        }
    });
    input.on('blur.int', function () {
        if ($(this).val().match(re)) {
            makeInputRight($(this));
        }
        else {
            makeInputWrong($(this));
        }
    });
}

function isSumm(summ) {
    const re = /^\d+[,.]?\d{0,2}$/;
    if (summ.match(re)) {
        return parseFloat(summ.replace(',', '.'));
    }
    return false;
}

function makeInputWrong(input) {
    input.removeClass('ready').addClass('failed');
    input.parent().removeClass('has-success').addClass('has-error');
    input.focus();

}

function makeInputRight(input) {
    input.addClass('ready').removeClass('failed');
    input.parent().addClass('has-success').removeClass('has-error');
}

function getLastDayOfMonth(y, m) {
    if (m === 1) {
        return y % 4 || (!(y % 100) && y % 400) ? 28 : 29;
    }
    return m === 3 || m === 5 || m === 8 || m === 10 ? 30 : 31;
}

function handlePowerInputs(modal, squareInput) {
    // Обработаю поля ввода целевых платежей
    // найду количество целевых платежей
    let powerRadios = modal.find('input.target-radio');
    let powerInputs = modal.find('input.target-input');
    const re = /^\s*\d+[,.]?\d{0,2}\s*$/;
    powerInputs.on('blur.testCost', function () {
        let par = $(this).parents('div.form-group').eq(0);
        let helpBlock = $(this).parents('div.text-input-parent').find('div.help-block');
        helpBlock.text('');
        let summ = toRubles(par.find('b.summ').text());
        let val = toRubles($(this).val());
        if (val === 0) {
            $(this).focus();
            makeInformer('info', 'Информация', 'Значение платежа должно быть больше нуля');
            par.addClass('has-error').removeClass('has-success');
        }
        else if ($(this).val() === '') {
            $(this).focus();
            makeInformer('info', 'Информация', 'Введите сумму в рублях');
            par.addClass('has-error').removeClass('has-success');
        }
        else if (val >= summ) {
            $(this).focus();
            makeInformer('info', 'Информация', 'Сумма не может быть больше полной суммы платежа');
            par.addClass('has-error').removeClass('has-success');
        }
        else if ($(this).val().match(re)) {
            par.removeClass('has-error').addClass('has-success');
        }
        else {
            $(this).focus();
            par.addClass('has-error').removeClass('has-success');
            makeInformer('danger', 'Ошибка', 'Неверное число!');
            helpBlock.text("Это не в рублях!");
        }
    });
    let powerRadioNames = {};
    let c = 0;
    while (powerRadios[c]) {
        let year = $(powerRadios[c]).attr('data-year');
        powerRadioNames[year] = $(powerRadios[c]).attr('name');
        c++;
    }
    let powerRadiosParents = powerRadios.parent();
    powerRadiosParents.on('click.switch', function (e) {
        // сначала проверю, что заполнена площадь участка, она понадобится для расчёта суммы платежа
        let float = toRubles($(this).attr('data-float'));
        if (float > 0) {
            if (!squareInput.val()) {
                e.preventDefault();
                e.stopPropagation();
                makeInformer('info', 'Внимание', 'Для расчёта суммы платежа нужно ввести площадь участка');
                squareInput.focus();
            }
        }
    });
    powerRadios.on('change.switch', function () {
        let par = $(this).parents('div.form-group').eq(0);
        let myInput = par.find('input[type="text"]');
        let myInputHelp = myInput.parents('div.text-input-parent').find('div.help-block');
        let type = $(this).val();
        if (type === 'full') {
            myInputHelp.text('');
            let summ = par.find('b.summ');
            // год оплачен полностью, убираю параметр disabled, добавляю параметр readonly, выставляю полную сумму платежа
            myInput.prop('disabled', false).addClass('readonly').removeClass('disabled').prop('readonly', true).val(toRubles(summ.text()));
            par.removeClass('has-error').addClass('has-success');
        }
        else if (type === 'no-payed') {
            myInputHelp.text('');
            // год оплачен полностью, убираю параметр disabled, добавляю параметр readonly, выставляю полную сумму платежа
            myInput.prop('disabled', true).addClass('disabled').removeClass('readonly').prop('readonly', false).val(0);
            par.removeClass('has-error').addClass('has-success');
        }
        else if (type === 'partial') {
            // год оплачен полностью, убираю параметр disabled, добавляю параметр readonly, выставляю полную сумму платежа
            myInput.prop('disabled', false).removeClass('readonly disabled').prop('readonly', false).val('').focus();
            par.removeClass('has-error has-success');
        }
    });
    let targetSummContainers = modal.find('b.summ');
    squareInput.on('change.calculate', function () {
        let square = parseInt($(this).val());
        if (square > 0) {
            // пересчитаю сумму целевого платежа за год с учётом плавающей ставки
            targetSummContainers.each(function () {
                let float = toRubles($(this).attr('data-float'));
                if (float > 0) {
                    let fixed = toRubles($(this).attr('data-fixed'));
                    $(this).text(toRubles(fixed + float / 100 * square));
                }
            });
        }
    });
    modal.find('form').on('afterValidate', function (e) {
        // разберусь, что не так с полями целевых взносов
        if (!powerRadios.eq(0).prop('disabled')) {
            let powers = modal.find('input.target-radio:checked');
            if (powers.length !== powerRadioNames.length) {
                // если не заполнен какой-либо из периодов целевых плтежей- помечу его как незаполненный
                for (let i in powerRadioNames) {
                    // проверю, заполнен ли именно этот раздел
                    if (powerRadioNames.hasOwnProperty(i)) {
                        let filled = modal.find('input.target-radio[name="' + powerRadioNames[i] + '"]:checked');
                        if (filled.length === 0) {
                            // отмечаю как неверно заполненный
                            let firstUnfilled = modal.find('input.target-radio[name="' + powerRadioNames[i] + '"]').eq(0);
                            let par = firstUnfilled.parents('div.form-group').eq(0);
                            firstUnfilled.parents('div.col-lg-5').eq(0).find('div.help-block').text("Выберите один из вариантов");
                            par.addClass('has-error').removeClass('has-success');
                            e.preventDefault();
                        }
                        else {
                            // если выбрана частичная оплата- проверю правильность заполнения текстового поля
                            let firstFilled = modal.find('input.target-radio[name="' + powerRadioNames[i] + '"]:checked').eq(0);
                            let par = firstFilled.parents('div.form-group').eq(0);
                            if (firstFilled.val() === 'partial') {
                                // если поле не отмечено как успешно заполненное- помечаю как неуспешно заполненное
                                if (!par.hasClass('has-success')) {
                                    par.addClass('has-error');
                                    e.preventDefault();
                                }
                            }
                            else {
                                firstFilled.parents('div.col-lg-5').eq(0).find('div.help-block').text("");
                                par.removeClass('has-error').addClass('has-success');
                            }
                        }
                    }
                }
            }
        }
    });
}
function handleMembershipInput(input) {
    input.on('input.fill', function () {
        // если введённое значение совпадает с шаблоном ввода- отправлю запрос на проверку заполненности тарифов
        const re = /^\s*(\d{4})\W*([1-4])\s*$/;
        let found;
        if (found = input.val().match(re)) {
            sendAjax('get', '/check/membership/interval/' + found[1] + '-' + found[2], callback);

            function callback(e) {
                if (e.status === 1) {
                    // открою новое окно для заполнения тарифа
                    if (membershipFillWindow)
                        membershipFillWindow.close();
                    membershipFillWindow = window.open('fill/membership/' + found[1] + '-' + found[2], '_blank');
                    membershipFillWindow.focus();
                    $(membershipFillWindow).on('load.trigger', function () {
                        // при закрытии окна повторно отсылаю данные поля на проверку
                        $(membershipFillWindow).on('unload.test', function () {
                            input.trigger('input');
                            input.trigger('change');
                        });
                    })
                }
                else if (e.status === 2) {
                    if (membershipFillWindow)
                        membershipFillWindow.close();
                }
            }
        }
    });
}