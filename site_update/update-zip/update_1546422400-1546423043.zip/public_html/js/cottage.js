const cottageNumber = location.pathname.split('/')[2];
$(function () {

    basementFunctional();
    additionalFunctions();
    individualTariff();
    $(window).on('beforeunload.closeChild', function () {
        if (tariffsFillWindow) {
            tariffsFillWindow.close();
        }
        if (invoiceWindow) {
            invoiceWindow.close();
        }
    })
});

function individualTariff() {
    let btn = $('button#indivTariffBtn');
    let additionalBtn = $('button#additionalIndivTariffBtn');
    let cancelBtn = $('button#indivTariffOffBtn');
    cancelBtn.on('click.off', function () {
        sendAjax('get', '/tariff/personal/disable/' + cottageNumber, callback);

        function callback(answer) {
            let modal = makeModal('Возвращение к обычному тарифу', answer);
            let frm = modal.find('form');
            // Обработаю поля ввода целевых платежей
            // найду количество целевых платежей
            let powerRadios = modal.find('input.target-radio');
            let powerInputs = modal.find('input.target-input');
            const re = /^\s*\d+[,.]?\d{0,2}\s*$/;
            powerInputs.on('blur.testCost', function () {
                let par = $(this).parents('div.form-group').eq(0);
                let helpBlock = $(this).parents('div.text-input-parent').find('div.help-block');
                helpBlock.text('');
                let summ = toRubles(par.find('b.summ').text());
                let val = toRubles($(this).val());
                if (val === 0) {
                    $(this).focus().removeClass('ready');
                    makeInformer('info', 'Информация', 'Значение платежа должно быть больше нуля');
                    par.addClass('has-error').removeClass('has-success');
                }
                else if ($(this).val() === '') {
                    $(this).focus().removeClass('ready');
                    makeInformer('info', 'Информация', 'Введите сумму в рублях');
                    par.addClass('has-error').removeClass('has-success');
                }
                else if (val >= summ) {
                    $(this).focus().removeClass('ready');
                    makeInformer('info', 'Информация', 'Сумма не может быть больше полной суммы платежа');
                    par.addClass('has-error').removeClass('has-success');
                }
                else if ($(this).val().match(re)) {
                    par.removeClass('has-error').addClass('has-success');
                    $(this).addClass('ready');
                }
                else {
                    $(this).focus().removeClass('ready');
                    par.addClass('has-error').removeClass('has-success');
                    makeInformer('danger', 'Ошибка', 'Неверное число!');
                    helpBlock.text("Это не в рублях!");
                }
            });
            let powerRadioNames = {};
            let c = 0;
            while (powerRadios[c]) {
                let year = $(powerRadios[c]).attr('data-year');
                powerRadioNames[year] = $(powerRadios[c]).attr('name');
                c++;
            }
            powerRadios.on('change.switch', function () {
                let par = $(this).parents('div.form-group').eq(0);
                let myInput = par.find('input[type="text"]');
                let myInputHelp = myInput.parents('div.text-input-parent').find('div.help-block');
                let type = $(this).val();
                if (type === 'full') {
                    myInputHelp.text('');
                    let summ = par.find('b.summ');
                    // год оплачен полностью, убираю параметр disabled, добавляю параметр readonly, выставляю полную сумму платежа
                    myInput.prop('disabled', false).addClass('readonly ready').removeClass('disabled').prop('readonly', true).val(toRubles(summ.text()));
                    par.removeClass('has-error').addClass('has-success');
                }
                else if (type === 'no-payed') {
                    myInputHelp.text('');
                    // год оплачен полностью, убираю параметр disabled, добавляю параметр readonly, выставляю полную сумму платежа
                    myInput.prop('disabled', true).addClass('disabled ready').removeClass('readonly').prop('readonly', false).val(0);
                    par.removeClass('has-error').addClass('has-success');
                }
                else if (type === 'partial') {
                    // год оплачен полностью, убираю параметр disabled, добавляю параметр readonly, выставляю полную сумму платежа
                    myInput.prop('disabled', false).removeClass('readonly disabled ready').prop('readonly', false).val('').focus();
                    par.removeClass('has-error has-success');
                }
            });
            let sended = false;
            frm.on('submit', function (e) {
                e.preventDefault();
                if (powerInputs.not('.ready').length > 0) {
                    makeInformer('info', 'Рано', 'Сначала заполните тарифы!.');
                }
                else {
                    if (!sended) {
                        // отправлю данные формы на обработку
                        sendAjax('post', '/tariff/personal/disable/' + cottageNumber, callback, frm, true);

                        function callback(answer) {
                            if (answer['status'] === 1) {
                                location.reload();
                            }
                            else {
                                sended = false;
                            }
                        }

                        sended = true;
                    }
                }
            })
        }
    });
    btn.on('click', function () {
        let modal = makeModal('Настройка индивидуального тарифа');
        sendAjax('get', '/tariff/personal/enable/' + cottageNumber, callback);

        function callback(answer) {
            modal.find('div.modal-body').html(answer);
            let frm = modal.find('form');
            let inputs = frm.find('input[type="text"].required');
            handleCashInput(inputs);
            inputs.eq(0).focus();
            const copyDataBtn = modal.find('button.copy-data');
            copyDataBtn.on('click.copy', function () {
                // заполню поля месяца ниже значениями из полей этого периода
                let par = $(this).parents('div.form-group');
                let next = par.nextAll('div.form-group').eq(0);
                if (next && par.hasClass('power-group') && next.hasClass('power-group')) {
                    next.find('input.power-limit').val(par.find('input.power-limit').val());
                    next.find('input.power-cost').val(par.find('input.power-cost').val());
                    next.find('input.power-overcost').val(par.find('input.power-overcost').val());
                    next.find('input').trigger('input');
                    next.find('input').trigger('blur');
                }
                else if (next && par.hasClass('membership-group') && next.hasClass('membership-group')) {
                    next.find('input.mem-fixed').val(par.find('input.mem-fixed').val());
                    next.find('input.mem-float').val(par.find('input.mem-float').val());
                    next.find('input').trigger('input');
                    next.find('input').trigger('blur');
                }
            });
            let sended = false;
            frm.on('submit', function (e) {
                e.preventDefault();
                if (inputs.filter('.failed').length > 0) {
                    makeInformer('info', 'Рано', 'Обнаружено неверно заполненное поле!.');
                }
                else if (inputs.not('.ready').length > 0) {
                    makeInformer('info', 'Рано', 'Сначала заполните все поля!.');
                }
                else {
                    if (!sended) {
                        // отправлю данные формы на обработку
                        sendAjax('post', '/tariff/personal/enable/' + cottageNumber, callback, frm, true);

                        function callback(answer) {
                            if (answer['status'] === 1) {
                                location.reload();
                            }
                            else {
                                sended = false;
                            }
                        }

                        sended = true;
                    }
                }
            })
        }
    });
    additionalBtn.on('click', function () {
        let modal = makeModal('Настройка индивидуального тарифа');
        sendAjax('get', '/tariff/personal/enable/additional/' + cottageNumber, callback);

        function callback(answer) {
            modal.find('div.modal-body').html(answer);
            let frm = modal.find('form');
            let inputs = frm.find('input[type="text"].required');
            handleCashInput(inputs);
            inputs.eq(0).focus();
            const copyDataBtn = modal.find('button.copy-data');
            copyDataBtn.on('click.copy', function () {
                // заполню поля месяца ниже значениями из полей этого периода
                let par = $(this).parents('div.form-group');
                let next = par.nextAll('div.form-group').eq(0);
                if (next && par.hasClass('power-group') && next.hasClass('power-group')) {
                    next.find('input.power-limit').val(par.find('input.power-limit').val());
                    next.find('input.power-cost').val(par.find('input.power-cost').val());
                    next.find('input.power-overcost').val(par.find('input.power-overcost').val());
                    next.find('input').trigger('input');
                    next.find('input').trigger('blur');
                }
                else if (next && par.hasClass('membership-group') && next.hasClass('membership-group')) {
                    next.find('input.mem-fixed').val(par.find('input.mem-fixed').val());
                    next.find('input.mem-float').val(par.find('input.mem-float').val());
                    next.find('input').trigger('input');
                    next.find('input').trigger('blur');
                }
            });
            let sended = false;
            frm.on('submit', function (e) {
                e.preventDefault();
                if (inputs.filter('.failed').length > 0) {
                    makeInformer('info', 'Рано', 'Обнаружено неверно заполненное поле!.');
                }
                else if (inputs.not('.ready').length > 0) {
                    makeInformer('info', 'Рано', 'Сначала заполните все поля!.');
                }
                else {
                    if (!sended) {
                        // отправлю данные формы на обработку
                        sendAjax('post', '/tariff/personal/enable/additional/' + cottageNumber, callback, frm, true);

                        function callback(answer) {
                            if (answer['status'] === 1) {
                                location.reload();
                            }
                            else {
                                sended = false;
                            }
                        }

                        sended = true;
                    }
                }
            })
        }
    });
    // просмотр данных тарифа
    let showDataBtn = $('button#showPersonalTariff');
    showDataBtn.on('click.show', function () {
        sendAjax('get', '/show/personal-tariff/' + cottageNumber, callback);

        function callback(answer) {
            makeModal('Данные о тарифе', answer);
        }
    });
    // изменение данных тарифа
    let changeDataBtn = $('button#editPersonalTariff');
    changeDataBtn.on('click.change', function () {
        sendAjax('get', '/tariff/personal/change/' + cottageNumber, callback);

        function callback(answer) {
            if (answer['status'] && answer['status'] === 2) {
                makeInformer("warning", "Невозможно", "Обнаружен выставленный но неоплаченный счёт. Оплатите или отмените его перед изменением данных");
                return;
            }
            let modal = makeModal('Изменение тарифа', answer);
            let frm = modal.find('form');
            let inputs = frm.find('input[type="text"].required');
            handleCashInput(inputs);
            inputs.eq(0).focus();
            const copyDataBtn = modal.find('button.copy-data');
            copyDataBtn.on('click.copy', function () {
                // заполню поля месяца ниже значениями из полей этого периода
                let par = $(this).parents('div.form-group');
                let next = par.nextAll('div.form-group').eq(0);
                if (next && par.hasClass('power-group') && next.hasClass('power-group')) {
                    next.find('input.power-limit').val(par.find('input.power-limit').val());
                    next.find('input.power-cost').val(par.find('input.power-cost').val());
                    next.find('input.power-overcost').val(par.find('input.power-overcost').val());
                    next.find('input').trigger('input');
                    next.find('input').trigger('blur');
                }
                else if (next && par.hasClass('membership-group') && next.hasClass('membership-group')) {
                    next.find('input.mem-fixed').val(par.find('input.mem-fixed').val());
                    next.find('input.mem-float').val(par.find('input.mem-float').val());
                    next.find('input').trigger('input');
                    next.find('input').trigger('blur');
                }
            });
            let sended = false;
            frm.on('submit', function (e) {
                e.preventDefault();
                if (inputs.filter('.failed').length > 0) {
                    makeInformer('info', 'Рано', 'Обнаружено неверно заполненное поле!.');
                }
                else if (inputs.not('.ready').length > 0) {
                    makeInformer('info', 'Рано', 'Сначала заполните все поля!.');
                }
                else {
                    if (!sended) {
                        // отправлю данные формы на обработку
                        sendAjax('post', '/tariff/personal/change/' + cottageNumber, callback, frm, true);

                        function callback(answer) {
                            if (answer['status'] === 1) {
                                location.reload();
                            }
                            else {
                                sended = false;
                            }
                        }

                        sended = true;
                    }
                }
            })
        }
    })
}

let tariffsFillWindow;
let invoiceWindow;

function remind(url) {
    sendAjax('post', url, notificationCallback);
}

function notificationCallback(answer) {
    // БЛОК ПРОВЕРКИ СТАТУСА ОТПРАВКИ АВТОМАТИЧЕСКОГО УВЕДОМЛЕНИЯ
    // if (answer['messageStatus']) {
    //     if (answer['messageStatus']['status'] === 2) {
    //         makeInformer('danger', 'Неуспешно', 'Нет подключения к интернету. Сообщение сохранено, вы сможете отправить его, когда подключение появится!');
    //     }
    //     else if (answer['messageStatus']['status'] === 1) {
    //         if (answer['messageStatus']['results']['to-owner']) {
    //             if (answer['messageStatus']['results']['to-owner'] === true)
    //                 makeInformer('success', 'Успешно', 'Письмо владельцу успешно отправлено!');
    //             else {
    //                 makeInformer('danger', 'Неуспешно', 'Письмо владельцу отправить не удалось!');
    //             }
    //         }
    //         if (answer['messageStatus']['results']['to-contacter']) {
    //             if (answer['messageStatus']['results']['to-contacter'] === true)
    //                 makeInformer('success', 'Успешно', 'Письмо контактному лицу успешно отправлено!');
    //             else {
    //                 makeInformer('danger', 'Неуспешно', 'Письмо контактному лицу отправить не удалось!');
    //             }
    //         }
    //     }
    // }
    // if (answer['status'] === 3) {
    //     makeInformer('warning', "Не вышло", "Проверьте подключение к интернету, отправка не удалась")
    // }
    // else if (answer['status'] === 4) {
    //     makeInformer('warning', "Не вышло", "Ни у владельца ни у контактного лица не указан адрес электронной почты")
    // }
}

function basementFunctional() {

    // отменю внесённые показания по электричеству
    let cBtn = $('button#cancelFillPower');
    cBtn.on('click.cancel', function () {
        sendAjax('post', '/power/cancel-previous/' + cottageNumber, pCallback);
    });
    // отменю внесённые показания по электричеству
    let caBtn = $('button#cancelFillAdditionalPower');
    caBtn.on('click.cancel', function () {
        sendAjax('post', '/power/cancel-previous/additional/' + cottageNumber, pCallback);
    });

    function pCallback(data) {
        if (data['status'] === 1) {
            cBtn.addClass('disabled').prop('disabled', true);
            makeInformer('success', 'Успешно', 'Сведения о потреблённой электроэнергии за предыдущий месяц успешно удалены')
        }
        else
            makeInformer('warning', 'Неудачно', 'Операция не удалась. Возможно, не заполнены покаания за месяц или месяц уже оплачен или есть неоплаченные счета по этому участку.')
    }
    // обработаю неоплаченный платёж при его наличии
    let payBtn = $('button#handleUnpayedBtn');
    payBtn.on('click.pay', function () {
        editBill($(this).attr('data-identificator'));
    });

    const createSingleButton = $('button#createSinglePayButton');
    createSingleButton.on('click.createSingle', function () {
        let url = "/payment/get-form/single/" + cottageNumber;
        sendAjax('get', url, callback);

        function callback(answer) {
            if (answer['status'] === 1) {
                let modal = makeModal('Создание разового платежа', answer['data']);
                let frm = modal.find('form');
                let ready = false;
                let validateInProcess = false;
                frm.on('submit', function (e) {
                    e.preventDefault();
                    if (!validateInProcess) {
                        if (ready) {
                            const url = '/payment/single/save';
                            sendAjax('post', url, callback, frm[0], true);

                            function callback(answer) {
                                if (answer['status'] === 1) {
                                    location.reload();
                                }
                                else {
                                    makeInformer('danger', 'Сохранение платежа', 'Сохранение почему-то не удалось');
                                }
                            }
                        }
                        else {
                            makeInformer('info', 'Сохранение платежа', 'Сначала заполните все необходимые поля.');
                        }
                    }
                });
                frm.on('beforeValidate', function () {
                    validateInProcess = true;
                });
                frm.on('beforeValidateAttribute', function () {
                    validateInProcess = true;
                });
                frm.on('afterValidate', function (event, fields, errors) {
                    validateInProcess = false;
                    ready = !errors.length;
                    if (errors.length > 0) {
                        makeInformer('danger', 'Ошибка', 'Не заполнены все необходимые поля или заполнены с ошибками. Проверьте введённые данные!');
                    }
                });
                frm.on('afterValidateAttribute', function (event, fields, errors) {
                    validateInProcess = false;
                    ready = !errors.length;
                });
            }
        }
    });

    const testTariffs = $('#tariff-no-filled');
    if (testTariffs.length === 1) {
        makeNewWindow('/tariffs/index', tariffsFillWindow, handle);

        function handle() {
            location.reload();
        }
    }
    const payButton = $('button#payForCottageButton');
    payButton.on('click.pay', function () {
        // загружу данные обо ВСЕХ платежах
        sendAjax('get', '/payment/get-form/complex/' + cottageNumber, callback);

        function callback(answer) {
            if (answer['status'] === 1) {
                let modal = makeModal('Создание счёта на оплату', answer['data']);
                let frm = modal.find('form');
                modal.find('.popovered').popover({'trigger': 'hover', 'html': true});
                $('body').append("<div class='flyingSumm'><p>Общая сумма задолженности: <b id='totalDebtSumm' class='text-danger'>0</b>&#8381;</p><p>К оплате: <b id='totalPaymentSumm' class='text-danger'>0</b>&#8381;</p><p class='hidden'>Скидка: <b id='discountSumm' class='text-danger'>0</b>&#8381;</p><p class='hidden'>Оплата с депозита: <b id='fromDepositSumm' class='text-danger'>0</b>&#8381;</p><p class='hidden'>Итого: <b id='recalculatedSumm' class='text-danger'>0</b>&#8381;</p><p>Останется оплатить: <b id='leftPaymentSumm' class='text-danger'>0</b>&#8381;</p><p><button class='btn btn-success' id='sendFormBtn'>Сформировать счёт</button></p></div>");
                const memberPeriods = $('input#complexpayment-membershipperiods');
                const memberAdditionalPeriods = $('input#complexpayment-additionalmembershipperiods');
                const powerPeriods = $('input#complexpayment-powerperiods');
                const additionalPowerPeriods = $('input#complexpayment-additionalpowerperiods');
                const countedSumm = $('input#complexpayment-countedsumm');
                modal.on('hidden.bs.modal', function () {
                    $('div.flyingSumm').remove();
                });
                let sendBtn = $('button#sendFormBtn');
                let totalDebt = $('b#totalDebtSumm');
                let totalPayment = $('b#totalPaymentSumm');
                let leftSumm = $('b#leftPaymentSumm');
                let globalSumm = toRubles($('span#paySumm').text());
                let discountSummInput = $('input#complexpayment-discount');
                let depositSummInput = $('input#complexpayment-fromdeposit');
                let discountSumm = $('b#discountSumm');
                let depositSumm = $('b#fromDepositSumm');
                let recalculatedSumm = $('b#recalculatedSumm');
                const useDiscountBtn = modal.find('button#useDiscountBtn');
                const discountInput = modal.find('input#complexpayment-discount');
                const discountReason = modal.find('textarea#discountReason');

                const useDepositBtn = modal.find('button#useDepositBtn');
                const depositInput = modal.find('input#complexpayment-fromdeposit');
                const depositWholeSumm = toRubles(modal.find('span#deposit').text());
                let useDiscount = false;
                let additionalSumm = 0;
                totalDebt.text(globalSumm + additionalSumm);
                leftSumm.text(globalSumm + additionalSumm);
                let powerSumm = 0;
                let memSumm = 0;
                let targetSumm = 0;
                let simpleSumm = 0;

                let noPowerLimitBtn = modal.find('button.no-limit');
                let noLimitInput = modal.find('input#complexpayment-nolimitpower');
                let noLimitAdditionalInput = modal.find('input#complexpayment-nolimitadditionalpower');
                noPowerLimitBtn.on('click.removeLimit', function (e) {
                    let oldSumm = toRubles($(this).parents('div.power-container').eq(0).attr('data-summ'));
                    e.stopPropagation();
                    if ($(this).hasClass('main')) {
                        noLimitInput.val(noLimitInput.val() + $(this).attr('data-month') + ' ');
                    }
                    else {

                        noLimitAdditionalInput.val(noLimitAdditionalInput.val() + $(this).attr('data-month') + ' ');
                    }
                    $(this).popover('destroy');
                    disableElement($(this));
                    // пересчитаю электроэнергию по максимальному тарифу
                    let diff = parseInt($(this).attr('data-difference'));
                    let overCost = toRubles($(this).attr('data-overcost'));
                    let fullCost = toRubles(diff * overCost);
                    $(this).parents('div.power-container').eq(0).attr('data-summ', fullCost).find('b').html(fullCost + ' &#8381;').attr('data-content', 'Принудительная оплата без учёта льготного лимита<br>Потрачено электроэнергии- <b class=\'text-info\'> ' + diff + ' </b><br/>Цена киловатта- <b class=\'text-info\'>' + overCost + '</b> &#8381; ');
                    globalSumm = toRubles(globalSumm + fullCost - oldSumm);
                    totalDebt.text(globalSumm);
                    if (powerSumm > 0)
                        powerSumm += fullCost - oldSumm;
                    recalculateSumm();
                });
                sendBtn.on('click.send', function () {
                    // если указана сумма платежа- отправляю форму на сохранение
                    if (depositInput.hasClass('failed') || discountInput.hasClass('failed')) {
                        makeInformer('danger', 'Ошибка', 'Что-то не так с данными о скидке или депозите! Проверьте правильность ввода');
                        return false;
                    }
                    if (countedSumm.val() > 0) {
                        sendAjax('post', '/payment/complex/save', callback, frm[0], true);

                        function callback(answer) {
                            //notificationCallback(answer['result']);
                            if (answer['status'] === 1) {
                                modal.modal('hide');
                                modal.on('hidden.bs.modal', function () {
                                    makeInformer('success', 'Счёт создан', 'Теперь нужно выбрать дальнейшее действие');
                                    editBill(answer['billId']);
                                });
                            }
                            else if (answer['status'] === 2) {
                                makeInformer('danger', "Ошибка во время оплаты", answer['errors']);
                            }
                            else {
                                makeInformer('danger', "Ошибка во время оплаты", 'Произошла неизвестная ошибка, попробуйте ещё раз');
                            }
                        }
                    }
                    else {
                        makeInformer('danger', 'Сохранение', 'Выберите что-то для сохранения платежа');
                    }
                });

                function recalculateSumm() {
                    let discount = isSumm(discountSummInput.val());
                    let deposit = isSumm(depositSummInput.val());
                    let summ = powerSumm + memSumm + targetSumm + simpleSumm;
                    totalPayment.text(toRubles(summ));
                    leftSumm.text(toRubles(globalSumm - summ + additionalSumm));
                    countedSumm.val(toRubles(summ));
                    if (discount && deposit) {
                        if (discount + deposit < summ) {
                            depositSumm.parents('p').eq(0).removeClass('hidden');
                            discountSumm.parents('p').eq(0).removeClass('hidden');
                            recalculatedSumm.parents('p').eq(0).removeClass('hidden');
                            discountSumm.text(discount);
                            depositSumm.text(deposit);
                            console.log(summ - discount - deposit);
                            recalculatedSumm.text(toRubles((summ - discount) - deposit));
                        }
                        else {
                            // сообщение об ошибке и сбрасываю поля ввода
                            makeInformer('danger', 'Ошибка', 'Сумма скидки и депозита не может быть больше суммы платежа! Придётся заполнить их снова!');
                            depositSumm.parents('p').eq(0).addClass('hidden');
                            discountSumm.parents('p').eq(0).addClass('hidden');
                            recalculatedSumm.parents('p').eq(0).addClass('hidden');
                            discountSumm.text(0);
                            depositSumm.text(0);
                            recalculatedSumm.text(0);
                            useDepositBtn.trigger('click');
                            useDiscountBtn.trigger('click');
                        }
                    }
                    else if (discount) {
                        if (discount < summ) {
                            discountSumm.parents('p').eq(0).removeClass('hidden');
                            recalculatedSumm.parents('p').eq(0).removeClass('hidden');
                            discountSumm.text(discount);
                            recalculatedSumm.text(toRubles(summ - discount));
                        }
                        else {
                            discountSumm.parents('p').eq(0).addClass('hidden');
                            recalculatedSumm.parents('p').eq(0).addClass('hidden');
                            discountSumm.text(0);
                            recalculatedSumm.text(0);
                        }
                    }
                    else if (deposit) {
                        if (deposit < summ) {
                            depositSumm.parents('p').eq(0).removeClass('hidden');
                            recalculatedSumm.parents('p').eq(0).removeClass('hidden');
                            depositSumm.text(deposit);
                            recalculatedSumm.text(toRubles(summ - deposit));
                        }
                        else {
                            depositSumm.parents('p').eq(0).addClass('hidden');
                            recalculatedSumm.parents('p').eq(0).addClass('hidden');
                            depositSumm.text(0);
                            recalculatedSumm.text(0);
                        }
                    }
                    else {
                        discountSumm.parents('p').eq(0).addClass('hidden');
                        depositSumm.parents('p').eq(0).addClass('hidden');
                        discountSumm.text(0);
                        depositSumm.text(0);
                        recalculatedSumm.parents('p').eq(0).addClass('hidden');
                    }
                }

                // ОБРАБОТКА СКИДКИ ==================================================================================
                handleCashInput(discountInput);
                discountInput.on('input.checkDiscout, blur.checkDiscount', function () {
                    let summ;
                    if (summ = isSumm($(this).val())) {
                        if (summ > toRubles(totalPayment.text()) || summ + isSumm(depositSumm.text()) > isSumm(totalPayment.text())) {
                            makeInputWrong($(this));
                            makeInformer('danger', 'Ошибка', 'Сумма скидки не может превышать сумму платежа!');
                        }
                        else {
                            recalculateSumm();
                        }
                    }

                });

                useDiscountBtn.on('click.switch', function () {
                    if (totalPayment.text() && toRubles(totalPayment.text()) > 0) {
                        if (useDiscount) {
                            $(this).text("Использовать скидку.").addClass('btn-success').removeClass('btn-danger');
                            discountInput.prop('disabled', true).val('').removeClass('failed');
                            discountReason.prop('disabled', true).val('');
                            recalculateSumm();
                            useDiscount = false;
                        }
                        else {
                            // скидка не используется.
                            $(this).text("Не использовать скидку.").removeClass('btn-success').addClass('btn-danger');
                            discountInput.prop('disabled', false);
                            discountReason.prop('disabled', false);
                            discountInput.focus();
                            useDiscount = true;
                        }
                    }
                    else {
                        makeInformer('danger', 'Рано!', 'Сначала выберите что-то для оплаты');
                    }
                });
                // ОБРАБОТКА ОПЛАТЫ С ДЕПОЗИТА ==================================================================================
                if (depositSumm === 0) {
                    disableElement(useDepositBtn, "на депозите нет средств");
                }
                let useDeposit = false;
                handleCashInput(depositInput);
                depositInput.on('input.checkDeposit, blur.checkDiscount', function () {
                    let summ;
                    if (summ = isSumm($(this).val())) {
                        if (summ > toRubles(totalPayment.text() - toRubles(discountSumm)) || summ + isSumm(discountSumm.text()) > isSumm(totalPayment.text())) {
                            makeInputWrong($(this));
                            makeInformer('danger', 'Ошибка', 'Использование депозита не может превышать сумму платежа!');
                        }
                        else if (summ > depositWholeSumm) {
                            makeInputWrong($(this));
                            makeInformer('danger', 'Ошибка', 'На депозите нет таких денег!');
                        }
                        else {
                            recalculateSumm();
                        }
                    }

                });

                useDepositBtn.on('click.switch', function () {
                    if (totalPayment.text() && toRubles(totalPayment.text()) > 0) {
                        if (useDeposit) {
                            $(this).text("Использовать депозит.").addClass('btn-success').removeClass('btn-danger');
                            depositInput.prop('disabled', true).val('').removeClass('failed');
                            recalculateSumm();
                            useDeposit = false;
                        }
                        else {
                            // скидка не используется.
                            $(this).text("Не использовать депозит.").removeClass('btn-success').addClass('btn-danger');
                            depositInput.prop('disabled', false);
                            depositInput.focus();
                            useDeposit = true;
                        }
                    }
                    else {
                        makeInformer('danger', 'Рано!', 'Сначала выберите что-то для оплаты');
                    }
                });
                // ОБРАБОТКА ПЛАТЕЖЕЙ ЗА ЭЛЕКТРОЭНЕРГИЮ ==================================================================================
                let powerPayAllBtn = modal.find('div#powerCollector button.pay-all');
                let powerPayNothingBtn = modal.find('div#powerCollector button.pay-nothing');
                let powerParts = modal.find('div.power-container.main');
                let additionalPowerParts = modal.find('div.power-container.additional');

                // частичная оплата по клику
                function payPowerToClick(parts, input, additional) {
                    parts.hover(function () {
                        $(this).prevAll('div').addClass('choosed');
                        // рассчитаю сумму оплаты
                    }, function () {
                        $(this).prevAll('div').removeClass('choosed');
                    });
                    parts.on('click.summ', function () {
                        // помечаю этот элемент и все ранее выбранные, как готовые для оплаты
                        $(this).prevAll('div').addClass('selected');
                        $(this).addClass('selected');
                        parts.removeClass('hoverable choosed');
                        let summ = 0;
                        let counter = 1;
                        $(this).prevAll().each(function () {
                            let s;
                            if (s = $(this).attr('data-summ')) {
                                ++counter;
                                summ += toRubles(s);
                            }
                        });
                        input.val(counter);
                        summ += toRubles($(this).attr('data-summ'));
                        parts.unbind('mouseenter mouseleave');
                        parts.off('click.summ');
                        powerSumm += summ;
                        recalculateSumm();
                        if(additional){
                            enableElement(powerPayNothingBtn.filter('.additional'));
                            disableElement(powerPayAllBtn.filter('.additional'));
                        }
                        else{
                            enableElement(powerPayNothingBtn.filter('.main'));
                            disableElement(powerPayAllBtn.filter('.main'));
                        }

                    });
                }

                payPowerToClick(powerParts, powerPeriods);
                payPowerToClick(additionalPowerParts, additionalPowerPeriods, true);
                powerPayAllBtn.on('click.all', function () {
                    // отмечу все платежи за электроэнергию как оплачиваемые
                    disableElement($(this));
                    enableElement($(this).parent().find('button.pay-nothing'));
                    if ($(this).hasClass('main')) {
                        powerParts.addClass('selected').removeClass('hoverable choosed');
                        // считаю общую сумму платежей за электричество и выношу её в общее значение
                        powerParts.each(function () {
                            powerSumm += toRubles($(this).attr('data-summ'));
                        });
                        powerParts.unbind('mouseenter mouseleave');
                        powerParts.off('click.summ');
                        recalculateSumm();
                        powerPeriods.val(powerParts.length);
                    }
                    else {
                        additionalPowerParts.addClass('selected').removeClass('hoverable choosed');
                        // считаю общую сумму платежей за электричество и выношу её в общее значение
                        additionalPowerParts.each(function () {
                            powerSumm += toRubles($(this).attr('data-summ'));
                        });
                        additionalPowerParts.unbind('mouseenter mouseleave');
                        additionalPowerParts.off('click.summ');
                        recalculateSumm();
                        additionalPowerPeriods.val(additionalPowerParts.length);
                    }
                });
                powerPayNothingBtn.on('click.nothing', function () {
                    disableElement($(this));
                    enableElement($(this).parent().find('button.pay-all'));
                    if ($(this).hasClass('main')) {
                        // отмечу все платежи за электроэнергию как оплачиваемые
                        // считаю общую сумму платежей за электричество и выношу её в общее значение
                        let selected = powerParts.filter('.selected');
                        selected.each(function () {
                            powerSumm -= toRubles($(this).attr('data-summ'));
                        });
                        powerParts.removeClass('choosed selected').addClass('hoverable');
                        payPowerToClick(powerParts, powerPeriods);
                        recalculateSumm();
                        powerPeriods.val(0);
                    }
                    else {
                        // отмечу все платежи за электроэнергию как оплачиваемые
                        // считаю общую сумму платежей за электричество и выношу её в общее значение
                        let selected = additionalPowerParts.filter('.selected');
                        selected.each(function () {
                            powerSumm -= toRubles($(this).attr('data-summ'));
                        });
                        additionalPowerParts.removeClass('choosed selected').addClass('hoverable');
                        payPowerToClick(additionalPowerParts, additionalPowerPeriods);
                        recalculateSumm();
                        powerPeriods.val(0);
                    }
                });
                // ОБРАБОТКА ПЛАТЕЖЕЙ ЗА ЧЛЕНСКИЕ ВЗНОСЫ ==================================================================================
                let addQuartersInput = modal.find('input#addFutureQuarters');
                let addQuartersAdditionalInput = modal.find('input#addFutureQuartersAdditional');
                let memPayAllBtn = modal.find('div#membershipCollector button.pay-all');
                let memPayNothingBtn = modal.find('div#membershipCollector button.pay-nothing');
                let memParts = modal.find('div.membership-container.main');
                let memAdditionalParts = modal.find('div.membership-container.additional');
                let futureDiv = modal.find('div#forFutureQuarters');
                let additionalFutureDiv = modal.find('div#forAdditionalFutureQuarters');

                // частичная оплата по клику
                function payMembershipToClick(parts, input, additional) {
                    parts.hover(function () {
                        $(this).prevAll('div').addClass('choosed');
                        // рассчитаю сумму оплаты
                    }, function () {
                        $(this).prevAll('div').removeClass('choosed');
                    });
                    parts.on('click.summ', function () {
                        // помечаю этот элемент и все ранее выбранные, как готовые для оплаты
                        $(this).prevAll('div').addClass('selected');
                        $(this).addClass('selected');
                        parts.removeClass('hoverable choosed');
                        let summ = 0;
                        let counter = 1;
                        $(this).prevAll().each(function () {
                            let s;
                            if (s = $(this).attr('data-summ')) {
                                ++counter;
                                summ += toRubles(s);
                            }
                        });
                        input.val(counter);
                        summ += toRubles($(this).attr('data-summ'));
                        parts.unbind('mouseenter mouseleave');
                        parts.off('click.summ');
                        memSumm += summ;
                        recalculateSumm();
                        if(additional){
                            enableElement(memPayNothingBtn.filter('.additional'));
                            disableElement(memPayAllBtn.filter('.additional'));
                        }
                        else{
                            enableElement(memPayNothingBtn.filter('.main'));
                            disableElement(memPayAllBtn.filter('.main'));
                        }
                    });
                }

                payMembershipToClick(memParts, memberPeriods);
                payMembershipToClick(memAdditionalParts, memberAdditionalPeriods, true);

                memPayAllBtn.on('click.all', function () {
                    disableElement($(this));
                    enableElement($(this).parent().find('button.pay-nothing'));
                    if ($(this).hasClass('main')) {
                        // сброшу количество дополнительных кварталов
                        addQuartersInput.val('');
                        futureDiv.text('');
                        additionalSumm -= futureDiv.attr('data-additional-summ');
                        futureDiv.attr('data-additional-summ', 0);
                        // отмечу все платежи  как оплачиваемые
                        memParts.addClass('selected').removeClass('hoverable choosed');
                        // считаю общую сумму платежей за электричество и выношу её в общее значение
                        memParts.each(function () {
                            memSumm += toRubles($(this).attr('data-summ'));
                        });
                        memParts.unbind('mouseenter mouseleave');
                        memParts.off('click.summ');
                        memberPeriods.val(memParts.length);
                    }
                    else{
                        // сброшу количество дополнительных кварталов
                        addQuartersAdditionalInput.val('');
                        futureDiv.text('');
                        additionalSumm -= additionalFutureDiv.attr('data-additional-summ');
                        additionalFutureDiv.attr('data-additional-summ', 0);
                        // отмечу все платежи  как оплачиваемые
                        memAdditionalParts.addClass('selected').removeClass('hoverable choosed');
                        // считаю общую сумму платежей за электричество и выношу её в общее значение
                        memAdditionalParts.each(function () {
                            memSumm += toRubles($(this).attr('data-summ'));
                        });
                        memAdditionalParts.unbind('mouseenter mouseleave');
                        memAdditionalParts.off('click.summ');
                        memberAdditionalPeriods.val(memAdditionalParts.length);
                    }
                    recalculateSumm();
                });
                memPayNothingBtn.on('click.nothing', function () {
                    disableElement($(this));
                    enableElement($(this).parent().find('button.pay-all'));

                    if ($(this).hasClass('main')) {
                        // сброшу количество дополнительных кварталов
                        addQuartersInput.val('');
                        futureDiv.text('');
                        memSumm -= futureDiv.attr('data-additional-summ');
                        additionalSumm -= futureDiv.attr('data-additional-summ');
                        futureDiv.attr('data-additional-summ', 0);
                        let selected = memParts.filter('.selected');
                        selected.each(function () {
                            memSumm -= toRubles($(this).attr('data-summ'));
                        });
                        memParts.removeClass('choosed selected').addClass('hoverable');
                        payMembershipToClick(memParts, memberPeriods);
                        recalculateSumm();
                        memberPeriods.val(0);
                    }
                    else{
                        // сброшу количество дополнительных кварталов
                        addQuartersAdditionalInput.val('');
                        additionalFutureDiv.text('');
                        additionalSumm -= additionalFutureDiv.attr('data-additional-summ');
                        memSumm -= additionalFutureDiv.attr('data-additional-summ');
                        additionalFutureDiv.attr('data-additional-summ', 0);
                        let selected = memAdditionalParts.filter('.selected');
                        selected.each(function () {
                            memSumm -= toRubles($(this).attr('data-summ'));
                        });
                        memAdditionalParts.removeClass('choosed selected').addClass('hoverable');
                        payMembershipToClick(memAdditionalParts, memberAdditionalPeriods, true);
                        recalculateSumm();
                        memberAdditionalPeriods.val(0);
                    }
                });
                // оплата дополнительных кварталов
                addQuartersInput.on('input.add', function () {
                    if ($(this).val() > 0) {
                        sendAjax('get', '/get/future-quarters/' + $(this).val() + "/" + cottageNumber, callback);

                        function callback(answer) {
                            if (answer['status'] === 2) {
                                // если не заполнены тарифы- открою окно для заполнения
                                if (tariffsFillWindow)
                                    tariffsFillWindow.close();
                                makeNewWindow('/fill/membership/' + answer['lastQuarterForFilling'], tariffsFillWindow, fillCallback);

                                function fillCallback() {
                                    addQuartersAdditionalInput.trigger('input');
                                }
                            }
                            else if (answer['status'] === 3) {
                                if (tariffsFillWindow)
                                    tariffsFillWindow.close();
                                // если не заполнены тарифы- открою окно для заполнения
                                makeNewWindow('/fill/membership-personal/' + cottageNumber + '/' + answer['lastQuarterForFilling'], tariffsFillWindow, callback);

                                function callback() {
                                    addQuartersInput.trigger('input');
                                }
                            }
                            else if (answer['status'] === 1) {
                                enableElement(memPayAllBtn.filter('.main'));
                                enableElement(memPayNothingBtn.filter('.main'));
                                futureDiv.html(answer['content']);
                                let selected = memParts.filter('.selected');
                                selected.each(function () {
                                    memSumm -= toRubles($(this).attr('data-summ'));
                                });
                                let futureQuarters = futureDiv.find('div.membership-container');
                                futureDiv.find('.popovered').popover({'trigger': 'hover', 'html': true});
                                memParts.addClass('selected').removeClass('hoverable choosed');
                                futureQuarters.addClass('selected').removeClass('hoverable choosed');
                                memParts.each(function () {
                                    memSumm += toRubles($(this).attr('data-summ'));
                                });
                                // добавлю к общей сумме платежа то, что прилетело
                                memSumm += answer['totalSumm'];
                                futureDiv.attr('data-additional-summ',  answer['totalSumm']);
                                memParts.unbind('mouseenter mouseleave');
                                memParts.off('click.summ');
                                additionalSumm += answer['totalSumm'];
                                memberPeriods.val(memParts.length + futureQuarters.length);
                                recalculateSumm();
                            }
                        }
                    }
                });
                // оплата дополнительных кварталов
                addQuartersAdditionalInput.on('input.add', function () {
                    if ($(this).val() > 0) {
                        sendAjax('get', '/get/future-quarters/additional/' + $(this).val() + "/" + cottageNumber, callback);

                        function callback(answer) {
                            if (answer['status'] === 2) {
                                // если не заполнены тарифы- открою окно для заполнения
                                if (tariffsFillWindow)
                                    tariffsFillWindow.close();
                                makeNewWindow('/fill/membership/' + answer['lastQuarterForFilling'], tariffsFillWindow, fillCallback);

                                function fillCallback() {
                                    addQuartersAdditionalInput.trigger('input');
                                }
                            }
                            else if (answer['status'] === 3) {
                                if (tariffsFillWindow)
                                    tariffsFillWindow.close();
                                // если не заполнены тарифы- открою окно для заполнения
                                makeNewWindow('/fill/membership-personal/additional/' + cottageNumber + '/' + answer['lastQuarterForFilling'], tariffsFillWindow, callback);

                                function callback() {
                                    addQuartersAdditionalInput.trigger('input');
                                }
                            }
                            else if (answer['status'] === 1) {
                                enableElement(memPayAllBtn.filter('.additional'));
                                enableElement(memPayNothingBtn.filter('.additional'));
                                additionalFutureDiv.html(answer['content']);
                                let selected = memAdditionalParts.filter('.selected');
                                selected.each(function () {
                                    memSumm -= toRubles($(this).attr('data-summ'));
                                });
                                let futureQuarters = additionalFutureDiv.find('div.membership-container');
                                additionalFutureDiv.find('.popovered').popover({'trigger': 'hover', 'html': true});
                                memAdditionalParts.addClass('selected').removeClass('hoverable choosed');
                                futureQuarters.addClass('selected').removeClass('hoverable choosed');
                                memAdditionalParts.each(function () {
                                    memSumm += toRubles($(this).attr('data-summ'));
                                });
                                // добавлю к общей сумме платежа то, что прилетело
                                memSumm += answer['totalSumm'];
                                additionalFutureDiv.attr('data-additional-summ',  answer['totalSumm']);
                                memAdditionalParts.unbind('mouseenter mouseleave');
                                memAdditionalParts.off('click.summ');
                                additionalSumm += answer['totalSumm'];
                                memberAdditionalPeriods.val(memAdditionalParts.length + futureQuarters.length);
                                recalculateSumm();
                            }
                        }
                    }
                });
                // ОБРАБОТКА ПЛАТЕЖЕЙ ЗА ЦЕЛЕВЫЕ ВЗНОСЫ ==================================================================================
                // при нажатии на кнопку полной оплаты целевого или разового взноса- заполню поле ввода максимальной суммой
                let fullFillBtns = modal.find('button.btn-pay-all');
                fullFillBtns.on('click.fill', function () {
                    let input = modal.find('input#' + $(this).attr('data-for'));
                    input.val(input.attr('data-max-summ'));
                    input.trigger('change');
                });
                // пересчитываю данные при введении суммы оплаты целевого платежа
                let targetInputs = modal.find('input.target-pay');
                targetInputs.on('change.fill', function () {
                    if ($(this).val()) {
                        // если введено верное значение
                        let limit = toRubles($(this).attr('data-max-summ'));
                        let val = toRubles($(this).val());
                        if (/^\d+[,.]?\d{0,2}$/.test($(this).val()) && val <= limit) {
                            targetSumm = 0;
                            // получаю сумму всех полей ввода целевых платежей
                            targetInputs.each(function () {
                                if ($(this).val()) {
                                    targetSumm += toRubles($(this).val());
                                }
                            });
                            recalculateSumm();
                        }
                        else {
                            $(this).focus();
                            makeInformer('danger', "Ошибка", "Неверное значение!");
                        }
                    }
                });
                let targetPayAllBtn = modal.find('div#targetCollector button.pay-all');
                let targetPayNothingBtn = modal.find('div#targetCollector button.pay-nothing');

                targetPayAllBtn.on('click.all', function () {
                    enableElement($(this).parent().find('button.pay-nothing'));
                    disableElement($(this));
                    $(this).parents('div.target-container').eq(0).find('input.target-pay').each(function () {
                        let summ = toRubles($(this).attr('data-max-summ'));
                        $(this).val(summ);
                        targetSumm += summ;
                    });
                    recalculateSumm();
                });
                targetPayNothingBtn.on('click.nothing', function () {
                    enableElement($(this).parent().find('button.pay-all'));
                    disableElement($(this));
                    $(this).parents('div.target-container').eq(0).find('input.target-pay').each(function () {
                        $(this).val(0);
                        $(this).trigger('change');
                    });
                    recalculateSumm();
                });
                // ОБРАБОТКА ПЛАТЕЖЕЙ ЗА РАЗОВЫЕ ВЗНОСЫ ==================================================================================
                // пересчитываю данные при введении суммы оплаты целевого платежа
                let singleInputs = modal.find('input.single-pay');
                singleInputs.on('change.fill', function () {
                    if ($(this).val()) {
                        // если введено верное значение
                        let limit = toRubles($(this).attr('data-max-summ'));
                        let val = toRubles($(this).val());
                        if (/^\d+[,.]?\d{0,2}$/.test($(this).val()) && val <= limit) {
                            simpleSumm = 0;
                            // получаю сумму всех полей ввода целевых платежей
                            singleInputs.each(function () {
                                if ($(this).val()) {
                                    simpleSumm += toRubles($(this).val());
                                }
                            });
                            recalculateSumm();
                        }
                        else {
                            $(this).focus();
                        }
                    }
                });

                let simplePayAllBtn = modal.find('div#simpleCollector button.pay-all');
                let simplePayNothingBtn = modal.find('div#simpleCollector button.pay-nothing');

                simplePayAllBtn.on('click.all', function () {
                    enableElement(simplePayNothingBtn);
                    disableElement(simplePayAllBtn);
                    simpleSumm = 0;
                    singleInputs.each(function () {
                        let summ = toRubles($(this).attr('data-max-summ'));
                        $(this).val(summ);
                        simpleSumm += summ;
                    });
                    recalculateSumm();
                });
                simplePayNothingBtn.on('click.nothing', function () {
                    enableElement(simplePayAllBtn);
                    disableElement(simplePayNothingBtn);
                    simpleSumm = 0;
                    singleInputs.each(function () {
                        $(this).val('');
                    });
                    recalculateSumm();
                });
            }
            else if (answer['status'] === 3) {
                editBill(answer['identificator']);
            }
        }

        return true;
    });
    const paymentsHistoryBtn = $('button#buttonShowPaymentsStory');
    paymentsHistoryBtn.on('click.showHistory', function () {
        sendAjax('get', '/get/bills/' + cottageNumber, callback);

        function callback(answer) {
            if (answer['status'] === 1) {
                let modal = makeModal('Просмотр истории платежей');
                let modalBody = modal.find('div.modal-body');
                let i = 0;
                while (answer['data'][i]) {
                    let simple = answer['data'][i];
                    let payed = simple['isPayed'] ? 'Оплачен' : 'Не оплачен';
                    modalBody.append('<p class="hoverable" data-payment-id="' + simple['id'] + '">Платёж, сумма: ' + simple['summ'] + ' &#8381;. ' + payed + ' ' + simple['paymentTime'] + '</p>');
                    i++;
                }
                modal.find('p.hoverable').on('click.show', function () {
                    let id = $(this).attr('data-payment-id');
                    modal.modal('hide');
                    modal.on('hidden.bs.modal', function () {
                        editBill(id);
                    });
                })
            }
            else if (answer['status'] === 2) {
                makeInformer('info', 'Список платежей', 'Платежей по данному участку не найдено');
            }
            else {
                makeInformer('danger', 'Что-то пошло не так', 'Сообщите мне об этой ошибке')
            }
        }

    });

    let changeBtn = $('button#changeInfoButton');
    changeBtn.on('click.change', function () {
        let modal = makeModal('Изменение информации об участке.');
        modal.find('div.modal-content').addClass('test-transparent');
        sendAjax('get', '/get-form/change/' + cottageNumber, callback);

        function callback(answer) {
            if (answer['status'] === 1) {
                let data = $(answer['data']);
                modal.find('div.modal-body').append(data);
                const membership = $('input#addcottage-membershippayfor');
                membership.on('input.fill', function () {
                    // если введённое значение совпадает с шаблоном ввода- отправлю запрос на проверку заполненности тарифов
                    const re = /^\s*(\d{4})\W*([1-4])\s*$/;
                    let found;
                    if (found = membership.val().match(re)) {
                        sendAjax('get', '/check/membership/interval/' + found[1] + '-' + found[2], callback);

                        function callback(e) {
                            if (e.status === 1) {
                                // открою новое окно для заполнения тарифа
                                if (membershipFillWindow)
                                    membershipFillWindow.close();
                                membershipFillWindow = window.open('fill/membership/' + found[1] + '-' + found[2], '_blank');
                                membershipFillWindow.focus();
                                $(membershipFillWindow).on('load.trigger', function () {
                                    // при закрытии окна повторно отсылаю данные поля на проверку
                                    $(membershipFillWindow).on('unload.test', function () {
                                        membership.trigger('input');
                                        membership.trigger('change');
                                    });
                                })
                            }
                            else if (e.status === 2) {
                                if (membershipFillWindow)
                                    membershipFillWindow.close();
                            }
                        }
                    }
                });
                // парсинг имени
                let namePattern = /^\s*([ёа-я-]+)\s+([ёа-я]+)\s+([ёа-я]+)\s*$/i;
                let nameInputs = modal.find('input#addcottage-cottageownerpersonals, input#addcottage-cottagecontacterpersonals');
                nameInputs.on('blur.testName', function () {
                    let match;
                    match = $(this).val().match(namePattern);
                    if (match[1]) {
                        let text = "Фамилия: " + match[1] + ", имя: " + match[2] + ", отчество: " + match[3];
                        $(this).parent().find("div.hint-block").text(text);
                    }
                    else {
                        $(this).parent().find("div.hint-block").html('<b class="text-success">Обязательное поле.</b> Буквы, пробелы и тире.');
                    }
                });

                // парсинг номера телефона
                let phoneInputs = modal.find('input#addcottage-cottageownerphone, input#addcottage-cottagecontacterphone');
                phoneInputs.on('input.testName', function () {
                    let hint = $(this).parent().find('div.hint-block');
                    let link = $(this).val();
                    let filtredVal = link.replace(/[^0-9]/g, '');
                    if (filtredVal.length === 7) {
                        hint.html('Распознан номер +7 831 ' + filtredVal.substr(0, 3) + '-' + filtredVal.substr(3, 2) + '-' + filtredVal.substr(5, 2));
                    }
                    else if (filtredVal.length === 10) {
                        hint.html('Распознан номер +7 ' + filtredVal.substr(0, 3) + ' ' + filtredVal.substr(3, 3) + '-' + filtredVal.substr(6, 2) + '-' + filtredVal.substr(8, 2));
                    }
                    else if (filtredVal.length === 11) {
                        hint.html('Распознан номер +7 ' + filtredVal.substr(1, 3) + ' ' + filtredVal.substr(4, 3) + '-' + filtredVal.substr(7, 2) + '-' + filtredVal.substr(9, 2));
                    }
                    else if (link.length > 0) {
                        hint.html('Номер не распознан!');
                    }
                    else {
                        hint.html('<b class="text-info">Необязательное поле.</b> Десять цифр, без +7.');
                    }
                });

                let addContacter = modal.find('input#addcottage-hascontacter');
                let contacterDiv = modal.find('fieldset#contacterInfo');
                addContacter.on('change.switch', function () {
                    if ($(this).prop('checked'))
                        contacterDiv.removeClass('hidden');
                    else
                        contacterDiv.addClass('hidden');
                });
                let sended = false;
                data.on('submit', function (e) {
                    e.preventDefault();
                    if (!sended) {
                        sended = true;
                        let i = 0;
                        let loadedForm;
                        while (data[i]) {
                            if (data[i].nodeName === "FORM") {
                                loadedForm = data[i];
                                break;
                            }
                            i++;
                        }
                        const url = "/add-cottage/save/change";
                        sendAjax('post', url, callback, loadedForm, true);

                        function callback(answer) {
                            if (answer['status'] === 1) {
                                normalReload();
                                location.reload();
                            }
                        }
                    }
                })

            }
        }
    })
}

function editBill(identificator) {
    // запрошу сведения о платеже
    sendAjax('get', '/get-info/bill/' + identificator, callback);

    function callback(answer) {
        if (answer['status'] === 1) {
            let modal = makeModal('Информация о платеже', answer['view']);
            // Обработаю использование депозита
            //const totalPaymentSumm = modal.find('span#paymentTotalSumm');
            const deleteBillBtn = $('button#deleteBill');
            deleteBillBtn.on('click.delete', function () {
                sendAjax('post', '/bill/delete/' + identificator, callback);

                function callback() {
                    location.reload();
                }
            });
            // Обработаю функции кнопок
            const remindAboutPayBtn = modal.find('button#remindAbout');
            remindAboutPayBtn.on('click.remind', function () {
                remind('/send/pay/' + identificator);
            });
            const printInvoiceBtn = modal.find('button#printInvoice');
            const sendInvoiceBtn = modal.find('button#sendInvoice');
            sendInvoiceBtn.on('click.send', function () {
                disableElement(sendInvoiceBtn, "Шлю письмо");
                sendAjax('post', '/send-invoice/' + identificator, callback);

                function callback(answer) {
                    if (answer['status'] === 1) {
                        makeInformer('success', 'Квитанция отправлена', "Квитанция успешно отправлена на адрес, указанный в профиле участка");
                        enableElement(sendInvoiceBtn, "Отправить квитанцию ещё раз");
                    }
                    else if (answer['status'] === 2) {
                        makeInformer('danger', 'Квитанция не отправлена', "Квитанция не отправлена. Возможно, в профиле не указан адрес почтового ящика или нет соединения с интернетом");
                    }
                }
            });
            printInvoiceBtn.on('click.print', function () {
                disableElement(printInvoiceBtn, "Распечатываем квитанцию");
                makeNewWindow('/invoice/' + identificator, invoiceWindow, callback);

                function callback() {
                    // квитанция распечатана
                    makeInformer('success', 'Квитанция распечатана');
                    enableElement(printInvoiceBtn, 'Распечатать ещё одну квитанцию');
                }
            });
            // отмечу платёж оплаченным безналом
            const payNoCashButton = modal.find('button#payedNoCash');
            let link = modal;
            payNoCashButton.on('click.save', function () {
                makeInformer('info', 'Рано', 'Модуль ещё не готов.');
                return false;
                // link.modal('hide');
                // modal.on('hidden.bs.modal', function () {
                //     let newModal = makeModal('Подтверждение безналичной оплаты');
                //     newModal.find('div.modal-body').html('<div class="col-lg-12 text-center"><h2>Платёж на сумму ' + totalPaymentSumm.text() + ' &#8381; оплачен. </h2><button class="btn btn-success" id="confirmSavingBtn">Отправить счёт в архив как оплаченный</button></div>');
                //     const confirmBtn = newModal.find('button#confirmSavingBtn');
                //     confirmBtn.on('click.confirm', function () {
                //         disableElement(confirmBtn, 'Сохраняю');
                //         sendAjax('post', '/bill/save/no-cash/' + identificator, callback);
                //
                //         function callback() {
                //             //location.reload();
                //         }
                //     })
                // });
            });
            let payCashButton = modal.find('button#payedCash');
            payCashButton.on('click.save', function () {
                link.modal('hide');
                modal.on('hidden.bs.modal', function () {
                    let newModal = makeModal('Подтверждение наличной оплаты');
                    sendAjax('get', '/get-form/pay/cash/' + identificator, callback);

                    function callback(answer) {
                        if (answer['status'] === 1) {
                            let frm = $(answer['view']);
                            newModal.find('div.modal-body').append(frm);
                            let rawSumm = newModal.find('input#pay-rawsumm');
                            let summ = toRubles(newModal.find('span#paySumm').text());
                            let change = newModal.find('span#change');
                            let changeInput = newModal.find('input#pay-change');
                            let toDepositBtn = newModal.find('input#pay-changetodeposit');
                            let roundSummGetBtn = newModal.find('span#roundSummGet');
                            let toDepositInput = newModal.find('input#pay-todeposit');
                            let allToDeposit = newModal.find('button#allChangeToDepositBtn');
                            let ready = false;
                            frm.on('submit', function (e) {
                                e.preventDefault();
                                if (ready) {
                                    let i = 0;
                                    let loadedForm;
                                    while (frm[i]) {
                                        if (frm[i].nodeName === "FORM") {
                                            loadedForm = frm[i];
                                            break;
                                        }
                                        i++;
                                    }
                                    const url = "/pay/cash/confirm/" + identificator;
                                    sendAjax('post', url, callback, loadedForm, true);

                                    function callback(answer) {
                                        if (answer['status'] === 1) {
                                            location.reload();
                                        }
                                        else {
                                            makeInformer('danger', 'Сохранение платежа', 'Сохранение почему-то не удалось');
                                        }
                                    }
                                }
                                else {
                                    makeInformer('info', 'Сохранение платежа', 'Сначала заполните все необходимые поля.');
                                }
                            });
                            frm.on('afterValidate', function (event, fields, errors) {
                                ready = !(errors.length + newModal.find('input[aria-invalid="true"]').length);
                            });
                            frm.on('afterValidateAttribute', function (event, fields, errors) {
                                ready = !(errors.length + newModal.find('input[aria-invalid="true"]').length);
                            });
                            roundSummGetBtn.on('click.all', function () {
                                rawSumm.val(summ);
                                rawSumm.trigger('input', 'change');
                            });
                            allToDeposit.on('click.allToDeposit', function () {
                                toDepositInput.val(change.attr('data-change'));
                                change.text(0);
                                changeInput.val(0);
                            });
                            toDepositBtn.on('change.switch', function () {
                                if ($(this).prop('checked')) {
                                    // проверю, есть ли сдача
                                    if (!change.attr('data-change') || change.attr('data-change') === '0') {
                                        makeInformer('danger', 'ошибка', 'Для начисления на депозит сумма сдачи должна быть больше нуля!');
                                        $(this).prop('checked', false);
                                        return false;
                                    }
                                    allToDeposit.prop('disabled', false);
                                    toDepositInput.prop('disabled', false);
                                    // если в окне суммы внесения на депозит какая-то сумма, вычитаю её из суммы сдачи
                                    if (toDepositInput.val()) {
                                        let depositSumm = toRubles(toDepositInput.val().replace(',', '.'));
                                        change.text(change.attr('data-change') - depositSumm);
                                        changeInput.val(change.attr('data-change') - depositSumm);
                                    }
                                }
                                else {
                                    toDepositInput.prop('disabled', true).val(0);
                                    allToDeposit.prop('disabled', true);
                                    change.text(change.attr('data-change'));
                                    changeInput.val(change.attr('data-change'));
                                }
                            });
                            // расчёт суммы сдачи.
                            rawSumm.on('input.cash', function () {
                                if (/^\s*\d+[,.]?\d{0,2}\s*$/.test($(this).val())) {
                                    let cash = toRubles($(this).val());
                                    if (cash > summ) {
                                        let changeSumm = toRubles(cash - summ);
                                        if (toDepositBtn.prop('checked')) {
                                            let depositSumm = toRubles(toDepositInput.val());
                                            if (depositSumm + change.attr('data-change') > changeSumm) {
                                                change.text(changeSumm).attr('data-change', changeSumm);
                                                changeInput.val(changeSumm);
                                                toDepositInput.val(0);
                                            }
                                            else {
                                                if (depositSumm > 0) {
                                                    change.text(changeSumm - depositSumm).attr('data-change', changeSumm);
                                                    changeInput.val(changeSumm - depositSumm);
                                                }
                                                else {
                                                    change.text(changeSumm).attr('data-change', changeSumm);
                                                    changeInput.val(changeSumm);
                                                }
                                            }
                                        }
                                        else {
                                            change.text(changeSumm).attr('data-change', changeSumm);
                                            changeInput.val(changeSumm);
                                        }
                                    }
                                    else {
                                        change.text(0);
                                        toDepositInput.val(0);
                                    }
                                }
                            });
                            toDepositInput.on('input.toDeposit', function () {
                                if (/^\s*\d+[,.]?\d{0,2}\s*$/.test($(this).val())) {
                                    let cash = toRubles($(this).val());
                                    let changeSumm = toRubles(change.attr('data-change'));
                                    if (cash > changeSumm) {
                                        $(this).parents('div.form-group').addClass('has-error').removeClass('has-success').find('div.help-block').text('Сумма, зачисляемая на депозит не может быть больше суммы сдачи');

                                    }
                                    else {
                                        change.text(changeSumm - cash);
                                        changeInput.val(changeSumm - cash);
                                        $(this).parents('div.form-group').removeClass('has-error').addClass('has-success').find('div.help-block').text('');
                                    }
                                }
                                else {
                                    change.text(change.attr('data-change'));
                                    if ($(this).val()) {
                                        $(this).parents('div.form-group').addClass('has-error').removeClass('has-success').find('div.help-block').text('Тут должна быть сумма в рублях');
                                    }
                                }
                            });
                        }
                    }
                });
            });
        }
    }
}

function additionalFunctions() {
    // Отображение подробной информации о долгах
    let detailViewers = $('a.detail-debt');
    detailViewers.on('click.show', function (e) {
        e.preventDefault();
        let type = $(this).attr('data-type');
        sendAjax('get', '/show/debt/detail/' + type + '/' + cottageNumber, callback);

        function callback(answer) {
            makeModal('Подробности', answer);
        }
    });


    // покажу отчёты по участку за выбранный период
    let showRepotrsBtn = $('button#showReports');
    showRepotrsBtn.on('click.show', function () {
        let modal = makeModal('Выберите период для отчёта', "<div class='row'><form>\n" +
            "    <div class='form-group membership-group text-center'>\n" +
            "        <div class='col-lg-6'>\n" +
            "            <label class=\"control-label\">Начало периода\n" +
            "                <input id='begin-period' type='date' class='form-control'/>\n" +
            "            </label>\n" +
            "        </div>\n" +
            "        <div class='col-lg-6'>\n" +
            "            <label class=\"control-label\">Завершение периода\n" +
            "                <input id=\"end-period\" type='date' class='form-control'/>\n" +
            "            </label>\n" +
            "        </div>\n" +
            "    </div>\n" +
            "    <div class='col-lg-12 text-center'><button type='button' id='goBtn' class='btn btn-primary'>Показать</button></div>\n" +
            "</form></div>");
        let sendBtn = modal.find('button#goBtn');
        let start = modal.find('input#begin-period');
        let end = modal.find('input#end-period');
        sendBtn.on('click.send', function () {
            let startVal = start.val();
            let endVal = end.val();
            if (startVal && endVal) {
                window.open('/print/cottage-report/' + new Date(startVal).getTime() + '/' + new Date(endVal).getTime() + '/' + cottageNumber, '_blank')
            }
            else {
                makeInformer('warning', 'Рано', 'Выберите дату начала и завершения периода');
            }
        });
    });
    // отправляю оповещение о задолженности
    let sendDutiesBtn = $('button#sendNotificationBtn');
    let sendRegInfoBtn = $('button#sendRegInfoNotificationBtn');


    sendDutiesBtn.on('click.send', function () {
        remind('/send/duties/' + cottageNumber);
    });
    sendRegInfoBtn.on('click.send', function () {
        remind('/send/reg-info/' + cottageNumber);
    });
    // замена счётчика электроэнергии
    let changeCounterBtn = $('button#changePowerCounter');
    changeCounterBtn.on('click.change', function () {
        let modal = makeModal('Замена счётчика электроэнергии');
        sendAjax('get', '/service/change-counter/' + cottageNumber, callback);

        function callback(answer) {
            if (answer['data']) {
                let frm = $(answer['data']);
                modal.find('div.modal-body').append(frm);
                let sended = false;
                frm.on('submit.test', function (e) {
                    e.preventDefault();
                    if (!sended) {
                        sended = true;
                        let i = 0;
                        let loadedForm;
                        while (frm[i]) {
                            if (frm[i].nodeName === "FORM") {
                                loadedForm = frm[i];
                                break;
                            }
                            i++;
                        }
                        const url = "/service/change-counter/" + cottageNumber;
                        sendAjax('post', url, callback, loadedForm, true);

                        function callback(answer) {
                            if (answer['status'] === 1) {
                                location.reload();
                            }
                            else {
                                sended = false;
                                makeInformer('danger', 'Не удалось сохранить данные', handleErrors(answer['errors']));
                            }
                        }
                    }
                })
            }
        }
    });
    let createCottageBtn = $('button#createAdditionalCottage');
    createCottageBtn.on('click.add', function () {
        sendAjax('get', '/create/additional-cottage/' + cottageNumber, callback);
        function callback(data) {
            let modal = makeModal('Добавление дополнительного участка', data);
            let frm = modal.find('form#AdditionalCottage');
            let ready = false;
            let validateInProcess = false;
            let powerBtn = $('input#additionalcottage-ispower');
            let powerDependent = modal.find('input.power-dependent');
            let membershipBtn = $('input#additionalcottage-ismembership');
            let membershipDependent = modal.find('input.membership-dependent');
            let targetBtn = $('input#additionalcottage-istarget');
            let targetDependent = modal.find('input.target-dependent, label.target-dependent');
            powerBtn.on('change.switch', function () {
                if ($(this).prop('checked')) {
                    powerDependent.prop('disabled', false);
                }
                else {
                    powerDependent.prop('disabled', true).val('');
                }
            });
            membershipBtn.on('change.switch', function () {
                if ($(this).prop('checked')) {
                    membershipDependent.prop('disabled', false);
                }
                else {
                    membershipDependent.prop('disabled', true).val('');
                }
            });
            targetBtn.on('change.switch', function () {
                if ($(this).prop('checked')) {
                    targetDependent.prop('disabled', false).removeClass('disabled');
                }
                else {
                    targetDependent.prop('disabled', true).addClass('disabled');
                }
            });
            const membership = $('input#additionalcottage-membershippayfor');
            handleMembershipInput(membership);
            let squareInput = modal.find('input#additionalcottage-cottagesquare');
            handlePowerInputs(modal, squareInput);

            frm.on('beforeValidate.ready', function () {
                validateInProcess = true;
            });
            frm.on('afterValidate.ready', function (event, fields, errors) {
                validateInProcess = false;
                ready = !errors.length;
                if (errors.length > 0) {
                    makeInformer('danger', 'Ошибка', 'Не заполнены все необходимые поля или заполнены с ошибками. Проверьте введённые данные!');
                }
            });

            frm.on('submit', function (e) {
                e.preventDefault();
                if (ready && !validateInProcess) {
                    sendAjax('post', '/save/additional-cottage/' + cottageNumber, callback, frm[0], true);

                    function callback(answer) {
                        if (answer['status'] && answer['status'] === 1) {
                            location.reload();
                        }
                    }
                }
            });
        }
    });
}

