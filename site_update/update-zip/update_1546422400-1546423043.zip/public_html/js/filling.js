$(function () {
    handle();
});

function handle() {
    const inputs = $('.power-fill');
    inputs.popover({'trigger': 'focus', 'html': true});
    // при изменении поля- отправляю данные на сохранение
    inputs.on('change.send', function () {
        const pointer = $(this);
        // отправлю запрос с данными
        let attributes = {
            'PowerHandler[cottageNumber]': $(this).attr('data-cottage'),
            'PowerHandler[newPowerData]': $(this).val(),
            'PowerHandler[month]': $(this).attr('data-month'),
        };
        if($(this).attr('data-additional')){
            attributes['PowerHandler[additional]'] = 1;
        }
            sendAjax('post', '/fill/power/' + $(this).attr('data-cottage'), callback, attributes);

        function callback(data) {
            if(data['status'] === 1)
                makeInformer('success', 'Успешно.', 'Данные сохранены');
            if (data['totalSumm'] === 0) {
                // расходов электроэнергии за месяц не было
                makeInformer('success', "Заполнено", "Данные внесены. Расходов электроэнергии за месяц не было, оплата не требуется");
                pointer.before('<p><b class="text-success">Заполнено</b></p>');
                pointer.remove();
                pointer.parent().find('input.compact').removeClass('compact');
            }
            else if(data['totalSumm'] > 0){
                // Выведу сообщение с суммой оплаченного платежа.
                makeInformer('success', "Заполнено", "Данные внесены. Сумма оплаты за месяц: " + data['totalSumm'] + " &#8381;");
                pointer.before('<p><b class="text-success">Заполнено</b></p>');
                pointer.remove();
            }
            if (data['message']) {
                // если есть сообщение- значит, сохранение не удалось, вывожу сообщение
                makeInformer('warning', "Неудача", data['message']);
            }
            if (data['messageStatus']) {
                if (data['messageStatus']['status'] === 2) {
                    makeInformer('danger', 'Неуспешно', 'Нет подключения к интернету. Сообщение сохранено, вы сможете отправить его, когда подключение появится!');
                }
                else if (data['messageStatus']['status'] === 1) {
                    if (data['messageStatus']['results']['to-owner']) {
                        if (data['messageStatus']['results']['to-owner'] === true)
                            makeInformer('success', 'Успешно', 'Письмо владельцу успешно отправлено!');
                        else {
                            makeInformer('danger', 'Неуспешно', 'Письмо владельцу отправить не удалось!');
                        }
                    }
                    if (data['messageStatus']['results']['to-contacter']) {
                        if (data['messageStatus']['results']['to-contacter'] === true)
                            makeInformer('success', 'Успешно', 'Письмо контактному лицу успешно отправлено!');
                        else {
                            makeInformer('danger', 'Неуспешно', 'Письмо контактному лицу отправить не удалось!');
                        }
                    }
                }
            }
            if(data['errors']){
                makeInformer('danger', "Ошибка", handleErrors(data['errors']));
                pointer.parent().addClass('has-warning');
                pointer.focus();
            }
            if(data['changeCounter']){
                makeInformer('info', "Замена счётчика", "Был заменён счётчик электроэнергии. Дополнительная стоимость электроэнергии за месяц по данным старого счётчика: " + data['additionalPay'] + " &#8381;");
            }
        }
    })
}