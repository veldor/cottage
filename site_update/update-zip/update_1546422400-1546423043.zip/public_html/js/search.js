$(function () {
baseFunctional();
});

function baseFunctional() {
    const start = $('input#search-startdate');
    const finish = $('input#search-finishdate');
    // подключу действие кнопкам выбора даты
    let dataChooseBtns = $('button.period-choose');
    dataChooseBtns.on('click.choosePeriod', function () {
        let period = $(this).attr('data-period');
        let date = new Date;
        let day = date.getDate();
        let month = date.getMonth() + 1;
        let year = date.getFullYear();
        if(period === 'day'){
            start.val(year + '-' + month + '-' + day);
            finish.val(year + '-' + month + '-' + day);
        }
        else if(period === 'month'){
            start.val(year + '-' + month + '-01');
            finish.val(year + '-' + month + '-' + getLastDayOfMonth(year, month));
        }
        else if(period === 'year'){
            start.val(year + '-01-01');
            start.trigger('change');
            start.trigger('input');
            start.trigger('blur');
            finish.val(year + '-12-31');
            finish.trigger('change');
        }
    });
    $('a.bill-info').on('click.show-info', function () {
       showBill($(this).attr('data-bill-id'));
    });
    const startT = $('input#searchtariffs-startdate');
    const finishT = $('input#searchtariffs-finishdate');
    // подключу действие кнопкам выбора даты
    let dataTariffChooseBtns = $('button.tariff-period-choose');
    dataTariffChooseBtns.on('click.choosePeriod', function () {
        let period = $(this).attr('data-period');
        let date = new Date;
        let day = date.getDate();
        let month = date.getMonth() + 1;
        let year = date.getFullYear();
        if(period === 'day'){
            startT.val(year + '-' + month + '-' + day);
            finishT.val(year + '-' + month + '-' + day);
        }
        else if(period === 'month'){
            startT.val(year + '-' + month + '-01');
            finishT.val(year + '-' + month + '-' + getLastDayOfMonth(year, month));
        }
        else if(period === 'year'){
            startT.val(year + '-01-01');
            startT.trigger('change');
            startT.trigger('input');
            startT.trigger('blur');
            finishT.val(year + '-12-31');
            finishT.trigger('change');
        }
    });
}
function showBill(identificator) {
    let modal = makeModal('Информация о платеже');
    // запрошу сведения о платеже
    sendAjax('get', '/get-info/bill/' + identificator, callback);

    function callback(answer) {
        if (answer['status'] === 1) {
            modal.find('div.modal-body').append(answer['view']);
            // Обработаю функции кнопок
            const remindAboutPayBtn = modal.find('button#remindAbout');
            remindAboutPayBtn.on('click.remind', function () {
                remind('/send/pay/' + identificator);
            });
        }
    }
}