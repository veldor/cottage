<?php

/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 11.12.2018
 * Time: 12:48
 */

use app\assets\SearchAsset;
use app\models\CashHandler;
use app\widgets\MembershipStatisticWidget;
use app\widgets\PowerStatisticWidget;
use nirvana\showloading\ShowLoadingAsset;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this \yii\web\View */
/* @var $settings \app\models\Search */
/* @var $searchTariffs \app\models\Search */
/* @var $activeSearch string */
$this->title = 'Выборки';
SearchAsset::register($this);
ShowLoadingAsset::register($this);

$tabs = ['cashSearch' => 'active in', 'tariffsSearch' => ''];

if(!empty($activeSearch)){
	foreach ($tabs as $key => $tab) {
        if($key === $activeSearch){
            $tabs[$key] = 'active in';
        }
        else{
	        $tabs[$key] = '';
        }
    }
}

?>

<ul class="nav nav-tabs tabs">
    <li class="<?=$tabs['cashSearch']?>"><a href="#cashSearch" data-toggle="tab">Денежные средства</a></li>
    <li class="<?=$tabs['tariffsSearch']?>"><a href="#tariffsSearch" data-toggle="tab">Тарифы</a></li>
    <li><a href="#cottagesSearch" data-toggle="tab">Участки</a></li>
</ul>

<div class="tab-content">
    <div class="tab-pane margened fade <?=$tabs['cashSearch']?>" id="cashSearch">
        <div class="row">
        <?php
        $form = ActiveForm::begin(['id' => 'Search', 'options' => ['class' => 'form-horizontal bg-default'], 'enableAjaxValidation' => true, 'action' => ['/search']]);
        echo $form->field($settings, 'startDate', ['template' =>
            '<div class="col-lg-6 text-right">{label}</div><div class="col-lg-6"> {input}{error}{hint}</div>', 'options' => ['class' => 'form-group col-lg-5']])
            ->input('date')
            ->label('С');
        echo $form->field($settings, 'finishDate', ['template' =>
            '<div class="col-lg-6 text-right">{label}</div><div class="col-lg-6"> {input}{error}{hint}</div>', 'options' => ['class' => 'form-group col-lg-5']])
            ->input('date')
            ->label('По');
        $checkboxClass = $settings->summary ? 'btn btn-info with-signal active' : 'btn btn-info with-signal';
        echo $form->field($settings, 'summary', ['options' => ['class' => 'col-lg-2'], 'template' => '<div data-toggle="buttons">{input}</div>{error}{hint}'])->checkbox([
            'class' => '',
            'label' => 'Суммарно',
            'labelOptions' => ['class' => $checkboxClass],
        ], true);
        echo '<div class="col-lg-12 text-center"><button type="button" class="btn btn-default period-choose" data-period="day">За день</button><button type="button" class="btn btn-default period-choose" data-period="month">За месяц</button><button type="button" class="btn btn-default period-choose" data-period="year">За год</button></div>';
        echo "<div class='col-lg-12 text-center margened'>";
        echo Html::submitButton('Сформировать', ['class' => 'btn btn-success btn-lg margened', 'id' => 'addSubmit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'data-html' => 'true',]);
        echo '</div>';
        ActiveForm::end();
        echo '</div>';
        if ($result!== null && $activeSearch === 'cashSearch' && $result['status'] === 1) {
            if (!empty($result['totalSumm'])) {
                $summ = CashHandler::toRubles($result['totalSumm']);
                echo "<h4>Всего: <span class='text-info'>{$summ}  &#8381;</span></h4>";
            }
            echo $result['data'];
        }
        ?>
    </div>
    <div class="tab-pane margened fade <?=$tabs['tariffsSearch']?>" id="tariffsSearch">
        <div class="row">
	    <?php
	    $form = ActiveForm::begin(['id' => 'searchTariffs', 'options' => ['class' => 'form-horizontal bg-default'], 'enableAjaxValidation' => true, 'action' => ['/search']]);
	    echo $form->field($searchTariffs, 'startDate', ['template' =>
		    '<div class="col-lg-6 text-right">{label}</div><div class="col-lg-6"> {input}{error}{hint}</div>', 'options' => ['class' => 'form-group col-lg-5']])
		    ->input('date')
		    ->label('С');
	    echo $form->field($searchTariffs, 'finishDate', ['template' =>
		    '<div class="col-lg-6 text-right">{label}</div><div class="col-lg-6"> {input}{error}{hint}</div>', 'options' => ['class' => 'form-group col-lg-5']])
		    ->input('date')
		    ->label('По');
	    echo '<div class="col-lg-12 text-center"><button type="button" class="btn btn-default tariff-period-choose" data-period="month">За месяц</button><button type="button" class="btn btn-default tariff-period-choose" data-period="year">За год</button></div>';
	    echo "<div class='col-lg-12 text-center margened'>";
	    echo Html::submitButton('Сформировать', ['class' => 'btn btn-success btn-lg margened', 'id' => 'addSubmit', 'data-toggle' => 'tooltip', 'data-placement' => 'top', 'data-html' => 'true',]);
	    echo '</div>';
	    ActiveForm::end();
	    echo '</div>';
	    if ($result!== null && $activeSearch === 'tariffsSearch' && $result['status'] === 1) {
		    if(!empty($result['data']['membership'])){
		        echo "<h2>Членские взносы</h2>";
		        foreach ($result['data']['membership'] as $item){
			        echo MembershipStatisticWidget::widget(['quarterInfo' => $item]);
                }
            }
		    if(!empty($result['data']['power'])){
			    echo "<h2>Электроэнергия</h2>";
		        foreach ($result['data']['power'] as $item){
			        echo PowerStatisticWidget::widget(['monthInfo' => $item]);
                }
            }
	    }
	    ?>
    </div>
    <div class="tab-pane fade" id="cottagesSearch">...</div>
</div>