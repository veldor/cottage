<?php

/* @var $this \yii\web\View */
/* @var $content string */

use app\widgets\Alert;
use yii\bootstrap\Nav;
use yii\helpers\Html;
use yii\bootstrap\NavBar;
use yii\widgets\Breadcrumbs;
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
<head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
</head>
<body>
<?php $this->beginBody() ?>

<div class="wrap">
    <?php
    NavBar::begin([
        'brandLabel' => 'Управление садоводством',
        'brandUrl' => Yii::$app->homeUrl,
        'options' => [
            'class' => 'navbar-inverse navbar-fixed-top',
        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => [
            ['label' => 'Статистика', 'url' => ['/count/index']],
            ['label' => 'Выборки', 'url' => ['/search/search']],
            ['label' => 'Заполнение', 'url' => ['/filling/power']],
            ['label' => 'Тарифы', 'url' => ['/tariffs/index']],
            ['label' => 'Управление', 'url' => ['/management/index']],
//            ['label' => 'Шаблоны', 'url' => ['/template/show']],
//            ['label' => 'Панель управления', 'url' => ['/person/management'], 'visible' =>\Yii::$app->user->can('manage')],
            '<li>'. Html::beginForm(['/logout'], 'post'). Html::submitButton('Выйти: (' . Yii::$app->user->identity->username . ')',['class' => 'btn btn-link logout']). Html::endForm(). '</li>',
        ],
    ]);
    //echo ;
    NavBar::end();
    ?>

    <div class="container">
        <?= Breadcrumbs::widget([
            'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
            'homeLink'=>false,
        ]) ?>
        <?= Alert::widget() ?>
        <?= $content ?>
    </div>
</div>
<div id="alertsContentDiv"></div>

<?php $this->endBody() ?>
</body>
</html>
<?php $this->endPage() ?>
