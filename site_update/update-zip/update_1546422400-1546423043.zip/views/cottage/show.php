<?php

use app\assets\CottageAsset;
use app\models\CashHandler;
use app\models\GrammarHandler;
use app\models\TimeHandler;
use nirvana\showloading\ShowLoadingAsset;

/* @var $this \yii\web\View */


ShowLoadingAsset::register($this);
CottageAsset::register($this);


/** @var \app\models\Cottage $cottageInfo */
$this->title = 'Участок № ' . $cottageInfo->globalInfo->cottageNumber;

?>

<div class="row">
    <div class="col-lg-12">
        <button id="changeInfoButton" class="btn btn-info">Изменить данные</button>
        <h1>Участок № <?= $cottageInfo->globalInfo->cottageNumber ?></h1>

        <table class="table table-hover">
            <caption>Информация о платежах</caption>
            <tbody>
            <?php
            if ($cottageInfo['globalInfo']->individualTariff) {
	            echo '
                <tr>
                <td colspan="2"><b class="text-primary">Участку подключён индивидуальный тариф</b></td>
                </tr>
                ';
            }
            ?>
            <tr>
                <td>Электроэнергия</td>
                <td><?= $cottageInfo->powerDebts > 0 ? "<a class='btn btn-default detail-debt' data-type='power' href='#'><b class='text-danger'>Задолженность {$cottageInfo->powerDebts} &#8381;</b></a>" : "<b class='text-success'>Оплачено</b>" ?></td>
            </tr>
            <tr>
                <td>Электроэнергия- последний оплаченный месяц</td>
                <td>
                    <b class="text-info"><?= TimeHandler::getFullFromShotMonth($cottageInfo->globalInfo->powerPayFor) ?></b> <?= $cottageInfo->powerPayDifference ?>
                </td>
            </tr>
            <tr>
                <td>Электроэнергия- последние показания счётчика</td>
                <td><b class="text-info"><?= $cottageInfo->globalInfo->currentPowerData ?> кВт.ч</b>
                    (<?= TimeHandler::getFullFromShotMonth($cottageInfo->lastPowerFillDate) ?>
                    ) <?= $cottageInfo->powerDataCancellable ? "<button id='cancelFillPower' class='btn btn-danger'>Удалить</button>" : '' ?>
                </td>
            </tr>
            <tr>
                <td>Членские взносы</td>
                <td><?= $cottageInfo->membershipDebts > 0 ? "<a class='btn btn-default detail-debt' data-type='membership' href='#'><b class='text-danger'>Задолженность {$cottageInfo->membershipDebts} &#8381;</b></a>" : "<b class='text-success'>Оплачено</b>" ?></td>
            </tr>
            <tr>
                <td>Членские взносы- последний оплаченный квартал</td>
                <td>
                    <b class="text-info"><?= TimeHandler::getFullFromShortQuarter($cottageInfo->globalInfo->membershipPayFor) ?></b>
                </td>
            </tr>
            <tr>
                <td>Целевые платежи</td>
                <td><?= $cottageInfo->globalInfo->targetDebt > 0 ? "<a class='btn btn-default detail-debt' data-type='target' href='#'><b class='text-danger'>Задолженность {$cottageInfo->globalInfo->targetDebt} &#8381;</b></a>" : "<b class='text-success'>Оплачено</b>" ?></td>
            </tr>
            <tr>
                <td>Разовые платежи</td>
                <td><?= $cottageInfo->globalInfo->singleDebt > 0 ? "<a class='btn btn-default detail-debt' data-type='single' href='#'><b class='text-danger'>Задолженность {$cottageInfo->globalInfo->singleDebt} &#8381;</b></a>" : "<b class='text-success'>Оплачено</b>" ?></td>
            </tr>
            </tbody>
            <tr>
                <td>Итоговая задолженность</td>
                <td><?= $cottageInfo->totalDebt > 0 ? "<b class='text-danger'>{$cottageInfo->totalDebt} &#8381;</b>" : "<b class='text-success'>Отсутствует</b>" ?></td>
            </tr>
            <tr>
                <td>Депозит участка</td>
                <td><b class="text-info"><?= $cottageInfo->globalInfo->deposit ?> &#8381;</b></td>
            </tr>
            <tr>
                <td>Площадь участка</td>
                <td><b class="text-info"><?= $cottageInfo->globalInfo->cottageSquare ?> м<sup>2</sup></b></td>
            </tr>
        </table>


        <?php
        if ($cottageInfo->globalInfo->haveAdditional) {
        ?>

        <table class="table table-hover">
            <caption>Дополнительный участок</caption>
            <tbody>

            <?php

            if ($cottageInfo->additionalCottageInfo['cottageInfo']->individualTariff){
                echo '
                <tr>
                <td colspan="2"><b class="text-primary">Дополнительному участку подключён индивидуальный тариф</b></td>
                </tr>
                ';
            }

            if ($cottageInfo->additionalCottageInfo['cottageInfo']->isPower) {
            ?>

            <tr class="info">
                <td>Электроэнергия</td>
                <td><?= $cottageInfo->additionalCottageInfo['cottageInfo']->powerDebt > 0 ? "<a class='btn btn-default detail-debt' data-type='power_additional' href='#'><b class='text-danger'>Задолженность {$cottageInfo->additionalCottageInfo['cottageInfo']->powerDebt} &#8381;</b></a>" : "<b class='text-success'>Оплачено</b>" ?></td>
            </tr>
            <tr class="info">
                <td>Электроэнергия- последний оплаченный месяц</td>
                <td>
                    <b class="text-info"><?= TimeHandler::getFullFromShotMonth($cottageInfo->additionalCottageInfo['cottageInfo']->powerPayFor) ?></b> <?= $cottageInfo->additionalCottageInfo['powerStatus']['powerPayDifference'] ?>
                </td>
            </tr>
            <tr class="info">
                <td>Электроэнергия- последние показания счётчика</td>
                <td><b class="text-info"><?= $cottageInfo->additionalCottageInfo['cottageInfo']->currentPowerData ?> кВт.ч</b>
                    <?= $cottageInfo->powerDataAdditionalCancellable ? "<button id='cancelFillAdditionalPower' class='btn btn-danger'>Удалить</button>" : '' ?>
                </td>
            </tr>

            <?php
            }
            else{

                ?>

                <tr class="info">
                    <td>Электроэнергия</td>
                    <td>Участок не электрифицирован</td>
                </tr>

            <?php
            }
            if ($cottageInfo->additionalCottageInfo['cottageInfo']->isMembership) {
                ?>

                <tr class="info">
                    <td>Членские взносы</td>
                    <td><?= $cottageInfo->additionalCottageInfo['membershipDebt'] > 0 ? "<a class='btn btn-default detail-debt' data-type='membership_additional' href='#'><b class='text-danger'>Задолженность {$cottageInfo->additionalCottageInfo['membershipDebt']} &#8381;</b></a>" : "<b class='text-success'>Оплачено</b>" ?></td>
                </tr>
                <tr class="info">
                    <td>Членские взносы- последний оплаченный квартал</td>
                    <td>
                        <b class="text-info"><?= TimeHandler::getFullFromShortQuarter($cottageInfo->additionalCottageInfo['cottageInfo']->membershipPayFor) ?></b>
                    </td>
                </tr>
                <?php
            }
            else{
            ?>
                <tr class="info">
                    <td>Членские взносы</td>
                    <td>Членские взносы за участок не оплачиваются</td>
                </tr>
            <?php
            }
            if ($cottageInfo->additionalCottageInfo['cottageInfo']->isTarget) {
                ?>
                <tr class="info">
                    <td>Целевые платежи</td>
                    <td><?= $cottageInfo->additionalCottageInfo['targetDebt'] > 0 ? "<a class='btn btn-default detail-debt' data-type='target_additional' href='#'><b class='text-danger'>Задолженность {$cottageInfo->additionalCottageInfo['targetDebt']} &#8381;</b></a>" : "<b class='text-success'>Оплачено</b>" ?></td>
                </tr>
                <?php
            }
            else {

                ?>
                <tr class="info">
                    <td>Целевые платежи</td>
                    <td>Целевые платежи за участок не оплачиваются</td>
                </tr>

                <?php
            }
            $fullDuty = CashHandler::toRubles($cottageInfo->additionalCottageInfo['totalDebt']) + CashHandler::toRubles($cottageInfo->totalDebt);
            ?>
                </tbody>
                <tr class="info">
                    <td>Итоговая задолженность дополнительного участка</td>
                    <td><?= $cottageInfo->additionalCottageInfo['totalDebt'] > 0 ? "<b class='text-danger'>{$cottageInfo->additionalCottageInfo['totalDebt']} &#8381;</b>" : "<b class='text-success'>Отсутствует</b>" ?></td>
                </tr>
                <tr class="info">
                    <td>Общая задолженность обоих участков</td>
                    <td><?= $fullDuty > 0 ? "<b class='text-danger'>{$fullDuty} &#8381;</b>" : "<b class='text-success'>Отсутствует</b>" ?></td>
                </tr>
                <tr class="info">
                    <td>Площадь дополнительного участка участка</td>
                    <td><b class="text-info"><?= $cottageInfo->additionalCottageInfo['cottageInfo']->cottageSquare ?> м<sup>2</sup></b></td>
                </tr>
            </table>

            <?php

        }
        if (empty($cottageInfo->globalInfo->cottageHaveRights)) {
            echo "<div class='alert alert-warning'>Нет документов на участок.</div>";
        }
        if (!$cottageInfo->filledPower) {
            echo "<div class='alert alert-info'>Не заполнены показания счётчика электричества за предыдущий месяц!</div>";
        }
        if (isset($cottageInfo->additionalCottageInfo['powerStatus']['lastPowerFillDate']) && !$cottageInfo->additionalCottageInfo['powerStatus']['filledPower']) {
            echo "<div class='alert alert-info'>Не заполнены показания счётчика электричества дополнительного участка за предыдущий месяц!</div>";
        }
        if ($cottageInfo->unpayedBills) {
            echo "<div class='alert alert-danger'>Имеется неоплаченный счёт.</div>";
        }
        ?>
        <div class="row">
            <div class="col-lg-6">
                <table class="table table-striped table-hover">
                    <caption>Информация о владельце</caption>
                    <tbody>
                    <tr>
                        <td>Владелец</td>
                        <td><?= $cottageInfo->globalInfo->cottageOwnerPersonals ?></td>
                    </tr>
                    <tr>
                        <td>Телефон владельца</td>
                        <td><?= $cottageInfo->globalInfo->cottageOwnerPhone ? "<a href='tel:{$cottageInfo->globalInfo->cottageOwnerPhone}'>{$cottageInfo->globalInfo->cottageOwnerPhone}<br/>
<a href='viber://chat?number={$cottageInfo->globalInfo->cottageOwnerPhone}'><img class='social-button' src='/graphics/viber.png'>" : 'Отсутствует' ?></td>
                    </tr>
                    <tr>
                        <td>Адрес электронной почты владельца</td>
                        <td><?= $cottageInfo->globalInfo->cottageOwnerEmail ? "<a href='mailto:{$cottageInfo->globalInfo->cottageOwnerEmail}'>{$cottageInfo->globalInfo->cottageOwnerEmail}" : 'Отсутствует' ?></td>
                    </tr>
                    <tr>
                        <td>Почтовый адрес</td>
                        <td><?= GrammarHandler::clearAddress($cottageInfo->globalInfo->cottageOwnerAddress) ?: 'Отсутствует' ?></td>
                    </tr>
                    <tr>
                        <td>Информация о владельце</td>
                        <td><?= $cottageInfo->globalInfo->cottageOwnerDescription ?: 'Отсутствует' ?></td>
                    </tr>
                    </tbody>
                </table>
            </div>
            <div class="col-lg-6">
                <table class="table table-striped table-hover">
                    <caption>Информация о контактном лице</caption>
                    <tbody>
                    <?php
                    if (!empty($cottageInfo->globalInfo->cottageContacterPersonals)) {
                        ?>
                        <tr>
                            <td>Контактное лицо</td>
                            <td><?= $cottageInfo->globalInfo->cottageContacterPersonals ?></td>
                        </tr>
                        <tr>
                            <td>Телефон контактного лица</td>
                            <td><?= $cottageInfo->globalInfo->cottageContacterPhone ? "<a href='tel:{$cottageInfo->globalInfo->cottageContacterPhone}'>{$cottageInfo->globalInfo->cottageContacterPhone}" : 'Отсутствует' ?></td>
                        </tr>
                        <tr>
                            <td>Адрес электронной почты контактного лица</td>
                            <td><?= $cottageInfo->globalInfo->cottageContacterEmail ? "<a href='mailto:{$cottageInfo->globalInfo->cottageContacterEmail}'>{$cottageInfo->globalInfo->cottageContacterEmail}" : 'Отсутствует' ?></td>
                        </tr>
                        <?php
                    } else {
                        echo '<tr><td>Отсутствует</td></tr>';
                    }
                    ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="col-lg-6">
            <h2>Основные действия</h2>
            <div class="btn-group-vertical">
                <?php
                if ($cottageInfo->unpayedBills) {
                    echo "<button id='handleUnpayedBtn' data-identificator='{$cottageInfo->unpayedBills->id}' class='btn btn-success' type='button'>Завершить оформление выставленного счёта</button>";
                }
                else {
                    echo "<button id='payForCottageButton' class='btn btn-success'>Оплатить</button>";
                }
                ?>

                <button id="buttonShowPaymentsStory" class="btn btn-default">История платежей</button>

                <button id="createSinglePayButton" class="btn btn-primary">Создать разовый платёж</button>


                <?php
                if ($cottageInfo->globalInfo->individualTariff) {
                    echo "<button class='btn btn-lg btn-info' id='indivTariffOffBtn'>Деактивировать индивидуальный тарифный план</button><br/>";
                    echo "<p><div class='btn-group-vertical'><button class='btn btn-info' id='showPersonalTariff'>Просмотреть данные тарифа</button>";
                    echo "<button class='btn btn-primary' id='editPersonalTariff'>Редактировать данные тарифа</button></div></p>";
                } else {
                    echo "<button class='btn btn-warning' id='indivTariffBtn'>Активировать индивидуальный тарифный план</button>";
                }
                if ($cottageInfo['globalInfo']->haveAdditional) {
	                if ($cottageInfo->additionalCottageInfo['cottageInfo']->individualTariff) {
		                echo "<button class='btn btn-lg btn-info' id='additionalIndivTariffOffBtn'>Деактивировать индивидуальный тарифный план (доп.)</button><br/>";
		                echo "<p><div class='btn-group-vertical'><button class='btn btn-info' id='showAdditionalPersonalTariff'>Просмотреть данные тарифа (доп.)</button>";
		                echo "<button class='btn btn-primary' id='editAdditionalPersonalTariff'>Редактировать данные тарифа (доп.)</button></div></p>";
	                }
	                else{
		                echo "<button class='btn btn-warning' id='additionalIndivTariffBtn'>Активировать индивидуальный тариф доп. участка</button><br/>";
                    }
                } else {
                    echo '<button id="createAdditionalCottage" class="btn btn-info">Зарегистрировать дополнительный участок</button>';
                }
                ?>
            </div>
        </div>
        <div class="col-lg-6">
            <h2>Различные действия</h2>
            <div class="btn-group-vertical">
                <button id="changePowerCounter" class="btn btn-danger">Заменён счётчик электроэнергии</button>
                <button id="sendNotificationBtn" class="btn btn-info">Отправить напоминание о долгах</button>
                <button id="sendRegInfoNotificationBtn" class="btn btn-info">Отправить напоминание о регистрационных
                    данных
                </button>
                <button id="showReports" class="btn btn-info">Отчёт о платежах</button>
            </div>
        </div>
    </div>
</div>
