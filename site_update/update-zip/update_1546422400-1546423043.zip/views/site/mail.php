<?php


\app\assets\IndexAsset::register($this);

use app\models\PowerHandler;
use app\models\TimeHandler;
//
//print_r(TimeHandler::getYearStartAndFinish('2018'));
//echo '<br/>';
//print_r(TimeHandler::getMonthStartAndFinish('2018-11'));
//echo '<br/>';
//print_r(TimeHandler::getDayStartAndFinish('2018-11-1'));
//echo '<br/>';
//print_r(TimeHandler::getPrevMonth('2018-01'));
//echo '<br/>';
//print_r(TimeHandler::getNextMonth('2018/12'));
//echo '<br/>';
//print_r(TimeHandler::isDay('2018 11 30'));
//echo '<br/>';
//print_r(TimeHandler::isMonth('2018 12'));
//echo '<br/>';
//print_r(TimeHandler::isYear('2990'));
//echo '<br/>';
//print_r(TimeHandler::isQuarter('2990 1'));
//echo '<br/>';
//print_r(TimeHandler::getQuarterShift('2'));
//echo '<br/>';
//print_r(TimeHandler::checkMonthDifference('2020-10', '2020-10'));
//echo '<br/>';
//print_r(TimeHandler::getMonthsList('2018-10'));
//echo '<br/>';
//print_r(TimeHandler::getQuarterList('2019-3'));
//echo '<br/>';

//echo \app\models\CashHandler::toRubles('  -1,3', true);
//echo TimeHandler::checkQuarterDifference('2020-4');
//print_r(\app\models\MembershipHandler::getTariffs(['start' => '2018-1']));
//app\models\PowerHandler::getTariff('2018-11');'
//echo "'" . \app\models\GrammarHandler::clearWhitespaces('  П  р  и            в      е        т  ! ') . "'";
//print_r(\app\models\MembershipHandler::getTariffs(['start' => '2018-3', 'finish' => TimeHandler::getCurrentQuarter()]));
print_r(TimeHandler::getQuarterList(['start' => '2020-1', 'finish' => '2018-4']));