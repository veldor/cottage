<?php

/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 26.09.2018
 * Time: 16:06
 */

/* @var $this \yii\web\View */
/* @var $model \app\models\Filling */
use app\assets\FillingAsset;
use nirvana\showloading\ShowLoadingAsset;
use app\widgets\AllCottagesWidget;

/* @var $this yii\web\View */
FillingAsset::register($this);
ShowLoadingAsset::register($this);

$this->title = 'Массовое заполнение форм';
/** @var array $info */
?>
<div class="row show-grid small-text">
    <?=AllCottagesWidget::widget(['info' => $info]);?>
</div>
