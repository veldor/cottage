<?php

return [
//    AUTH BLOCK
	'login' => 'auth/login', // Форма входа на сайт
	'logout' => 'auth/logout', // Выход из учётной записи
//    END AUTH BLOCK
//    COTTAGE BLOCK
	'add-cottage' => 'cottage/add',
	'add-cottage/<cottageNumber:[0-9]+>' => 'cottage/add',
	'create/additional-cottage/<cottageNumber:[0-9]+>' => 'cottage/additional',
	'save/additional-cottage/<cottageNumber:[0-9]+>' => 'cottage/additional-save',
	'change-cottage/<cottageNumber:[0-9]+>' => 'cottage/change',
	'change-cottage' => 'cottage/change',
	'add-cottage/save/<type:add|change>' => 'cottage/save',
	'show-cottage/<cottageNumber:[0-9]+>' => 'cottage/show',
//    END COTTAGE BLOCK
//    TARRIFS BLOCK
//    END TARRIFS BLOCK
//    PAYMENTS BLOCK
	'payment/get-form/<type:complex|single>/<cottageNumber:[0-9]+>' => 'payments/form', // используется
	'payment/validate/single' => 'payments/validate-single',
	'payment/get/<type:power|membership|target|complex>/<cottageNumber:[0-9]+>' => 'payments/history',
	//'payment/<type:power|membership|target|complex>/<cottageNumber:[0-9]+>' => 'payments/form',
	'payment/<type:single|complex>/save' => 'payments/save',
	'invoice/show/<invoiceId:[0-9]+>' => 'payments/invoice-show',
	'show/previous/power/<cottageNumber:[0-9]+>' => 'payments/show-previous',


//    END PAYMENTS BLOCK

//    MANAGEMENT BLOCK
	'update/create/form' => 'management/get-update-form',
	'update/validate' => 'management/validate-update',
	'update/create' => 'management/create-update',
	'updates/check' => 'management/check-update',
	'updates/install' => 'management/install-update',
//    END MANAGEMENT BLOCK
//    GLOBAL FILL BLOCK
//    'create/<type:payment>/<purpose:target>' => 'filling/create',
	'fill/<type:power>/<cottageNumber:[0-9]+>' => 'filling/fill', // используется
//    'fill/<type:membership>/<period:quarter>' => 'tariffs/fill',
//    'fill/<type:target>/<period:year>' => 'tariffs/fill',
	'fill/<type:membership>/<period:\d{4}-[1-4]{1}>' => 'tariffs/fill', // используется, заполнение ставок по членским взносам
	'fill/<type:membership-personal|membership-personal-additional>/<cottageNumber:[0-9]+>/<period:\d{4}-[1-4]{1}>' => 'tariffs/fill-personal', // используется, заполнение ставок по членским взносам
//    'fill/<type:target>/<period:\d{4}>' => 'tariffs/fill',
//    END GLOBAL FILL BLOCK
//    CHECKS BLOCK
	'check/<type:membership>/interval/<from:\d{4}-[1-4]{1}>' => 'tariffs/check',
	'check/<type:target>/interval/<from:\d{4}>' => 'tariffs/check',
//    END CHECKS BLOCK
//    MEMBERSHIP BLOCK
	'pay/<type:single>/<cottageNumber:[0-9]+>' => 'payments/validate-payment',
	'get/future-quarters/<quartersNumber:\d+>/<cottageNumber:[0-9]+>' => 'filling/future-quarters',
	'get/future-quarters/<additional:additional>/<quartersNumber:\d+>/<cottageNumber:[0-9]+>' => 'filling/future-quarters',
//    END MEMBERSHIP BLOCK

//    COMPLEX PAYMENT BLOCK
	'create/payment/complex/<cottageNumber:[0-9]+>' => 'payments/create-complex',
	'get-info/bill/<identificator:[0-9]+>' => 'payments/bill-info',
	'invoice/<identificator:[0-9]+>' => 'payments/print-invoice',
	'send-invoice/<identificator:[0-9]+>' => 'payments/send-invoice',
	'bill/delete/<identificator:[0-9]+>' => 'payments/delete-bill',
	'bill/save/<type:cash|no-cash>/<identificator:[0-9]+>' => 'payments/save-bill',
	'get/bills/<cottageNumber:[0-9]+>' => 'payments/get-bills',
	'get-form/pay/cash/<identificator:[0-9]+>' => 'payments/get-pay-confirm-form',
	'pay/cash/check/<identificator:[0-9]+>' => 'payments/validate-cash',
	'pay/cash/confirm/<identificator:[0-9]+>' => 'payments/confirm-cash',
//    END COMPLEX PAYMENT BLOCK
	'get-form/change/<cottageNumber:[0-9]+>' => 'cottage/change',
//    NOTIFIER BLOCK======================================================================================
	'send/duties/<cottageNumber:[0-9]+>' => 'notify/duties',
	'send/reg-info/<cottageNumber:[0-9]+>' => 'notify/reg-info',
	'send/pay/<billId:[0-9]+>' => 'notify/pay',
	'notifications/check-unsended' => 'notify/check-unsended',

//    END NOTIFIER BLOCK==================================================================================
//    SERVICES BLOCK======================================================================================
	'service/change-counter/<cottageNumber:[0-9]+>' => 'service/change-counter',
//    END SERVICES BLOCK==================================================================================
//    BALANCE BLOCK======================================================================================
	'balance/show/<type:day-in|month-in|year-in|day-out|month-out|year-out>' => 'count/show',
	'balance/show-transactions/<type:day|month|year>' => 'count/show-transactions',
	'balance/show-summary/<type:day|month|year>' => 'count/show-summary',
//    END BALANCE BLOCK==================================================================================
	'power/cancel-previous/<cottageNumber:[0-9]+>' => 'filling/cancel-power',
	'power/cancel-previous/<additional:additional>/<cottageNumber:[0-9]+>' => 'filling/cancel-power',

	'print/cottage-report/<start:[0-9]+>/<end:[0-9]+>/<cottageNumber:[0-9]+>' => 'print/cottage-report',
	'tariff/personal/enable/<cottageNumber:[0-9]+>' => 'tariffs/make-personal',
	'tariff/personal/enable/additional/<cottageNumber:[0-9]+>' => 'tariffs/make-additional-personal',
	'tariff/personal/disable/<cottageNumber:[0-9]+>' => 'tariffs/disable-personal',
	'tariff/personal/change/<cottageNumber:[0-9]+>' => 'tariffs/change-personal',
	'show/personal-tariff/<cottageNumber:[0-9]+>' => 'tariffs/show-personal',
	'show/debt/detail/<type:power|membership|target|single|power_additional|membership_additional|target_additional>/<cottageNumber:[0-9]+>' => 'report/debt-details',
	'search' => 'search/search',
];