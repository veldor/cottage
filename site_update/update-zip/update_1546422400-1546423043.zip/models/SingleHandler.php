<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 15.12.2018
 * Time: 13:51
 */

namespace app\models;


use yii\base\InvalidArgumentException;
use yii\base\Model;

class SingleHandler extends Model {
	public $cottageNumber;
	public $summ;
	public $description;

	const SCENARIO_NEW_DUTY = 'new_duty';


	public function scenarios(): array
	{
		return [
			self::SCENARIO_NEW_DUTY => ['cottageNumber', 'summ', 'description'],
		];
	}

	public function __construct(array $config = [])
	{
		parent::__construct($config);
		if (!empty($config['attributes'])) {
			$this->cottageNumber = $config['attributes']['cottageNumber'];
		}
	}

	public function attributeLabels(): array
	{
		return [
			'summ' => 'Сумма платежа',
			'description' => 'Назначение платежа',
		];
	}

	public function rules(): array
	{
		return [
			[['cottageNumber', 'summ'], 'required', 'on' => self::SCENARIO_NEW_DUTY],
			['summ', 'checkCost'],
			['description', 'string', 'max' => 500],
		];
	}

	public function checkCost($attribute)
	{
		try {
			$this->$attribute = CashHandler::toRubles($this->$attribute);
		} catch (InvalidArgumentException $e) {
			$this->addError($attribute, $e->getMessage());
		}
	}

	/**
	 * @return array
	 */
	public function insert(): array
	{
		$description = urlencode($this->description);
		$time = time();
		$cottage = Cottage::getCottageInfo($this->cottageNumber);
		// добавлю сведения о платеже в поле;
		if (!empty($cottage->singlePaysDuty)) {
			// если уже есть платежи- добавлю ещё один
			$dom = new \DOMDocument('1.0', 'UTF-8');
			$dom->loadXML($cottage->singlePaysDuty);
			$elem = $dom->createElement('singlePayment');
			$elem->setAttribute('time', $time);
			$elem->setAttribute('payed', '0');
			$elem->setAttribute('summ', $this->summ);
			$elem->setAttribute('description', $description);
			$dom->documentElement->appendChild($elem);
			$data = html_entity_decode($dom->saveXML($dom->documentElement));
			$cottage->singlePaysDuty = $data;
		}
		else {
			// если платежей нет- создам
			$content = "<singlePayments><singlePayment time='{$time}' payed='0' summ='{$this->summ}' description='{$description}'/></singlePayments>";
			$cottage->singlePaysDuty = $content;
		}
		$cottage->singleDebt += CashHandler::toRubles($this->summ);
		$cottage->save();
		return ['status' => 1];
	}

	/**
	 * @param $cottage int|string|Table_cottages
	 * @return array
	 */
	public static function getDebtReport($cottage): array
	{
		$answer = [];
		if (!is_object($cottage)) {
			$cottage = Cottage::getCottageInfo($cottage);
		}
		if (!empty($cottage->singlePaysDuty)) {
			$targetDom = new \DOMDocument('1.0', 'UTF-8');
			$targetDom->loadXML($cottage->singlePaysDuty);
			$targetXpath = new \DOMXpath($targetDom);
			$pays = $targetXpath->query('/singlePayments/singlePayment');
			/**
			 * @var  $pay \DOMElement
			 */
			foreach ($pays as $pay) {
				$time = $pay->getAttribute('time');
				$answer[$time]['summ'] = CashHandler::toRubles($pay->getAttribute('summ'));
				$answer[$time]['payed'] = CashHandler::toRubles($pay->getAttribute('payed'));
				$answer[$time]['description'] = urldecode($pay->getAttribute('description'));
			}
		}
		return $answer;
	}

	public static function createPayment($cottageInfo, $target): array
	{
		$answer = '';
		$summ = 0;
		$debt = self::getDebtReport($cottageInfo);
		foreach ($target as $key => $value) {
			if (!empty($value)) {
				$pay = CashHandler::toRubles($value);
				if ($value > 0) {
					if (!empty($debt[$key])) {
						if ($pay > $debt[$key]['summ']) {
							throw new InvalidArgumentException('Сумма платежа превышает сумму задолженности');
						}
						$summ += $pay;
						$leftPay = CashHandler::toRubles($debt[$key]['summ']) - $pay - CashHandler::toRubles($debt[$key]['payed']);
						$answer .= "<pay timestamp='$key' payed='{$pay}' summ='{$debt[$key]['summ']}' payed-before='{$debt[$key]['payed']}' left-pay='{$leftPay}'/>";

					}
					else {
						throw new InvalidArgumentException('Счёт не найден в списке задолженностей');
					}
				}
			}
		}
		if ($summ > 0) {
			$summ = CashHandler::toRubles($summ);
			$answer = "<single cost='{$summ}'>" . $answer . '</single>';
		}
		else {
			$answer = '';
		}
		return ['text' => $answer, 'summ' => $summ];
	}

	public static function registerPayment($cottageInfo, $billInfo, $payments)
	{
		$dom = DOMHandler::getDom($cottageInfo->singlePaysDuty);
		$xpath = DOMHandler::getXpath($dom);
		// зарегистрирую платежи
		foreach ($payments['values'] as $payment) {
			$summ = CashHandler::toRubles($payment['payed']);
			$pay = $xpath->query("/singlePayments/singlePayment[@time='{$payment['timestamp']}']");
			$attrs = DOMHandler::getElemAttributes($pay->item(0));
			$payed = CashHandler::toRubles($attrs['payed']);
			$fullSumm = CashHandler::toRubles($attrs['summ']);
			if ($fullSumm === $summ + $payed) {
				// долг оплачен полностью, удаляю его из списка долгов
				$pay->item(0)->parentNode->removeChild($pay->item(0));
			}
			else {
				$pay->item(0)->setAttribute('payed', $summ + $payed);
			}
			$cottageInfo->singleDebt -= $summ;
			$cottageInfo->singlePaysDuty = DOMHandler::saveXML($dom);
			self::insertPayment($cottageInfo, $billInfo, $payment);
		}
	}

	public static function insertPayment($cottageInfo, $billInfo, $payment)
	{
		if ($payment['summ'] > 0) {
			$write = new Table_payed_single();
			$write->cottageId = $cottageInfo->cottageNumber;
			$write->billId = $billInfo->id;
			$write->time = $payment['timestamp'];
			$write->summ = CashHandler::toRubles($payment['payed']);
			$write->paymentDate = $billInfo->paymentTime;
			$write->save();
		}
	}
}