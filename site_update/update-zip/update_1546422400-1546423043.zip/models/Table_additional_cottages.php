<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 13.12.2018
 * Time: 8:54
 */

namespace app\models;


use yii\db\ActiveRecord;

class Table_additional_cottages extends Table_cottages
{
    public static function tableName()
    {
        return 'additional_cottages';
    }
}