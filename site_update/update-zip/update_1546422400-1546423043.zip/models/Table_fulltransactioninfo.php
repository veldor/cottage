<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 05.12.2018
 * Time: 8:26
 */

namespace app\models;


use yii\db\ActiveRecord;

class Table_fulltransactioninfo extends ActiveRecord
{
    public static function tableName()
    {
        return 'fulltransactioninfo';
    }
}