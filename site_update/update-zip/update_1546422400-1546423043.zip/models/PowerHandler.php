<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 13.12.2018
 * Time: 13:35
 */

namespace app\models;


use app\validators\CashValidator;
use app\validators\CheckCottageNoRegistred;
use app\validators\CheckMonthValidator;
use yii\base\ErrorException;
use yii\base\InvalidArgumentException;
use yii\base\InvalidValueException;
use yii\base\Model;

class PowerHandler extends Model
{
    const SCENARIO_NEW_RECORD = 'new_record';
    const SCENARIO_NEW_TARIFF = 'new_tariff';

	public static function cancelPowerFill($cottageNumber, $additional)
	{
		if($additional){
			$cottage = AdditionalCottage::getCottage($cottageNumber);
		}
		else{
			$cottage = Cottage::getCottageInfo($cottageNumber);
		}
		$data = self::getMonthInfo($cottage, TimeHandler::getPreviousShortMonth());
		$cottage->powerDebt = CashHandler::toRubles($cottage->powerDebt - $data->totalPay);
		$cottage->currentPowerData = $data->oldPowerData;
		$cottage->save();
		$data->delete();
		return ['status' => 1];
	}

	/**
	 * @param $cottage Table_cottages|Table_additional_cottages
	 * @param $period
	 * @return Table_additional_power_months|Table_power_months
	 */
	private static function getMonthInfo($cottage, $period)
	{
		if(get_class($cottage) === 'app\models\Table_cottages'){
			$data = Table_power_months::findOne(['cottageNumber' => $cottage->cottageNumber, 'month' => $period]);
		}
		else{
			$data = Table_additional_power_months::findOne(['cottageNumber' => $cottage->masterId, 'month' => $period]);
		}
		if(!empty($data)){
			return $data;
		}
		throw new InvalidArgumentException('Данные за месяц не заполнены');
	}


	public function scenarios(): array
    {
        return [
            self::SCENARIO_NEW_RECORD => ['cottageNumber', 'month', 'newPowerData', 'additional'],
            self::SCENARIO_NEW_TARIFF => ['month', 'powerCost', 'powerOvercost', 'powerLimit'],
        ];
    }

    public $cottageNumber;
    public $month;
    public $newPowerData;
    public $additional = false;

    public $powerCost;
    public $powerOvercost;
    public $powerLimit;

    public $currentCondition;

    public function rules(): array
    {
        return [
            [['cottageNumber', 'month', 'newPowerData'], 'required', 'on' => self::SCENARIO_NEW_RECORD],
	        [['powerCost', 'powerOvercost', 'month', 'powerLimit'], 'required', 'on' => self::SCENARIO_NEW_TARIFF],
            ['cottageNumber', CheckCottageNoRegistred::class],
            ['month', CheckMonthValidator::class],
            ['additional', 'boolean'],
            ['cottageNumber', 'integer', 'min' => 1, 'max' => 300],
            [['newPowerData', 'powerLimit'], 'integer', 'min' => 0],
	        [['powerCost', 'powerOvercost'], CashValidator::class],
        ];
    }

    public function __construct(array $config = [])
    {
        parent::__construct($config);
        if (!empty($config['attributes'])) {
            $this->cottageNumber = $config['attributes']['cottageNumber'];
            $this->month = $config['attributes']['month'];
            $this->newPowerData = $config['attributes']['newPowerData'];
            if ($config['attributes']['additional'] === true) {
                $this->additional = true;
            }
        }
    }

	public function createTariff(): bool
	{
		if($this->validate()){
			// проверю, не заполнен ли уже тариф за месяц
			try{
				self::getRowTariff($this->month);
				throw new InvalidValueException('Тариф на ' . $this->month . ' уже заполнен!');
			}
			catch(InvalidArgumentException $e){
			}
			$newRecord = new Table_tariffs_power();
			$newRecord->targetMonth = $this->month;
			$newRecord->powerLimit = $this->powerLimit;
			$newRecord->powerCost = $this->powerCost;
			$newRecord->powerOvercost = $this->powerOvercost;
			$newRecord->searchTimestamp = TimeHandler::getMonthTimestamp($this->month);
			$newRecord->fullSumm = 0;
			$newRecord->payedSumm = 0;
			$newRecord->paymentInfo = '';
			$newRecord->save();
			self::recalculatePower($this->month);
			return true;
		}
		throw new InvalidArgumentException('Ошибка в данных: ' . serialize($this->errors));
	}

    /**
     * @return array
     * @throws ErrorException
     */
    public function insert(): array
    {
        if ($this->validate()) {
            // проверю, заносились ли уже данные по этому участку
            if ($this->additional) {
                $oldData = Table_additional_power_months::find()->where(['cottageNumber' => $this->cottageNumber])->orderBy('searchTimestamp DESC')->one();
            } else {
                $oldData = Table_power_months::find()->where(['cottageNumber' => $this->cottageNumber])->orderBy('searchTimestamp DESC')->one();
            }
            if (!empty($oldData)) {
                // если уже вносились данные и предыдущий месяц не является последним найденным- заполню предыдущие месяцы нулевыми значениями
                $prev = TimeHandler::getPrevMonth($this->month);
                if ($oldData->month >= $this->month) {
                    throw new ErrorException($prev . ' - данные за этот месяц уже заполнены!');
                }
                if ($oldData->month !== $prev) {
                    $monthsList = TimeHandler::getMonthsList($oldData->month, $prev);
                    foreach ($monthsList as $key => $item) {
                    	$attributes = ['cottageNumber' => $this->cottageNumber, 'month' => $key, 'newPowerData' => $oldData->newPowerData, 'additional' => $this->additional];
                        $power = new PowerHandler(['scenario' => self::SCENARIO_NEW_RECORD, 'attributes' => $attributes]);
                        $power->insert();
                    }
                }
                $oldPowerData = $oldData->newPowerData;
            } else {
                $oldPowerData = (int)$this->newPowerData;
            }
            // расчитаю данные
            $this->newPowerData = (int)$this->newPowerData;
            if ($this->newPowerData < $oldPowerData) {
                throw new InvalidArgumentException('Новые значения не могут быть меньше старых!');
            }
            $fillingDate = time();
            $searchTimestamp = TimeHandler::getMonthTimestamp($this->month);
            $difference = 0;
            $totalPay = 0;
            $inLimitSumm = 0;
            $inLimitPay = 0;
            $overLimitPay = 0;
            $overLimitSumm = 0;
            if ($this->newPowerData > $oldPowerData) {
                $difference = $this->newPowerData - $oldPowerData;
                // получу тариф на электричество по данному месяцу. Если его не существует- исключение незаполненного тарифа
                $tariff = self::getTariff($this->month);
                if ($difference > $tariff[$this->month]['powerLimit']) {
                    $inLimitSumm = $tariff[$this->month]['powerLimit'];
                    $inLimitPay = CashHandler::toRubles($inLimitSumm * $tariff[$this->month]['powerCost']);
                    $overLimitSumm = $difference - $inLimitSumm;
                    $overLimitPay = CashHandler::toRubles($overLimitSumm * $tariff[$this->month]['powerOvercost']);
                    $totalPay = CashHandler::toRubles($inLimitPay + $overLimitPay);
                } else {
                    $inLimitSumm = $difference;
                    $inLimitPay = CashHandler::toRubles($difference * $tariff[$this->month]['powerCost']);
                    $totalPay = $inLimitPay;
                }
            }
            if ($this->additional) {
                $newData = new Table_additional_power_months();
            } else {
                $newData = new Table_power_months();
            }
            $newData->cottageNumber = $this->cottageNumber;
            $newData->month = $this->month;
            $newData->fillingDate = $fillingDate;
            $newData->oldPowerData = $oldPowerData;
            $newData->newPowerData = $this->newPowerData;
            $newData->searchTimestamp = $searchTimestamp;
            $newData->payed = 'no';
            $newData->difference = $difference;
            $newData->totalPay = $totalPay;
            $newData->inLimitSumm = $inLimitSumm;
            $newData->inLimitPay = $inLimitPay;
            $newData->overLimitSumm = $overLimitSumm;
            $newData->overLimitPay = $overLimitPay;

            if ($this->additional) {
                $this->currentCondition = AdditionalCottage::getCottage($this->cottageNumber);
            }
            /**
             * @var $ref Table_cottages
             */
            $ref = $this->currentCondition;
            $ref->powerDebt = CashHandler::toRubles($ref->powerDebt + $totalPay);
            $ref->currentPowerData = $this->newPowerData;
            $newData->save();
            $ref->save();
            self::recalculatePower($this->month);
            return ['status' => 1, 'totalSumm' => $totalPay, 'data' =>$newData];
        }
        throw new InvalidArgumentException('Ошибка в данных: ' . serialize($this->errors));
    }

    /**
     * @param $period string|array
     * @return array
     * @throws ErrorException|InvalidArgumentException
     */
    public static function getTariff($period): array
    {
        $data = [];
        if (is_string($period) && TimeHandler::isMonth($period)) {
            $tariff = Table_tariffs_power::findOne(['targetMonth' => $period]);
            if ($tariff !== null) {
                $data[$tariff->targetMonth] = ['powerLimit' => $tariff->powerLimit, 'powerCost' => $tariff->powerCost, 'powerOvercost' => $tariff->powerOvercost];
            }
            else{
	            throw new ErrorException('Тарифа на данный месяц не существует!');
            }
        }
        if (is_array($period)) {
            $start = TimeHandler::isMonth($period['start']);
            $tariff = Table_tariffs_power::find()->where("targetMonth>{$start['full']}")->all();
            if (!empty($tariff)) {
                foreach ($tariff as $item) {
                    $data[$item->targetMonth] = ['powerLimit' => $item->powerLimit, 'powerCost' => $item->powerCost, 'powerOvercost' => $item->powerOvercost];
                }
            }
            else{
	            throw new ErrorException('Тарифа на данный месяц не существует!');
            }
        }
        return $data;
    }

    public static function getInserted($cottages, $additionalCottages, $period): array
    {
        $answer = [];
        $tariff = self::getTariff($period);
        $answer['tariff'] = $tariff[$period];
        $mainData = self::getPowerData($period);
        $additionalData = self::getAdditionalPowerData($period);
        if (!empty($cottages)) {
            foreach ($cottages as $cottage) {
                $info = [];
                if (!empty($mainData[$cottage->cottageNumber])) {
                    $info['filled'] = true;
                }
                $info['currentData'] = $cottage->currentPowerData;
                if ($cottage->haveAdditional && $additionalCottages[$cottage->cottageNumber]->isPower) {
                    if (!empty($additionalData[$cottage->cottageNumber])) {
                        $info['additionalFilled'] = true;
                    }
                    $info['additionalData'] = $additionalCottages[$cottage->cottageNumber]->currentPowerData;
                }
                $answer['cottages'][$cottage->cottageNumber] = $info;
            }
        }
        return $answer;
    }

    /**
     * @param $cottageInfo Table_cottages
     * @return array
     */
    public static function getCottageStatus($cottageInfo): array
    {
        // проверю, выставлен ли счет на электроэнергию за предыдущий месяц
        $filledPower = Table_power_months::findOne(['cottageNumber' => $cottageInfo->cottageNumber, 'month' => TimeHandler::getPreviousShortMonth()]);
        if ($filledPower === null) {
	        $filledPower = Table_power_months::find()->where(['cottageNumber' => $cottageInfo->cottageNumber])->orderBy('month DESC')->one();
	        $filled = false;
            // проверю, можно ли отменить платёж
        } else {
        	$filled = true;
        }
        // проверю, как давно оплачено электричество
        $difference = TimeHandler::checkMonthDifference($cottageInfo->powerPayFor);
        $powerPayDifference = '';
        if ($difference > 1) {
            $powerPayDifference = '(' . GrammarHandler::handleMonthsDifference(--$difference) . ' назад)';
        }
        return ['filledPower' => $filled, 'lastPowerFillDate' => $filledPower->month, 'powerPayDifference' => $powerPayDifference, 'powerDebt' => $cottageInfo->powerDebt,
        'powerPayed' => $filledPower->payed];
    }

    /**
     * @param $cottageInfo Table_additional_cottages
     * @return array
     */
    public static function getAdditionalCottageStatus($cottageInfo): array
    {
        if ($cottageInfo->isPower) {
            // проверю, выставлен ли счет на электроэнергию за предыдущий месяц
            $filledPower = Table_additional_power_months::findOne(['cottageNumber' => $cottageInfo->masterId, 'month' => TimeHandler::getPreviousShortMonth()]);
            if ($filledPower === null) {
	            $filledPower = Table_additional_power_months::find()->where(['cottageNumber' => $cottageInfo->masterId])->orderBy('month DESC')->one();
	            $filled = false;
            }
            else{
            	$filled = true;
            }
            // проверю, как давно оплачено электричество
            $difference = TimeHandler::checkMonthDifference($cottageInfo->powerPayFor);
            $powerPayDifference = '';
            if ($difference > 1) {
                $powerPayDifference = '(' . GrammarHandler::handleMonthsDifference(--$difference) . ' назад)';
            }
            return ['filledPower' => $filled, 'lastPowerFillDate' => $filledPower->month, 'powerPayDifference' => $powerPayDifference, 'powerDebt' => $cottageInfo->powerDebt, 'powerPayed' => $filledPower->payed];
        }
        return [];
    }

    /**
     * @param $period string|array
     * @return array
     */
    public static function getPowerData($period): array
    {
        $info = null;
        $values = [];
        if (is_string($period)) {
            $info = TimeHandler::isMonth($period);
        }
        $data = Table_power_months::find()->where(['month' => $info['full']])->all();
        if (!empty($data)) {
            if (is_array($data)) {
                foreach ($data as $item) {
                    $values[$item->cottageNumber] = $item;
                }
            } else {
                $values[$data->month] = $data;
            }
        }
        return $values;
    }

    public static function getAdditionalPowerData($period): array
    {
        $info = 'null';
        $values = [];
        if (is_string($period)) {
            $info = TimeHandler::isMonth($period);
        }
        $data = Table_additional_power_months::find()->where(['month' => $info['full']])->all();
        if (!empty($data)) {
            if (is_array($data)) {
                foreach ($data as $item) {
                    $values[$item->cottageNumber] = $item;
                }
            } else {
                $values[$data->month] = $data;
            }
        }
        return $values;
    }

    /**
     * @param $cottage int|string|Table_cottages|Table_additional_cottages
     * @param bool $additional
     * @return array
     * @throws ErrorException
     */
    public static function getDebtReport($cottage, $additional = false): array
    {
        $query = null;
        if ($additional) {
            if (!is_object($cottage)) {
                $cottage = AdditionalCottage::getCottage($cottage);
            }
            if (!$cottage->isPower) {
                return [];
            }
            $query = Table_additional_power_months::find()->where(['cottageNumber' => $cottage->masterId]);
        } else {
            if (!is_object($cottage)) {
                $cottage = Cottage::getCottageInfo($cottage);
            }
            $query = Table_power_months::find()->where(['cottageNumber' => $cottage->cottageNumber]);
        }
        $tariffs = self::getTariff(['start' => $cottage->powerPayFor]);
        $rates = $query->andWhere(['>', 'month', $cottage->powerPayFor])->orderBy('searchTimestamp')->all();
        $answer = [];
        if (!empty($rates)) {
            foreach ($rates as $rate) {
                foreach ($rate as $key => $value) {
                    $answer[$rate->month][$key] = $value;
                }
                if ($rate->difference > 0) {
                    foreach ($tariffs[$rate->month] as $key => $value) {
                        $answer[$rate->month][$key] = $value;
                    }
                }
            }
        }
        return $answer;
    }

    /**
     * @param $cottage Table_cottages|Table_additional_cottages|int|string
     * @param $powerPeriods int|string
     * @param $corrected string
     * @param bool $additional
     * @return array|string
     * @throws ErrorException
     */
    public static function createPayment($cottage, $powerPeriods, $corrected, $additional = false)
    {
        if ($additional) {
            if (!is_object($cottage)) {
                $cottage = AdditionalCottage::getCottage($cottage);
            }
            if (!$cottage->isPower) {
                return [];
            }
        } else if (!is_object($cottage)) {
            $cottage = Cottage::getCottageInfo($cottage);
        }
        // получу все задолженности
        $duty = self::getDebtReport($cottage, $additional);
        if (!empty($corrected)) {
            $noLimArr = array_flip(explode(' ', trim($corrected)));
        }
        $answer = '';
        $summ = 0;
        if (!empty($duty)) {
            foreach ($duty as $key => $value) {
                if ($powerPeriods === 0) {
                    break;
                }
                if ($value['difference'] > 0) {
                    if (isset($noLimArr[$key])) {
                    	$payWithLimit = "pay-with-limit='{$value['totalPay']}'";
                        $correctedSumm = $value['difference'] * CashHandler::toRubles($value['powerOvercost']);

                        $summ += $correctedSumm;
                        $answer .= "<month date='$key' summ='{$correctedSumm}' old-data='{$value['oldPowerData']}' new-data='{$value['newPowerData']}' powerLimit='0' powerCost='{$value['powerCost']}' in-limit-cost='0' in-limit='0' powerOvercost='{$value['powerOvercost']}' difference='{$value['difference']}' over-limit='{$value['difference']}' over-limit-cost='{$correctedSumm}' corrected='1' $payWithLimit/>";
                    } else {
                        $answer .= "<month date='$key' summ='{$value['totalPay']}' old-data='{$value['oldPowerData']}' new-data='{$value['newPowerData']}' powerLimit='{$value['powerLimit']}' powerCost='{$value['powerCost']}' powerOvercost='{$value['powerOvercost']}' difference='{$value['difference']}' in-limit='{$value['inLimitSumm']}' over-limit='{$value['overLimitSumm']}' in-limit-cost='{$value['inLimitPay']}' over-limit-cost='{$value['overLimitPay']}' corrected='0'/>";
                        $summ += $value['totalPay'];
                    }
                } else {
                    $answer .= "<month date='$key' summ='0' new-data='{$value['newPowerData']}' difference='0'/>";
                }
                --$powerPeriods;
            }
            if ($additional) {
                $answer = /** @lang xml */
                    "<additional_power cost='{$summ}'>" . $answer . '</additional_power>';
            } else {
                $answer = /** @lang xml */
                    "<power cost='{$summ}'>" . $answer . '</power>';
            }
        }
        return ['text' => $answer, 'summ' => CashHandler::toRubles($summ)];
    }

	/**
	 * @param $cottageInfo Table_cottages|Table_additional_cottages
	 * @param $billInfo Table_payment_bills
	 * @param $payments array
	 * @param $additional boolean
	 */
	public static function registerPayment($cottageInfo, $billInfo, $payments, $additional = false)
	{
		// зарегистрирую платежи
		$realSumm = 0;
		foreach ($payments['values'] as $payment){
			self::insertPayment($payment, $cottageInfo, $billInfo, $additional);
			if(!empty($payment['corrected']) && $payment['corrected'] === '1'){
				$realSumm += CashHandler::toRubles($payment['pay-with-limit']);
			}
			else{
				$realSumm += CashHandler::toRubles($payment['summ']);
			}
		}
		$cottageInfo->powerPayFor = end($payments['values'])['date'];
		$cottageInfo->powerDebt -= $realSumm;
	}
	public static function insertPayment($payment, $cottageInfo, $billInfo, $additional = false){
		if($payment['summ'] > 0){
			if($additional){
				$cottageId = $cottageInfo->masterId;
				$write = new Table_additional_payed_power();
				$write->cottageId = $cottageInfo->masterId;
			}
			else{
				$cottageId = $cottageInfo->cottageNumber;
				$write = new Table_payed_power();
				$write->cottageId = $cottageInfo->cottageNumber;
			}
			$write->billId = $billInfo->id;
			$write->month = $payment['date'];
			$write->summ = CashHandler::toRubles($payment['summ']);
			$write->paymentDate = $billInfo->paymentTime;
			$write->save();
			self::recalculatePower($payment['date']);
		}
		else if($additional){
			$cottageId = $cottageInfo->masterId;
		}
		else{
			$cottageId = $cottageInfo->cottageNumber;
		}
		$paymentMonth = self::getPaymentMonth($cottageId, $payment['date'], $additional);
		$paymentMonth->payed = 'yes';
		$paymentMonth->save();
	}

	/**
	 * @param $cottageNumber int|string
	 * @param $period string
	 * @param bool $additional
	 * @return Table_additional_power_months|Table_power_months
	 */
	public static function getPaymentMonth($cottageNumber, $period, $additional = false){
		if($additional){
			$data = Table_additional_power_months::findOne(['cottageNumber' => $cottageNumber, 'month' => $period]);
		}
		else{
			$data = Table_power_months::findOne(['cottageNumber' => $cottageNumber, 'month' => $period]);
		}
		if($data !== null){
			return $data;
		}
		throw new InvalidArgumentException("Данные по участку $cottageNumber за $period не заполнены!");
	}
	public static function recalculatePower($period){
		$month = TimeHandler::isMonth($period);
		$cottagesCount = Table_cottages::find()->count();
		$additionalCottagesCount = Table_additional_cottages::find()->count();
		$tariff = Table_tariffs_power::findOne(['targetMonth' => $month['full']]);
		if(!empty($tariff)){
			$payedNow = 0;
			$payedCounter = 0;
			$additionalPayedCounter = 0;
			// получу оплаченные счета за этот месяц
			$payed = Table_payed_power::find()->where(['month' => $month['full']])->all();
			$additionalPayed = Table_additional_payed_power::find()->where(['month' => $month['full']])->all();
			if(!empty($payed)){
				foreach ($payed as $item) {
					$payedNow += $item->summ;
					$payedCounter++;
				}
			}
			if(!empty($additionalPayed)){
				foreach ($additionalPayed as $item) {
					$payedNow += $item->summ;
					$additionalPayedCounter++;
				}
			}
			$fill = 0;
			$additionalFill = 0;
			$usedEnergy = 0;
			$neededSumm = 0;
			// следующий этап- получу данные о потраченной за месяц энергии и количество участков, по которым заполнены данные
			$filled = Table_power_months::find()->where(['month' => $month['full']])->all();
			$additionalFilled = Table_additional_power_months::find()->where(['month' => $month['full']])->all();
			if(!empty($filled)){
				foreach ($filled as $item) {
					$fill++;
					$usedEnergy += $item->difference;
					$neededSumm += $item->totalPay;
				}
			}
			if(!empty($additionalFilled)){
				foreach ($additionalFilled as $item) {
					$additionalFill++;
					$usedEnergy += $item->difference;
					$neededSumm += $item->totalPay;
				}
			}
			$tariff->fullSumm = $neededSumm;
			$tariff->payedSumm = $payedNow;
			$tariff->paymentInfo = /** @lang xml */
				"<info><cottages_count>$cottagesCount</cottages_count><additional_cottages_count>$additionalCottagesCount</additional_cottages_count><pay>$payedCounter</pay><pay_additional>$additionalPayedCounter</pay_additional><fill>$fill</fill><fill_additional>$additionalFill</fill_additional><used_energy>$usedEnergy</used_energy></info>";
			/** @var Table_tariffs_power $tariff */
			$tariff->save();
		}
	}

	/**
	 * @param $period string|boolean
	 * @return Table_tariffs_power
	 * @throws InvalidArgumentException
	 * @throws InvalidValueException
	 */
	public static function getRowTariff($period = false): Table_tariffs_power
	{
		if(!empty($period)){
			$month = TimeHandler::isMonth($period);
			$data = Table_tariffs_power::findOne(['targetMonth' => $month['full']]);
			if(!empty($data)){
				return $data;
			}
			throw new InvalidArgumentException('Тарифа на данный месяц не существует!');
		}
		$data = Table_tariffs_power::find()->orderBy('searchTimestamp DESC')->one();
		if(!empty($data)){
			return $data;
		}
		throw new InvalidValueException('Тарифы  не обнаружены');
	}
}