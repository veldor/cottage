<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 26.09.2018
 * Time: 15:52
 */

namespace app\models;

use yii\base\Model;

class Filling extends Model{

    public static function getPaymentDetails($billInfo): string
    {
        $discountSumm = '';
        $fromDepositSumm = '';
        $summForPay = '';
        $toDeposit = '';
        $content = '<div>';
        if ($billInfo->isPayed == 1) {
            $content .= "<h3>Статус: <b class='text-success'>Оплачен</b></h3>";
            $payDate = TimeHandler::getDatetimeFromTimestamp($billInfo->paymentTime);
            $content .= "<p>Дата оплаты: <b class='text-success'>$payDate</b><br/>";
        } else {
            $content .= "<h3>Статус: <b class='text-danger'>Не оплачен</b></h3>";
        }
        $dom = new \DOMDocument('1.0', 'UTF-8');
        $dom->loadXML($billInfo->bill_content);
        $xpath = new \DOMXpath($dom);
        // $info = $xpath->query('//target[@year=' . $tariff->year . ']');
        $totalSumm = CashHandler::toRubles($dom->documentElement->getAttribute('summ'));
        $content .= "Общая сумма платежа: <b class='text-success'>{$totalSumm} &#8381;</b><br/>";
        if ($billInfo->discount > 0) {
            $summ = CashHandler::toRubles($billInfo->discount);
            $discountSumm = "Сумма скидки по платежу: <b class='text-success'>{$summ} &#8381;</b><br/>";
        }
        if ($billInfo->depositUsed > 0) {
            $summ = CashHandler::toRubles($billInfo->depositUsed);
            $fromDepositSumm = "Оплаты с депозита: <b class='text-success'>{$summ} &#8381;</b><br/>";
        }
        if ($billInfo->toDeposit > 0) {
            $summ = CashHandler::toRubles($billInfo->toDeposit);
            $toDepost = "Зачислено на депозит: <b class='text-success'>{$summ} &#8381;</b><br/>";
        }
        if ($billInfo->discount > 0 || $billInfo->depositUsed > 0 || $billInfo->toDeposit > 0) {
            $summ = CashHandler::toRubles($totalSumm - $billInfo->depositUsed - $billInfo->discount + $billInfo->toDeposit);
            $summForPay = "Итого к оплате: <b class='text-success'>{$summ} &#8381;</b><br/>";
        }
        $content .= "{$discountSumm}{$fromDepositSumm}{$toDepost}{$summForPay}";
        $content .= "<h2>Детали платежа:</h2>";
        $content .= "</div>";
        $powers = $xpath->query('//power/month');
        if ($powers->length > 0) {
            $cost = CashHandler::toRubles($powers->item(0)->parentNode->getAttribute('cost'));
            $content .= "<div style='background-color: azure;'><h3>Электроэнергия</h3>";
            $content .= "<p> Оплачено месяцев: <b class='text-success'>{$powers->length}</b><br/>";
            $content .= "<p> Общая сумма платежей за электроэнергию: <b class='text-success'>{$cost} &#8381;</b><br/>";
            $content .= "<ol>";
            /** @var \DOMElement $power */
            foreach ($powers as $power) {
                $date = TimeHandler::getFullFromShotMonth($power->getAttribute('date'));
                $monthSumm = CashHandler::toRubles($power->getAttribute('summ'));
                $start = $power->getAttribute('old-data');
                $end = $power->getAttribute('new-data');
                $diff = $power->getAttribute('difference');
                $content .= "<li><h4>{$date} года: оплачено за месяц <b class='text-success'>{$monthSumm} &#8381;</b></h4>";
                $content .= "Показания счётчика на начало месяца: <b class='text-info'>{$start} кВт.ч</b><br/>";
                $content .= "Показания счётчика на конец месяца:  <b class='text-info'>{$end} кВт.ч</b><br/>";
                $content .= "Израсходовано за месяц:  <b class='text-info'>{$diff} кВт.ч</b><br/>";
                $limit = $power->getAttribute('powerLimit');
                if ($limit > 0) {
                    $content .= "Лимит льготного потребления электроэнергии за месяц: <b class='text-info'>{$limit} кВт.ч</b><br/>";
                    $inLimit = $power->getAttribute('in-limit');
                    $content .= "Потрачено в пределах льготного лимита: <b class='text-info'>{$inLimit} кВт.ч</b><br/>";
                    $costForKw = $power->getAttribute('powerCost');
                    $inLimitSumm = $power->getAttribute('in-limit-cost');
                    $content .= "Стоимость 1 кВт.ч в пределах льготного лимита: <b class='text-success'>{$costForKw} &#8381;</b><br/>";
                    $content .= "Стоимость потраченной электроэнергии в пределах льготного лимита: {$inLimit} * {$costForKw} = <b class='text-success'>{$inLimitSumm} &#8381;</b><br/>";
                }
                $overLimit = $power->getAttribute('over-limit');
                if ($overLimit > 0) {
                    $content .= "Потрачено за пределами льготного лимита: <b class='text-info'>{$overLimit} кВт.ч</b><br/>";
                    $costForKw = $power->getAttribute('powerOvercost');
                    $overLimitSumm = $power->getAttribute('over-limit-cost');
                    $content .= "Стоимость 1 кВт.ч за пределами льготного лимита: <b class='text-success'>{$costForKw} &#8381;</b><br/>";
                    $content .= "Стоимость потраченной электроэнергии за пределами льготного лимита: {$overLimit} * {$costForKw} = <b class='text-success'>{$overLimitSumm} &#8381;</b><br/>";
                }
                $corrected = $power->getAttribute('corrected');
                if ($corrected == 1) {
                    $content .= "<b class='text-danger'>Льготный лимит не используется!</b><br/>";
                }
                $content .= "</li>";
            }
            $content .= "</ol></p></div>";
        }
        $mems = $xpath->query('//membership/quarter');
        if ($mems->length > 0) {
            $cost = $mems->item(0)->parentNode->getAttribute('cost');
            $content .= "<div style='background-color: gainsboro;'><h3>Членские взносы</h3>";
            $content .= "<p> Оплачено кварталов: <b class='text-success'>{$mems->length}</b><br/>";
            $content .= "<p> Общая сумма платежей за членские взносы: <b class='text-success'>{$cost} &#8381;</b><br/>";
            $content .= "<ol>";
            /** @var \DOMElement $mem */
            foreach ($mems as $mem) {
                $date = TimeHandler::getFullFromShortQuarter($mem->getAttribute('date'));
                $quarterSumm = CashHandler::toRubles($mem->getAttribute('summ'));
                $content .= "<li><h4>{$date}: к оплате за квартал <b class='text-success'>{$quarterSumm} &#8381;</b></h4>";
                $fixed = CashHandler::toRubles($mem->getAttribute('fixed'));
                if ($fixed > 0) {
                    $content .= "Фиксированный взнос за квартал: <b class='text-success'>{$fixed} &#8381;</b><br/>";
                }
                $float = CashHandler::toRubles($mem->getAttribute('float'));
                if ($float > 0) {
                    $forMeter = $float / 100;
                    $square = $mem->getAttribute('square');
                    $cost = CashHandler::toRubles($forMeter * $square);
                    $content .= "Стоимость взноса за квартал с 1 сотки : <b class='text-success'>{$float} &#8381;</b>, c 1 м<sup>2</sup>: <b class='text-success'>{$forMeter} &#8381;</b><br/>";
                    $content .= "Взнос за квартал: {$square} м<sup>2</sup> *  <b class='text-success'>{$forMeter} &#8381;</b> = <b class='text-success'>{$cost} &#8381;</b><br/>";
                }
                $content .= "</li>";
            }
            $content .= "</ol></p></div>";
        }
        $targets = $xpath->query('//target/pay');
        if ($targets->length > 0) {
            $cost = $targets->item(0)->parentNode->getAttribute('cost');
            $content .= "<div style='background-color: #edbfbf;'><h3>Целевые взносы</h3>";
            $content .= "<p> Оплачено лет: <b class='text-success'>{$targets->length}</b><br/>";
            $content .= "<p> Общая сумма платежей за целевые взносы: <b class='text-success'>{$cost} &#8381;</b><br/>";
            $content .= "<ol>";
            /** @var \DOMElement $target */
            foreach ($targets as $target) {
                $totalCost = 0;
                $date = $target->getAttribute('year');
                $yearSumm = CashHandler::toRubles($target->getAttribute('summ'));
                $content .= "<li><h4>{$date} год: оплачено <b class='text-success'>{$yearSumm} &#8381;</b></h4>";
                $fixed = cashHandler::toRubles($target->getAttribute('fixed-cost'));
                if ($fixed > 0) {
                    $content .= "Фиксированный взнос за год: <b class='text-success'>{$fixed} &#8381;</b><br/>";
                    $totalCost += $fixed;
                }
                $float = CashHandler::toRubles($target->getAttribute('float-cost'));
                if ($float > 0) {
                    $forMeter = CashHandler::toRubles($float / 100);
                    $square = $target->getAttribute('square');
                    $cost = CashHandler::toRubles($forMeter * $square);
                    $totalCost += $cost;
                    $content .= "Стоимость взноса за год с 1 сотки : <b class='text-success'>{$float} &#8381;</b>, c 1 м<sup>2</sup>: <b class='text-success'>{$forMeter} &#8381;</b><br/>";
                    $content .= "Взнос за год: {$square} м<sup>2</sup> *  <b class='text-success'>{$forMeter} &#8381;</b> = <b class='text-success'>{$cost} &#8381;</b><br/>";
                }
                $content .= "Общая стоимость платежа за год: <b class='text-success'>{$totalCost} &#8381;</b><br/>";
                $payedBefore = CashHandler::toRubles($target->getAttribute('payed-before'));
                if ($payedBefore > 0) {
                    $content .= "Оплачено ранее: <b class='text-success'>{$payedBefore} &#8381;</b><br/>";
                }
                $payedForNow = $yearSumm + $payedBefore;
                if ($payedForNow == $totalCost) {
                    $content .= "Статус: <b class='text-success'>год оплачен полностью.</b><br/>";
                } else {
                    $dif = CashHandler::toRubles($totalCost - $payedForNow);
                    $content .= "Статус: <b class='text-danger'>Осталось доплатить {$dif} &#8381;</b><br/>";
                }
                $content .= "</li>";
            }
            $content .= "</ol></p></div>";
        }
        $single = $xpath->query('//single/pay');
        if ($single->length > 0) {
            $cost = $single->item(0)->parentNode->getAttribute('cost');
            $content .= "<div style='background-color: #edbfbf;'><h3>Разовые взносы</h3>";
            $content .= "<p> Оплачено взносов: <b class='text-success'>{$single->length}</b><br/>";
            $content .= "<p> Общая сумма платежей за разовые взносы: <b class='text-success'>{$cost} &#8381;</b><br/>";
            $content .= "<ol>";
            /** @var \DOMElement $item */
            foreach ($single as $item) {
                $date = TimeHandler::getDatetimeFromTimestamp($item->getAttribute('timestamp'));
                $itemSumm = CashHandler::toRubles($item->getAttribute('summ'));
                $content .= "<li><h4>Дата выставления разового платежа: {$date}. Оплачено <b class='text-success'>{$itemSumm} &#8381;</b></h4>";
                $payedBefore = CashHandler::toRubles($item->getAttribute('payed-before'));
                if ($payedBefore > 0) {
                    $content .= "Оплачено ранее: <b class='text-success'>{$payedBefore} &#8381;</b><br/>";
                }
                $content .= "</li>";
            }
            $content .= "</ol></p></div>";
        }
        return $content;
    }

    public static function cancelPowerFill($cottageNumber, $additional = false)
    {
        // несколько проверок- нужно убедиться, что данные заполнены, ещё не оплачены и нет выставленных неоплаченных платежей по данному участку
        $result = Table_power_months::findOne(['cottageNumber' => $cottageNumber, 'month' => TimeHandler::getPreviousShortMonth(), 'payed' => 'no']);
        if (!empty($result) && Table_payment_bills::find()->where(['cottageNumber' => $cottageNumber, 'isPayed' => '0'])->count() == 0) {
            // убавлю долг по электричеству, выставленный по этому платежу
            $cottage = Table_cottages::findOne($cottageNumber);
            echo "$cottage->powerDebt $result->totalPay";
            die;
            $cottage->powerDebt = CashHandler::toRubles($cottage->powerDebt - $result->totalPay);
            $cottage->currentPowerData = $result->oldPowerData;
            $cottage->save();
            $result->delete();
            return ['status' => 1];
        }
        return ['status' => 0];
    }


    public static function getCottageDutyText($cottageInfo)
    {
        $content = "";
        $powerCost = 0;
        $membershipCost = 0;
        $targetCost = 0;
        $singleCost = 0;
        $totalCost = 0;
        // если оплата комплексная- найду данные о электроэнергии и членских взносах
        $lastPayedPower = $cottageInfo->powerPayFor;
        $point = TimeHandler::getMonthTimestamp($lastPayedPower);
        $data = Table_power_months::find()->where(['cottageNumber' => $cottageInfo->cottageNumber])->andWhere(['>', 'searchTimestamp', $point])->orderBy('month')->all();

        if (!empty($data)) {
            $tariffs = Table_tariffs_power::find()->where('targetMonth>=' . $data[0]->month)->orderBy('targetMonth')->all();
            $tariffsArray = [];
            if (!empty($tariffs)) {
                foreach ($tariffs as $tariff) {
                    $tariffsArray[$tariff->targetMonth] = ['powerLimit' => $tariff->powerLimit, 'powerCost' => $tariff->powerCost, 'powerOvercost' => $tariff->powerOvercost];
                }
            }
            $powerString = '';
            $monthQuantity = count($data);
            foreach ($data as $month) {
                // заполню ячейку
                if ($month->difference > 0) {
                    $cost = CashHandler::calculatePower($month->newPowerData, $month->oldPowerData, $tariffsArray[$month->month]['powerLimit'], $tariffsArray[$month->month]['powerCost'], $tariffsArray[$month->month]['powerOvercost']);
                    $date = TimeHandler::getFullFromShotMonth($month->month);
                    $powerCost += $cost;
                    $totalCost += $cost;
                    $difference = $month->newPowerData - $month->oldPowerData;
                    if ($difference > $tariffsArray[$month->month]['powerLimit']) {
                        $inLimit = $tariffsArray[$month->month]['powerLimit'];
                        $overLimit = $difference - $inLimit;
                        $overLimitSumm = $overLimit * $tariffsArray[$month->month]['powerOvercost'];
                    } else {
                        $inLimit = $difference;
                        $overLimit = 0;
                        $overLimitSumm = 0;
                    }
                    $inLimitSumm = $inLimit * $tariffsArray[$month->month]['powerCost'];
                    $powerString .= "<p>{$date} года: <b style='color: #d43f3a'>{$cost}</b> &#8381;<br/>Старые показания: <b style='color: #3e8f3e'>{$month->oldPowerData}</b> кВт/ч , новые показания: <b style='color: #3e8f3e'>{$month->newPowerData}</b> кВт/ч<br/>Израсходовано за месяц: <b style='color: #d43f3a'>{$difference}</b> кВт/ч<br/>Льготный лимит: <b style='color: #3e8f3e'>{$tariffsArray[$month->month]['powerLimit']}</b> кВт/ч<br/>Льготная цена: {$inLimit}  кВт/ч * {$tariffsArray[$month->month]['powerCost']} &#8381; за кВт/ч = <b style='color: #3e8f3e'>{$inLimitSumm}</b>  &#8381;<br/>Дополнительная цена: {$overLimit}  кВт/ч * {$tariffsArray[$month->month]['powerOvercost']} &#8381; за кВт/ч = <b style='color: #3e8f3e'>{$overLimitSumm}</b>  &#8381;<br/></p>";
                }
            }
            $powerString = "<div><h2>Электроэнергия:</h2><p>Неоплаченных месяцев: {$monthQuantity}<br/>Общая сумма задолженности за электроэнергию: <b style='color: #d43f3a'>{$powerCost}</b> &#8381;</p></div>" . $powerString;
            $content .= $powerString;
        }
        // верну все тарифы за кварталы начиная с оплаченного по данный квартал
        $lastPayedMembership = $cottageInfo->membershipPayFor;
        $startSearch = TimeHandler::getQuarterTimestamp($lastPayedMembership);
        $now = TimeHandler::getQuarterTimestamp(TimeHandler::getCurrentQuarter());
        $tariffs = Table_tariffs_membership::find()->where(['and', "search_timestamp>$startSearch", "search_timestamp<=$now"])->orderBy('quarter')->all();
        if (!empty($tariffs)) {
            $membershipString = '';
            $quarterQuantity = count($tariffs);
            foreach ($tariffs as $tariff) {
                $cost = $tariff->fixed_part + $tariff->changed_part / 100 * $cottageInfo->cottageSquare;
                $membershipCost += $cost;
                $totalCost += $cost;
                $date = TimeHandler::getFullFromShortQuarter($tariff->quarter);
                $membershipString .= "<p>{$date}: <b style='color: #d43f3a'>{$cost}</b> &#8381;<br/>Расчётная площадь участка: <b style='color: #3e8f3e'>{$cottageInfo->cottageSquare}</b> м<sup>2</sup><br/> Фиксированный взнос: <b style='color: #3e8f3e'>{$tariff->fixed_part}</b> &#8381;<br/>Взнос с сотки: <b style='color: #3e8f3e'>{$tariff->changed_part}</b> &#8381;<br/><br/></p>";
            }
            $membershipString = "<div><h2>Членские взносы:</h2><p>Неоплаченных кварталов: {$quarterQuantity}<br/>Общая сумма задолженности за членские взносы: <b style='color: #d43f3a'>{$membershipCost}</b> &#8381;</p></div>" . $membershipString;
            $content .= $membershipString;
        }
        // список неоплаченных целевых взносов
        if (!empty($cottageInfo->targetPaysDuty)) {
            // получу список из XML
            $dom = new \DOMDocument('1.0', 'UTF-8');
            $dom->loadXML($cottageInfo->targetPaysDuty);
            $debts = $dom->getElementsByTagName('target');
            if ($debts->length > 0) {
                $targetString = '';
                foreach ($debts as $debt) {
                    /** @var \DOMElement $debt */
                    $targetYear = $debt->getAttribute('year');
                    $payed = CashHandler::toRubles($debt->getAttribute('payed'));
                    $square = (int)$debt->getAttribute('square');
                    $fixed = CashHandler::toRubles($debt->getAttribute('fixed'));
                    $float = CashHandler::toRubles($debt->getAttribute('float'));
                    $description = urldecode($debt->getAttribute('description'));
                    $cost = $fixed + $float / 100 * $square - $payed;
                    $targetCost += $cost;
                    $totalCost += $cost;

                    $targetString .= "<p>{$targetYear} год: <b style='color: #d43f3a'>{$cost}</b> &#8381;<br/>Расчётная площадь участка: <b style='color: #3e8f3e'>{$square}</b> м<sup>2</sup><br/> Фиксированный взнос: <b style='color: #3e8f3e'>{$fixed}</b> &#8381;<br/>Взнос с сотки: <b style='color: #3e8f3e'>{$float}</b> &#8381;<br/>Оплачено ранее: <b style='color: #3e8f3e'>{$payed}</b> &#8381;<br/>Назначение платежа: {$description}<br/></p>";
                }

                $targetString = "<div><h2>Целевые взносы:</h2><p>Неоплаченных лет: {$debts->length}<br/>Общая сумма задолженности за целевые взносы: <b style='color: #d43f3a'>{$targetCost}</b> &#8381;</p></div>" . $targetString;
                $content .= $targetString;
            }
        }
        // список неоплаченных разовых взносов
        if (!empty($cottageInfo->singlePaysDuty)) {
            // получу список из XML
            $dom = new \DOMDocument('1.0', 'UTF-8');
            $dom->loadXML($cottageInfo->singlePaysDuty);
            $debts = $dom->getElementsByTagName('singlePayment');
            if ($debts->length > 0) {
                $singleString = '';
                foreach ($debts as $debt) {
                    /** @var \DOMElement $debt */
                    $payed = CashHandler::toRubles($debt->getAttribute('payed'));
                    $time = TimeHandler::getDatetimeFromTimestamp($debt->getAttribute('time'));
                    $summ = CashHandler::toRubles($debt->getAttribute('summ'));
                    $description = urldecode($debt->getAttribute('description'));
                    $cost = $summ - $payed;
                    $totalCost += $cost;
                    $singleCost += $cost;
                    $singleString .= "<p>{$time}: <b style='color: #d43f3a'>{$cost}</b> &#8381;<br/>Общая стоимость: <b style='color: #3e8f3e'>{$summ}</b> &#8381;<br/>Оплачено ранее: <b style='color: #3e8f3e'>{$payed}</b> &#8381;<br/>Назначение платежа: {$description}<br/></p>";
                }
                $singleString = "<div><h2>Разовые взносы:</h2><p>Неоплаченных взносов: {$debts->length}<br/>Общая сумма задолженности за разовые взносы: <b style='color: #d43f3a'>{$singleCost}</b> &#8381;</p></div>" . $singleString;
                $content .= $singleString;
            }
        }
        $content = "<h2>Общая сумма задолженности: <b style='color: #3e8f3e'>{$totalCost}</b> &#8381;</h2>" . $content;
        return $content;
    }


    public static function checkTariffsFilling(): bool
    {
        // проверю тарифы на членские взносы за данный квартал и электричество за данный месяц
	    return Table_tariffs_power::find()->where(['targetMonth' => TimeHandler::getPreviousShortMonth()])->count() && Table_tariffs_membership::find()->where(['quarter' => TimeHandler::getCurrentQuarter()])->count();
    }

	public static function getFillingInfo()
	{
		$cottages = Cottage::getRegistredList();
		$additionalCottages = AdditionalCottage::getRegistredList();
		$inserted = PowerHandler::getInserted($cottages, $additionalCottages, TimeHandler::getPreviousShortMonth());
		return $inserted;
	}
}