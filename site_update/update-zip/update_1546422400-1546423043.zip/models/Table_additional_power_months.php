<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 18.09.2018
 * Time: 23:04
 */

namespace app\models;

use yii\db\ActiveRecord;

class Table_additional_power_months extends ActiveRecord
{
    public static function tableName()
    {
        return 'additional_months_power';
    }
}