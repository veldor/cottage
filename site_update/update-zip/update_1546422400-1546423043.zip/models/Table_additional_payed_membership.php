<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 02.12.2018
 * Time: 12:55
 */

namespace app\models;


use yii\db\ActiveRecord;

class Table_additional_payed_membership extends ActiveRecord
{
    public static function tableName()
    {
        return 'additional_payed_membership';
    }
}