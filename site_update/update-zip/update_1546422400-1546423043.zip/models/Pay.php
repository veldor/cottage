<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 18.10.2018
 * Time: 18:17
 */

namespace app\models;

use yii\base\InvalidArgumentException;
use yii\base\Model;


class Pay extends Model {
	public $billIdentificator; // Идентификатор платежа
	public $rawSumm = 0; // фактическое количество наличных
	public $totalSumm; // Общая сумма оплаты
	public $fromDeposit = 0;
	public $toDeposit = 0; // Начисление средств на депозит
	public $realSumm; // Фактическая сумма поступившив в кассу средств
	public $changeToDeposit = 0; // зачислить сдачу на депозин
	public $change = 0;
	public $discount = 0;
	/**
	 * @var $billInfo Table_payment_bills
	 */
	protected $billInfo;

	const SCENARIO_CASH = 'cash';

	public function scenarios(): array
	{
		return [
			self::SCENARIO_CASH => ['billIdentificator', 'totalSumm', 'totalSumm', 'fromDeposit', 'toDeposit', 'realSumm', 'rawSumm', 'changeToDeposit', 'change'],
		];
	}

	public function attributeLabels(): array
	{
		return [
			'changeToDeposit' => 'Зачислить сдачу на депозит',
			'rawSumm' => 'Сумма наличных',
			'toDeposit' => 'Сумма, зачисляемая на депозит',
		];
	}

	/**
	 * @return array
	 */
	public function rules(): array
	{
		return [
			[['totalSumm', 'rawSumm', 'fromDeposit', 'toDeposit', 'realSumm', 'rawSumm', 'change', 'changeToDeposit'], 'checkCost'],
			[['billIdentificator', 'totalSumm', 'rawSumm', 'change'], 'required', 'on' => self::SCENARIO_CASH],
			[['toDeposit'], 'required', 'when' => function () {
				return $this->changeToDeposit;
			}, 'whenClient' => "function () {return $('input#pay-changetodeposit').prop('checked');}"],
			['changeToDeposit', 'in', 'range' => [1, 0]],
			['toDeposit', 'checkToDeposit'],
			['rawSumm', 'number', 'min' => $this->totalSumm - $this->fromDeposit - $this->discount],
		];
	}

	public function checkCost($attribute)
	{
		try {
			$this->$attribute = CashHandler::toRubles($this->$attribute);
		} catch (InvalidArgumentException $e) {
			$this->addError($attribute, $e->getMessage());
		}
	}

	public function checkToDeposit($attribute)
	{
		// сумма, зачисляемая на депозит не должна превышать сумму потенциальной сдачи
		$changeSumm = $this->rawSumm - $this->totalSumm;
		if ($this->$attribute > $changeSumm) {
			$this->addError($attribute, 'Сумма слишком велика');
		}
		if ($this->$attribute + $this->change !== $changeSumm) {
			$this->addError($attribute, 'Не сходится сумма сдачи и зачисления');
		}
	}

	public function fillInfo($identificator): bool
	{
		$this->billInfo = ComplexPayment::getBill($identificator);
		if ($this->billInfo->isPayed === 1) {
			throw new InvalidArgumentException('Счёт уже оплачен!');
		}
		$this->billIdentificator = $identificator;
		$this->totalSumm = $this->billInfo->totalSumm;
		$this->fromDeposit = $this->billInfo->depositUsed;
		$this->discount = $this->billInfo->discount;
		return true;
	}

	/**
	 * @return array
	 */
	public function confirm(): array
	{
		$this->billInfo->paymentTime = time();
		$this->billInfo->toDeposit = $this->toDeposit;
		$info = ComplexPayment::getBillInfo($this->billInfo);
		$cottageInfo = $info['cottageInfo'];
		$additionalCottageInfo = null;
		if($cottageInfo->haveAdditional){
			$additionalCottageInfo = AdditionalCottage::getCottage($cottageInfo->cottageNumber);
		}
		// теперь нужно отметить платёж как оплаченный, создать денежную транзакцию, сохранить её, сохранить в данных участка изменения связанные с оплатой
		// ищу информацию по каждому платежу
		// данные о оплате электроэнергии
		if (!empty($info['paymentContent']['power'])) {
			PowerHandler::registerPayment($cottageInfo, $this->billInfo, $info['paymentContent']['power']);
		}
		if (!empty($info['paymentContent']['additionalPower'])) {
			PowerHandler::registerPayment($additionalCottageInfo, $this->billInfo, $info['paymentContent']['additionalPower'], true);
		}
		if (!empty($info['paymentContent']['membership'])) {
			MembershipHandler::registerPayment($cottageInfo, $this->billInfo, $info['paymentContent']['membership']);
		}
		if (!empty($info['paymentContent']['additionalMembership'])) {
			MembershipHandler::registerPayment($additionalCottageInfo, $this->billInfo, $info['paymentContent']['additionalMembership'], true);
		}
		if (!empty($info['paymentContent']['target'])) {
			TargetHandler::registerPayment($cottageInfo, $this->billInfo, $info['paymentContent']['target']);
		}
		if (!empty($info['paymentContent']['additionalTarget'])) {
			TargetHandler::registerPayment($additionalCottageInfo, $this->billInfo, $info['paymentContent']['additionalTarget'], true);
		}
		if (!empty($info['paymentContent']['single'])) {
			SingleHandler::registerPayment($cottageInfo, $this->billInfo, $info['paymentContent']['single']);
		}

		if ($this->fromDeposit > 0) {
			DepositHandler::registerDeposit($this->billInfo, $info['cottageInfo'],'out');
		}
		if ($this->discount > 0) {
			DiscountHandler::registerDiscount($this->billInfo);
		}
		if ($this->changeToDeposit && $this->toDeposit > 0) {
			DepositHandler::registerDeposit($this->billInfo, $info['cottageInfo'],'in');
		}
		$payedSumm = $this->billInfo->totalSumm - $this->discount - $this->fromDeposit + $this->toDeposit;
		$this->billInfo->isPayed = 1;
		$this->billInfo->payedSumm = $payedSumm;
		$this->billInfo->save();
		$t = new Table_transactions();
		$t->cottageNumber = $info['cottageInfo']->cottageNumber;
		$t->billId = $this->billInfo->id;
		$t->transactionDate = $this->billInfo->paymentTime;
		$t->transactionType = 'cash';
		$t->transactionSumm = $payedSumm;
		$t->transactionWay = 'in';
		$t->transactionReason = 'Оплата услуг';
		$t->save();
		// обновлю информацию о балансе садоводства на этот месяц
		Balance::toBalance($t->transactionSumm, 'cash');
		// вроде как и всё, сохраняю
		/** @var Table_cottages $cottageInfo */
		$cottageInfo->save();
		if($additionalCottageInfo !== null){
			$additionalCottageInfo->save();
		}
		// отправлю письмо об успешно оплаченном счёт
//		if ($cottageInfo->cottageOwnerEmail || $cottageInfo->cottageContacterEmail) {
//			$dutyText = Filling::getCottageDutyText($cottageInfo);
//			$paymentDetails = Filling::getPaymentDetails($this->billInfo);
//			// заполню тело письма
//			$mailText = "<div style='text-align: center'><h1>Добрый день!</h1></div><div><h2>Счёт успешно оплачен.</h2>{$paymentDetails}</div>";
//			if ($this->changeToDeposit && $this->toDeposit > 0) {
//				$mailText .= "<div>На депозит участка начислено {$this->toDeposit} &#8381;</div>";
//			}
//			$mailText .= "<div style='text-align: center'>{$dutyText}<h3>Депозит участка</h3><p>Средств на депозите: <b style='color: #3e8f3e'>{$cottageInfo->deposit}</b> &#8381;<br/><b style='color: #3e8f3e'>Средства, находящиеся на депозите вы можете использовать для оплаты любых услуг садоводства.</b></p></div>";
//			$mailText .= "</div>";
//			//return Notifier::sendNotification($cottageInfo, 'Счёт оплачен.', $mailText);
//			return ['status' => 1];
//		}
		return ['status' => 1];
	}
}