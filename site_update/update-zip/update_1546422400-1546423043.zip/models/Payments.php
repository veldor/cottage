<?php

/** @var $this ->cottageInfo  \app\models\Table_cottages */

namespace app\models;

use yii\base\Model;

class Payments extends Model
{

    public $cottageNumber; // номер участка.

    public $membershipFixedPay; // Сумма фиксированного членского взноса
    public $membershipFloatPay; // Сумма членского взноса с сотки
    public $lastPowerDataRegistred; // Время выставления последней квитанции на оплату электричества

    public $unfilledQuarters; // Кварталы, по которым нет информации о тарифе
    public $membershipTariffs;
    public $paymentSumm;
    public $singlePaymentDescription;
    public $membershipAdditionalQuarters;

    protected $paymentTotal;

    public $previousPowerPays;


    public $cottageInfo;
    public $unpayed; // Тут будет массив неоплачнных счетов с действующими тарифами

    protected $tarrifsInfo;
    protected $unpayedPower;

    protected $power_attributes = ['currentPowerData', 'newPowerData', 'powerLimit', 'powerCost', 'powerOvercost', 'paymentTotal', 'paymentConfirm'];

    public function attributeLabels():array
    {
        return [
            'currentPowerData' => 'Предыдущие показания счётчика',
            'newPowerData' => 'Новые показания счётчика',
            'powerLimit' => 'Льготный порог',
            'powerCost' => 'Нормальный тариф',
            'powerOvercost' => 'Повышенный тариф',
            'cottageSquare' => 'Площадь участка',
            'paymentType' => 'Тип оплаты',
            'paymentConfirm' => 'Соcтояние оплаты',
            'partialPayment' => 'Частичная оплата',
            'lastPayedMembership' => 'Последний оплаченный квартал',
            'paymentSumm' => 'Сумма платежа',
            'singlePaymentDescription' => 'Описание платежа',
        ];
    }

    const SCENARIO_COMPLEX = 'complex';
    const SCENARIO_SINGLE = 'single';

    public function scenarios()
    {
        return [
            self::SCENARIO_SINGLE => ['cottageNumber', 'paymentSumm', 'singlePaymentDescription'],
        ];
    }

    /**
     * @return array
     * @var integer $this ->cottageInfo->currentPowerData
     * @var integer $this ->cottageInfo->cottageNumber
     * @property Table_cottages $this->cottageInfo
     */
    public function rules()
    {
        return [
            [['cottageNumber', 'paymentSumm', 'singlePaymentDescription'], 'required', 'on' => self::SCENARIO_SINGLE],
            [['paymentSumm'], 'match', 'pattern' => '/^\d+[,.]?\d{0,2}$/', 'message' => 'Это не в рублях.'],
            [['cottageNumber', 'powerPaymentPeriods'], 'integer', 'min' => 0],
            ['cottageNumber', 'checkCottageExistence'],
            ['newPowerData', 'integer', 'min' => $this->cottageInfo->currentPowerData, 'message' => 'Новые значения не могут быть меньше старых.'],
            ['powerLimit', 'number', 'min' => 0, 'message' => 'Лимит больше ноля!'],
            [['powerCost', 'powerOvercost'], 'number', 'min' => 0.01, 'message' => 'Это должно стоить хотя бы копейку!'],
            ['paymentType', 'in', 'range' => ['cash', 'no_cash']],
            ['paymentConfirm', 'in', 'range' => ['full_payed', 'partial_payed', 'no_payed']],
            ['lastPayedMembership', 'match', 'pattern' => '/^([1-4])\W*(\d{4})$/'],
            ['quarter', 'match', 'pattern' => '/^([1-4])\W*(\d{4})$/'],
        ];
    }


    public function checkCottageExistence($attribute)
    {
        if ($this->$attribute != $this->cottageInfo->cottageNumber)
            $this->addError($attribute, 'Не стоит менять номер участка, если не просили.');
    }

    /**
     * Payments constructor.
     * @param array $array
     */

    private function powerCostCalculate()
    {
        if (empty($this->newPowerData) || (empty($this->currentPowerData) && $this->currentPowerData != 0) || empty($this->powerLimit) || empty($this->powerCost) || empty($this->powerOvercost)) {
            return false;
        }
        $differense = $this->newPowerData - $this->currentPowerData;
        if ($this->powerLimit != 0) {
            if ($this->powerLimit > $differense) {
                $this->paymentTotal = round($differense * $this->powerCost, 2);
            } else {
                $std = $this->powerLimit * $this->powerCost;
                $over = ($differense - $this->powerLimit) * $this->powerOvercost;
                $this->paymentTotal = round($std + $over, 2);
            }
        } else
            $this->paymentTotal = round($differense * $this->powerOvercost, 2);
        return true;
    }

    /**
     * @return bool
     */
    public function save($type)
    {
        if ($type == 'single') {
            $description = urlencode($this->singlePaymentDescription);
            $time = time();
            // добавлю сведения о платеже в поле;
            if (!empty($this->cottageInfo->singlePaysDuty)) {
                // если уже есть платежи- добавлю ещё один
                $dom = new \DOMDocument('1.0', 'UTF-8');
                $dom->loadXML($this->cottageInfo->singlePaysDuty);
                $elem = $dom->createElement('singlePayment');
                $elem->setAttribute('time', $time);
                $elem->setAttribute('payed', 0);
                $elem->setAttribute('summ', $this->paymentSumm);
                $elem->setAttribute('description', $description);
                $dom->documentElement->appendChild($elem);
                $data = html_entity_decode($dom->saveXML($dom->documentElement));
                $this->cottageInfo->singlePaysDuty = $data;
            } else {
                // если платежей нет- создам
                $content = "<singlePayments><singlePayment time='{$time}' summ='{$this->paymentSumm}' description='{$description}'/></singlePayments>";
                $this->cottageInfo->singlePaysDuty = $content;
            }
            $this->cottageInfo->singleDebt += CashHandler::toRubles($this->paymentSumm);
            if($this->cottageInfo->save()){
                // если есть почтовый ящик- отправляю туда отчёт.
                if($this->cottageInfo->cottageOwnerEmail){
                    $dutyText = Filling::getCottageDutyText($this->cottageInfo);
                    $description = urldecode($description);
                    $mailText = "<div style='text-align: center'><h1>Добрый день!</h1></div><div><h2>Добавлен новый платёж за услуги садоводства</h2><p>Вид платежа: <b>Единоразовый платёж.</b><br/>Сумма платежа: <b style='color: #d43f3a'>{$this->paymentSumm}</b> &#8381;<br/>Назначение платежа:  {$description}<br/></p></div><div style='text-align: center'>{$dutyText}<h3>Депозит участка</h3><p>Средств на депозите: <b style='color: #3e8f3e'>{$this->cottageInfo->deposit}</b> &#8381;<br/><b style='color: #3e8f3e'>Средства, находящиеся на депозите вы можете использовать для оплаты любых услуг садоводства.</b></p></div>";
                    //Cloud::sendMessage($this->cottageInfo, 'Добавлен новый платёж.', $mailText);
                }
                return true;
            }
        }
        return false;
    }

    /**
     * @param $type
     * @param $cottageNumber
     * @return Payments_power[]|array|null|\yii\db\ActiveRecord[]
     * @var Table_cottages $info
     * @var integer $info ->id
     */
    public static function paymentsHistory($type, $cottageNumber)
    {
        // найду id участка
        $info = Table_cottages::find()->where(['cottageNumber' => $cottageNumber])->one();
        $data = null;
        if ($type === 'power') {
            $data = Payments_power::find()->where(['cottageNumber' => $info->cottageNumber])->all();
        }
        return $data;
    }

    public static function invoiceInfo($invoiceId)
    {
        $info = Table_payment_bills::findOne(['id' => $invoiceId]);
        $cottageInfo = Table_cottages::findOne(['cottageNumber' => $info->cottageNumber]);
        return ['invoiceInfo' => $info, 'cottageInfo' => $cottageInfo];
//        $info = Payments_power::find()->where($invoiceId)->one();
//        $transactions = false;
//        // если есть инвойс - работаю с ним, если нет- возвращаю false
//        if (!empty($info)) {
//            // Если инвойс не не оплачен- ищу транзакции по нему
//            if ($info->paymentConfirm != 'no_payed') {
//                $transactions = Transactions_::find()->where(['month' => $info->paymentMonth, 'cottageNumber' => $info->cottageNumber])->all();
//            }
//            return ['info' => $info, 'transactions' => $transactions];
//        } else return false;
    }

//    public function checkUnpayed()
//    {
//        $unpayed = [];
//        if ($this->scenario === 'powerPayment') {
//            // найду последний оплаченный месяц
//            $lastPayed = $this->cottageInfo->powerPayFor;
//            if (!empty($lastPayed)) {
//                // ищу все месяцы, начиная с оплаченного
//                $data = Table_power_months::find()->where(['cottageNumber' => $this->cottageNumber])->andWhere('searchTimestamp>' . TimeHandler::getMonthTimestamp($this->cottageInfo->powerPayFor))->orderBy('month')->all();
//            } else {
//                // пока нет информации о последнем оплаченном месяце- значит, считаем, что участок только что зарегистрирован
//                // Смотрю, есть ли показания счётчика участка за последний месяц
//                $data = Table_power_months::find()->where(['cottageNumber' => $this->cottageNumber])->orderBy('month')->all();
//            }
//            if (!empty($data)) {
//                $tariffs = Table_tariffs_power::find()->where('targetMonth>=' . $data[0]->month)->orderBy('targetMonth')->all();
//                if (!empty($tariffs)) {
//                    $tariffsArray = [];
//                    foreach ($tariffs as $tariff) {
//                        $tariffsArray[$tariff->targetMonth] = ['powerLimit' => $tariff->powerLimit, 'powerCost' => $tariff->powerCost, 'powerOvercost' => $tariff->powerOvercost];
//                    }
//                }
//                foreach ($data as $month) {
//                    // заполню ячейку
//                    $this->unpayed[$month->month] = ['oldData' => $month->oldPowerData, 'newData' => $month->newPowerData, 'powerLimit' => $tariffsArray[$month->month]['powerLimit'], 'powerCost' => $tariffsArray[$month->month]['powerCost'], 'powerOvercost' => $tariffsArray[$month->month]['powerOvercost']];
//                }
//                return true;
//            }
//        } elseif ($this->scenario === 'membershipPayment') {
//            // найду последний оплаченный квартал
//            $beginTimestamp = TimeHandler::getQuarterTimestamp($this->cottageInfo->membershipPayFor);
//            $endTimestamp = TimeHandler::getQuarterTimestamp(TimeHandler::getCurrentQuarter());
//            $tariffs = Table_tariffs_membership::find()
//                ->where(['and', "search_timestamp>$beginTimestamp", "search_timestamp<=$endTimestamp"])
//                ->all();
//            if (!empty($tariffs)) {
//                foreach ($tariffs as $tariff) {
//                    $this->unpayed[$tariff->quarter] = ['fixed' => $tariff->fixed_part, 'float' => $tariff->changed_part];
//                }
//                return true;
//            }
//        } elseif ($this->scenario === 'targetPayment') {
//            $tariffs = Target_tariffs::find()
//                ->where("year>" . $this->cottageInfo->targetPayFor)
//                ->all();
//            if (!empty($tariffs)) {
//                foreach ($tariffs as $tariff) {
//                    $this->unpayed[$tariff->year] = ['fixed' => $tariff->fixed_part, 'float' => $tariff->float_part];
//                }
//                return true;
//            }
//        } elseif ($this->scenario === 'single')
//            return true;
//        return false;
//    }

    public function loadInfo($cottageNumber)
    {
        if ($this->cottageInfo = Table_cottages::findOne((int)$cottageNumber)) {
            $this->cottageNumber = $this->cottageInfo->cottageNumber;
            $unpayed = ['power' => [], 'membership' => [], 'target' => [], 'single' => []];
            // если оплата комплексная- найду данные о электроэнергии и членских взносах
            if ($this->scenario == self::SCENARIO_COMPLEX) {
                $lastPayedPower = $this->cottageInfo->powerPayFor;
                if (!empty($lastPayedPower)) {
                    $point = TimeHandler::getMonthTimestamp($lastPayedPower);
                    $data = Table_power_months::find()->where(['cottageNumber' => $this->cottageInfo->cottageNumber])->andWhere(['>', 'searchTimestamp', $point])->orderBy('month')->all();
                } else {
                    // пока нет информации о последнем оплаченном месяце- значит, считаем, что участок только что зарегистрирован
                    // Ищу все показания счётчика, считаю их неоплаченными
                    $data = Table_power_months::find()->where(['cottageNumber' => $this->cottageInfo->cottageNumber])->orderBy('month')->all();
                }
                if (!empty($data)) {
                    $tariffs = Table_tariffs_power::find()->where('targetMonth>=' . $data[0]->month)->orderBy('targetMonth')->all();
                    if (!empty($tariffs)) {
                        $tariffsArray = [];
                        foreach ($tariffs as $tariff) {
                            $tariffsArray[$tariff->targetMonth] = ['powerLimit' => $tariff->powerLimit, 'powerCost' => $tariff->powerCost, 'powerOvercost' => $tariff->powerOvercost];
                        }
                    }
                    foreach ($data as $month) {
                        if($month->difference > 0){
                            $unpayed['power'][$month->month] = ['oldData' => $month->oldPowerData, 'newData' => $month->newPowerData, 'powerLimit' => $tariffsArray[$month->month]['powerLimit'], 'powerCost' => $tariffsArray[$month->month]['powerCost'], 'powerOvercost' => $tariffsArray[$month->month]['powerOvercost'], 'inLimitPay' => $month->inLimitPay, 'overLimitPay' => $month->overLimitPay];
                        }
                    }
                }
                // верну все тарифы за кварталы начиная с оплаченного по данный квартал
                $lastPayedMembership = $this->cottageInfo->membershipPayFor;
                if($this->cottageInfo->individualTariff){
                    $unpayed['membership'] = PersonalTariff::countMembershipDebt($this->cottageInfo)['unpayed'];
                }
                else{
                    $startSearch = TimeHandler::getQuarterTimestamp($lastPayedMembership);
                    $now = TimeHandler::getQuarterTimestamp(TimeHandler::getCurrentQuarter());
                    $tariffs = Table_tariffs_membership::find()->where(['and', "search_timestamp>$startSearch", "search_timestamp<=$now"])->orderBy('quarter')->all();
                    if (!empty($tariffs)) {
                        foreach ($tariffs as $tariff) {
                            $unpayed['membership'][$tariff->quarter] = ['fixed' => $tariff->fixed_part, 'float' => $tariff->changed_part, 'square' => $this->cottageInfo->cottageSquare];
                        }
                    }
                }
                // список неоплаченных целевых взносов
                if(!empty($this->cottageInfo->targetPaysDuty)){
                    // получу список из XML

                    $dom = new \DOMDocument('1.0', 'UTF-8');
                    $dom->loadXML($this->cottageInfo->targetPaysDuty);
                    $debts = $dom->getElementsByTagName('target');
                    if($debts->length > 0){
                        foreach ($debts as $debt){
                            /** @var \DOMElement $debt */
                            $targetYear = $debt->getAttribute('year');
                            $payed = CashHandler::toRubles($debt->getAttribute('payed'));
                            $square = $debt->getAttribute('square');
                            $fixed = CashHandler::toRubles($debt->getAttribute('fixed'));
                            $float = CashHandler::toRubles($debt->getAttribute('float'));
                            $summ = CashHandler::toRubles($debt->getAttribute('summ'));
                            $description = html_entity_decode($debt->getAttribute('description'));
                            $unpayed['target'][$targetYear] = ['fixed' => $fixed, 'float' => $float, 'square' => $square, 'payed' => $payed, 'summ' => $summ, 'description' => $description];
                        }
                    }
                }
                // список неоплаченных разовых взносов
                if(!empty($this->cottageInfo->singlePaysDuty)){
                    // получу список из XML
                    $dom = new \DOMDocument('1.0', 'UTF-8');
                    $dom->loadXML($this->cottageInfo->singlePaysDuty);
                    $debts = $dom->getElementsByTagName('singlePayment');
                    if($debts->length > 0){
                        foreach ($debts as $debt){
                            /** @var \DOMElement $debt */
                            $payed = CashHandler::toRubles($debt->getAttribute('payed'));
                            $time = $debt->getAttribute('time');
                            $summ = CashHandler::toRubles($debt->getAttribute('summ'));
                            $description = html_entity_decode($debt->getAttribute('description'));
                            $unpayed['single'][$time] = ['payed' => $payed, 'summ' => $summ, 'description' => $description];
                        }
                    }
                }
                $this->unpayed = $unpayed;
            }
            return true;
        }
        return false;
    }

    protected function getUnpayed($type)
    {
        $answer = [];
        if ($type == 'power') {
            // найду неоплаченные платежи
            // найду последний оплаченный месяц
            $lastPayed = $this->cottageInfo->powerPayFor;
            if (!empty($lastPayed)) {
                $data = Table_power_months::find()->where(['cottageNumber' => $this->cottageNumber, 'searchTimestamp>' => $lastPayed])->orderBy('month')->all();
            } else {
                // пока нет информации о последнем оплаченном месяце- значит, считаем, что участок только что зарегистрирован
                // Ищу все показания счётчика, считаю их неоплаченными
                $data = Table_power_months::find()->where(['cottageNumber' => $this->cottageNumber])->orderBy('month')->all();
            }
            if (!empty($data)) {
                $tariffs = Table_tariffs_power::find()->where('targetMonth>=' . $data[0]->month)->orderBy('targetMonth')->all();
                if (!empty($tariffs)) {
                    $tariffsArray = [];
                    foreach ($tariffs as $tariff) {
                        $tariffsArray[$tariff->targetMonth] = ['powerLimit' => $tariff->powerLimit, 'powerCost' => $tariff->powerCost, 'powerOvercost' => $tariff->powerOvercost];
                    }
                }
                foreach ($data as $month) {
                    // заполню ячейку
                    $answer[$month->month] = ['oldData' => $month->oldPowerData, 'newData' => $month->newPowerData, 'powerLimit' => $tariffsArray[$month->month]['powerLimit'], 'powerCost' => $tariffsArray[$month->month]['powerCost'], 'powerOvercost' => $tariffsArray[$month->month]['powerOvercost']];
                }
                return $answer;
            }
        } elseif ($type == 'target') {
            // найду неоплаченные платежи
            // найду последний оплаченный месяц
            $lastPayed = $this->cottageInfo->targetPayFor;
            $thisYear = TimeHandler::getThisYear();
            $tariffs = Target_tariffs::find()->where('year>' . $lastPayed)->orderBy('year')->all();
            if (!empty($tariffs)) {
                $tariffsArray = [];
                foreach ($tariffs as $tariff) {
                    $tariffsArray[$tariff->year] = ['fixed' => $tariff->fixed_part, 'float' => $tariff->float_part];
                }
            }
            $counter = $lastPayed + 1;
            while ($counter < $thisYear) {
                $answer[$counter] = ['fixed' => $tariffsArray[$counter]['fixed'], 'float' => $tariffsArray[$counter]['float']];
                ++$counter;
            }
            // заполняяю данные за этот год, если тариф уже создан
            if ($tariffsArray[$thisYear])
                $answer[$thisYear] = ['fixed' => $tariffsArray[$thisYear]['fixed'], 'float' => $tariffsArray[$thisYear]['float']];
            return $answer;
        } elseif ($type == 'membership') {
            // верну все тарифы за кварталы начиная с оплаченного, чтобы не заморачиваться с подсчётами
            $lastPayed = $this->cottageInfo->membershipPayFor;
            $startSearch = TimeHandler::getQuarterTimestamp($lastPayed);
            $tariffs = Table_tariffs_membership::find()->where('search_timestamp>' . $startSearch)->orderBy('quarter')->all();
            if (!empty($tariffs)) {
                foreach ($tariffs as $tariff) {
                    $answer[$tariff->quarter] = ['fixed' => $tariff->fixed_part, 'float' => $tariff->changed_part];
                }
            }
            return $answer;
        }
        return false;
    }
}