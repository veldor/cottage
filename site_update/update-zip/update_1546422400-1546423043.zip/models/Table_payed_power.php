<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 02.12.2018
 * Time: 12:53
 */

namespace app\models;

use yii\db\ActiveRecord;


class Table_payed_power extends ActiveRecord
{
    public static function tableName():string
    {
        return 'payed_power';
    }
}