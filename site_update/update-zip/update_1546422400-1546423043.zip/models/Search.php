<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 11.12.2018
 * Time: 12:48
 */

namespace app\models;


use yii\base\Model;

class Search extends Model
{
    public $startDate;
    public $finishDate;
    public $summary = false;

    const SCENARIO_BILLS_SEARCH = 'bills-search';

    public function scenarios():array
    {
        return [
            self::SCENARIO_BILLS_SEARCH => ['startDate', 'finishDate', 'summary'],
        ];
    }

    public function rules():array
    {
        return [
            [['startDate', 'finishDate', 'summary'], 'required'],
            [['startDate', 'finishDate'], 'date', 'format' => 'y-M-d'],
            [['summary'], 'boolean'],
        ];
    }

    public function attributeLabels():array
    {
        return [
            'startDate' => 'Начало периода',
            'finishDate' => 'Конец периода',
            'summary' => 'Сводный отчёт',
        ];
    }


    public function doSearch(): array
    {
        $start = new \DateTime('0:0:00'. $this->startDate);
        $finish = new \DateTime('23:59:50'. $this->finishDate);
        $interval = ['start' => $start->format('U'), 'finish' => $finish->format('U')];
        if($this->summary){
            return $this->getSummary($interval);
        }
            return $this->getTransactions($interval);
    }

    public function getTransactions($interval): array
    {
        $totalSumm = 0;
        $content = "<table class='table table-striped'><thead><th>Дата платежа</th><th>№</th><th>Сумма</th><th>Тип</th><th>Вид</th></thead><tbody>";
        $results = Table_transactions::find()->where(['>=', 'transactionDate', $interval['start']])->andWhere(['<=', 'transactionDate', $interval['finish']])->andWhere(['transactionType' => 'cash'])->all();
        if (!empty($results)) {
            foreach ($results as $result) {
                $totalSumm += $result->transactionSumm;
                $date = TimeHandler::getDateFromTimestamp($result->transactionDate);
                if ($result->transactionWay === 'in') {
	                $way = "<b class='text-success'>Поступление</b>";
                }
                else {
	                $way = "<b class='text-danger'>Списание</b>";
                }
                if ($result->transactionType === 'cash') {
	                $type = "<b class='text-success'>Наличные</b>";
                }
                else {
	                $type = "<b class='text-primary'>Безналичный расчёт</b>";
                }
                $content .= "<tr><td>$date</td><td><a href='#' class='bill-info' data-bill-id='{$result->billId}'>{$result->billId}</a></td><td><b class='text-info'>{$result->transactionSumm} &#8381;</b></td><td>$way</td><td>$type</td></tr>";
            }
            $content .= '</tbody></table>';
        } else {
            $content .= '</tbody></table>';
            $content .= '<h3>Транзакций за данный период не найдено</h3>';
        }
        return ['status' => 1, 'data' => $content, 'totalSumm' => $totalSumm];
    }

    public function getSummary($interval): array
    {
        $totalPowerSumm = 0;
        $totalMemSumm = 0;
        $totalTargetSumm = 0;
        $totalSingleSumm = 0;
        $content = "<table class='table table-striped'><thead><th>Электроэнергия</th><th>Членские</th><th>Целевые</th><th>Разовые</th></thead><tbody>";
        $powers = Table_payed_power::find()->where(['>=', 'paymentDate', $interval['start']])->andWhere(['<=', 'paymentDate', $interval['finish']])->all();
        if (!empty($powers)) {
            foreach ($powers as $power) {
                $totalPowerSumm += $power->summ;
            }
        }
        $mems = Table_payed_membership::find()->where(['>=', 'paymentDate', $interval['start']])->andWhere(['<=', 'paymentDate', $interval['finish']])->all();
        if (!empty($mems)) {
            foreach ($mems as $mem) {
                $totalMemSumm += $mem->summ;
            }
        }
        $targets = Table_payed_target::find()->where(['>=', 'paymentDate', $interval['start']])->andWhere(['<=', 'paymentDate', $interval['finish']])->all();
        if (!empty($targets)) {
            foreach ($targets as $target) {
                $totalTargetSumm += $target->summ;
            }
        }
        $singls = Table_payed_single::find()->where(['>=', 'paymentDate', $interval['start']])->andWhere(['<=', 'paymentDate', $interval['finish']])->all();
        if (!empty($singls)) {
            foreach ($singls as $single) {
                $totalSingleSumm += $single->summ;
            }
        }
        $content .= "<tr><td>$totalPowerSumm</td><td>$totalMemSumm</td><td>$totalTargetSumm</td><td>$totalSingleSumm</td></tr></tbody></table>";
        return ['status' => 1, 'data' => $content];
    }
}