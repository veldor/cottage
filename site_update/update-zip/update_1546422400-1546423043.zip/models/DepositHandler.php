<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 17.12.2018
 * Time: 22:14
 */

namespace app\models;


use yii\base\Model;

class DepositHandler extends Model {
	/**
	 * @param $billInfo Table_payment_bills
	 * @param $cottageInfo Table_cottages
	 * @param $way 'in'|'out'
	 */
	public static function registerDeposit($billInfo, $cottageInfo, $way){
		$depositIo = new Deposit_io();
		$depositIo->cottageNumber = $billInfo->cottageNumber;
		$depositIo->billId = $billInfo->id;
		$depositIo->destination = '$way';
		$depositIo->summBefore = $cottageInfo->deposit;
		if($way === 'out'){
			$depositIo->summ = $billInfo->depositUsed;
			$depositIo->summAfter = $cottageInfo->deposit -= $billInfo->depositUsed;
		}
		else{
			$depositIo->summ = $billInfo->toDeposit;
			$depositIo->summAfter = $cottageInfo->deposit += $billInfo->toDeposit;
		}
		$depositIo->actionDate = $billInfo->paymentTime;
		$depositIo->save();
	}
}