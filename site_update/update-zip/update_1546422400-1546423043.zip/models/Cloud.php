<?php

namespace app\models;

use http\Exception;
use Swift_TransportException;
use Yandex\Disk\DiskClient;
use Yii;
use yii\base\Model;

class Cloud extends Model
{
    private $token;
    private $drive;
    public $updates;

    public function __construct(array $config = [])
    {
        parent::__construct($config);
        $this->drive = new DiskClient($_SESSION['ya_auth']['access_token']);
        $this->drive->setServiceScheme(DiskClient::HTTPS_SCHEME);
    }

    public function uploadFile($filename, $source)
    {
        if (is_file($source)) {
            $this->drive->uploadFile(
                '/Updates/',
                array(
                    'path' => $source,
                    'size' => filesize($source),
                    'name' => $filename
                )
            );
            return true;
        }
        return false;
    }

    public function checkUpdates()
    {
        // проверю подключение к интернету
        try {
            $url = 'https://ya.ru/';
            ini_set('default_socket_timeout', '2');
            $fp = fopen($url, "r");
            $res = fread($fp, 5);
            fclose($fp);
        } catch (\Exception $e) {
            return ['status' => 2];
        }
        try {
            // Получаем список файлов из директории
            $dirContent = $this->drive->directoryContents('/Updates');
            foreach ($dirContent as $dirItem) {
                if ($dirItem['resourceType'] === 'file') {
                    $name = $dirItem['displayName'];
                    if (preg_match('/^update\_[0-9]{1,11}\-[0-9]{1,11}\.info?/', $name)) {
                        $this->updates[] = $name;
                    }
                }
            }
            return ($this->updates);
        } catch (Exception $e) {
            die('connectionError');
        }
        return fasle;
    }

    public function getUpdates()
    {
        // Получаем список файлов из директории
        $dirContent = $this->drive->directoryContents('/Updates');
        foreach ($dirContent as $dirItem) {
            if ($dirItem['resourceType'] === 'file') {
                $name = $dirItem['displayName'];
                if (preg_match('/^update\_[0-9]{1,11}\-[0-9]{1,11}\.zip?/', $name)) {
                    $this->updates[] = $name;
                }
            }
        }
        return ($this->updates);
    }

    public function downloadFile($path, $destination, $name)
    {
        if ($this->drive->downloadFile($path, $destination, $name)) {
            return true;
        } else
            return false;
    }

    public static function sendInvoice($info): int
    {
        $address = $info['cottageInfo']->cottageOwnerEmail;
        if (empty($address)) {
            return 2;
        }
        $name = $info['cottageInfo']->cottageOwnerPersonals;
        $mailbody = '<h3>' . $name . ', привет!</h3>
                            <p>Это письмо отправлено автоматически. Отвечать на него не нужно.</p>
                            <p>Вам выставлен счет на оплату услуг садоводства.</p>
                            ';
        if (Yii::$app->mailer->compose()
            ->setFrom(['oblepiha.snt@yandex.ru' => "Садоводство Облепиха"])
            ->setTo([$address => $name])
            ->setSubject('Счет на оплату')
            ->attach('Z:\sites\cottage\mail\files\1.pdf', ['fileName' => "Квитанция.pdf"])
            ->setHtmlBody($mailbody)
            ->send()
        ) {
            return 1;
        }
        return 0;
    }

    public static function sendMessage($info, $subject, $body)
    {
        $text = "<body><table border='0' cellpadding='0' cellspacing='0' style='max-width: 600px; width: 100%; margin:0; padding: 0'><tbody><tr><td>";
        $text .= $body;
        $text .= "</td></tr><tr><td><div style='text-align: center;'><h2>Контактная информация</h2><p>Телефон председателя: <a href='tel:+79049280858'><b>+7 904 928-08-58</b></a><br/>Телефон бухгалтера: <a href='tel:+79108730302'><b>+7 910 873-03-02</b></a><br/>Официальная группа ВКонтакте: <a target='_blank' href='https://vk.com/club173020344'>Посетить</a><br/></p></div></td></tr></tbody></table></body>";
        $results = [];
        $mail = Yii::$app->mailer->compose()
            ->setFrom(['oblepiha.snt@yandex.ru' => "Садоводство Облепиха"])
            ->setSubject($subject)
            ->setHtmlBody($text);
        $sendTo = [];
        if (!empty($info->cottageOwnerEmail)) {
            $name = explode(' ', $info->cottageOwnerPersonals);
            if (count($name) == 3)
                $username = "$name[1] $name[2]";
            else
                $username = $info->cottageOwnerPersonals;
            $address = $info->cottageOwnerEmail;
            $sendTo[] = [$address, $username];
            $results['to-owner'] = true;
        }
        if (!empty($info->cottageContacterEmail)) {
            $name = explode(' ', $info->cottageContacterPersonals);
            if (count($name) == 3)
                $username = "$name[1] $name[2]";
            else
                $username = $info->cottageContacterPersonals;
            $address = $info->cottageContacterEmail;
            $sendTo[] = [$address, $username];
            $results['to-contacter'] = true;
        }
        foreach ($sendTo as $value) {
            $mail->setTo([$value[0] => $value[1]]);
            // проверю подключение к интернету
            try {
                $url = 'https://ya.ru/';
                ini_set('default_socket_timeout', '2');
                $fp = fopen($url, "r");
                $res = fread($fp, 5);
                fclose($fp);
            } catch (\Exception $e) {
                return ['status' => 2];
            }
            try {
                $mail->send();
            } catch (\Exception $e) {
                return ['status' => 2];
            }
        }
        return ['status' => 1, 'results' => $results];
    }

    public static function messageToUnsended($cottageId, $subject, $body)
    {
        $msg = new Table_unsended_messages();
        $msg->cottageNumber = $cottageId;
        $msg->subject = $subject;
        $msg->body = $body;
        $msg->save();
    }
}