<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 22.11.2018
 * Time: 19:26
 */

namespace app\models;

use yii\base\Model;

class GrammarHandler extends Model
{
    public static function clearWhitespaces($string){
        // заменю встречающиеся несколько пробелов подряд на один и обрежу пробелы в начале и конце
        $regexp = '/ {2,}/';
        $string = preg_replace($regexp, ' ', $string);
        return trim($string);
    }
    public static function clearAddress($string){
        // заменю встречающиеся разделители- знаки амперсанда
        $regexp = '/&/';
        return trim(preg_replace($regexp, '', $string));
    }
    public static function personalsToArray($string){
        // извлекаю имя и отчество из персональных данных
        $result = explode(' ', $string);
        if(count($result) === 3){
            return ['lname' => $result[0], 'name' => $result[1], 'fname' => $result[2]];
        }
        return false;
    }
    public static function handleMonthsDifference($difference){
        if($difference === 1){
            return 'месяц';
        }
        $param = (string) $difference;
        $last = substr($param, strlen($param) - 1);
        $prelast = $param[strlen($param) - 2];
        if($prelast === '1'){
            return "$difference месяцев";
        }
        switch ($last){
            case '1' : return "$difference месяц";
            case '2' :
            case '3' :
            case '4' : return "$difference месяца";
            case '5' :
            case '6' :
            case '7' :
            case '8' :
            case '9' :
            case '0' : return "$difference месяцев";
        }
        return false;
    }
}