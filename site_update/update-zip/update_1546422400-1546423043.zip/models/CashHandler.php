<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 23.10.2018
 * Time: 18:11
 */

namespace app\models;

use yii\base\InvalidArgumentException;
use yii\base\Model;


class CashHandler extends Model
{
    /**
     * @param $summ
     * @param bool $isNegative
     * @throws InvalidArgumentException
     * @return float
     */
    public static function toRubles($summ, $isNegative = false){
        if($isNegative){
            $re = '/^\s*(-?\d+)[,.]?(\d*)?\s*$/';
        }
        else{
            $re = '/^\s*(\d+)[,.]?(\d*)?\s*$/';
        }
        $match = null;
        if(preg_match($re, $summ, $match)){
            return round((float) "$match[1].$match[2]", 2);
        }
        throw new InvalidArgumentException($summ . ' - Данное значение не является верным числом');
    }
    public static function calculatePower($newData, $oldData, $limit, $cost, $overcost){
        $newData = (int) $newData;
        $oldData = (int) $oldData;
        $limit = (int) $limit;
        $cost = (float) $cost;
        $overcost = (float) $overcost;
        $difference = $newData - $oldData;
        if($difference == 0)
            return 0;
        if ($limit != 0) {
            if ($limit > $difference) {
                $paymentTotal = round($difference * $cost, 2);
            } else {
                $std = $limit * $cost;
                $over = ($difference - $limit) * $overcost;
                $paymentTotal = round($std + $over, 2);
            }
        } else
            $paymentTotal = round($difference * $overcost, 2);
        return $paymentTotal;
    }

    public static function calculateMembership($square, $fixed, $float)
    {
        $square = (int) $square;
        $fixed = (float) $fixed;
        $float = (float) $float;
        return self::toRubles($fixed + $float / 100 * $square);
    }
}