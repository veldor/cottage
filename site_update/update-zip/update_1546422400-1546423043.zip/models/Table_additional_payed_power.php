<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 02.12.2018
 * Time: 12:53
 */

namespace app\models;

use yii\db\ActiveRecord;


class Table_additional_payed_power extends ActiveRecord
{
    public static function tableName():string
    {
        return 'additional_payed_power';
    }
}