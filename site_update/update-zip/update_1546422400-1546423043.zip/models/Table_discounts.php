<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 06.11.2018
 * Time: 12:45
 */

namespace app\models;

use yii\db\ActiveRecord;


class Table_discounts extends ActiveRecord
{
	public static function tableName():string
	{
		return 'payed_power';
	}
}