<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 05.12.2018
 * Time: 12:23
 */

namespace app\models;


use yii\base\Model;

class Fix extends Model
{

    public static function refreshPower(): array
    {
        // получу список всех участков
        $cottages = Table_cottages::find()->select(['cottageNumber', 'currentPowerData'])->all();
        if(!empty($cottages)){
            foreach ($cottages as $cottage){
                // найду последнюю запись о электроэнергии, запишу показания в карточку участка
                $data = Table_power_months::find()->where(['cottageNumber' => $cottage->cottageNumber])->orderBy('searchTimestamp DESC')->select('newPowerData')->one();
                $cottage->currentPowerData = $data->newPowerData;
                $cottage->save();
            }
        }
        return ['status' => 1];
    }

	/**
	 *
	 */
	public static function bills(): array
	{
		$bills = Table_payment_bills::find()->all();
		foreach ($bills as $bill){
			$dom = DOMHandler::getDom($bill->bill_content);
			$xpath = DOMHandler::getXpath($dom);
			$powers = $xpath->query('/payment/power/month');
			if($powers->length > 0){
				foreach ($powers as $power){
					/** @var \DOMElement $power */
					if(!$power->hasAttribute('corrected')){
						$power->setAttribute('corrected', 0);
					}
				}
			}
			$membership = $xpath->query('/payment/membership/quarter');
			if($membership->length > 0){
				foreach ($membership as $item){
					/** @var \DOMElement $item */
					if(!$item->hasAttribute('float-cost')){
						$float = CashHandler::toRubles($item->getAttribute('float'));
						$square = $item->getAttribute('square');
						$item->setAttribute('float-cost', CashHandler::toRubles($float / 100 * $square));
					}
				}
			}
			$targets = $xpath->query('/payment/target/pay');
			if($targets->length > 0){
				foreach ($targets as $item){
					/** @var \DOMElement $item */
					if(!$item->hasAttribute('total-summ')){
						$float = CashHandler::toRubles($item->getAttribute('float-cost'));
						$fixed = CashHandler::toRubles($item->getAttribute('fixed-cost'));
						$square = $item->getAttribute('square');
						$payedBefore = CashHandler::toRubles($item->getAttribute('payed-before'));
						$summ = CashHandler::toRubles($item->getAttribute('summ'));
						$totalSumm = Calculator::countFixedFloatPlus($fixed, $float, $square);
						$item->removeAttribute('fixed-cost');
						$item->setAttribute('float-cost', $totalSumm['float']);
						$item->setAttribute('float', $float);
						$item->setAttribute('fixed', $fixed);
						$item->setAttribute('total-summ', $totalSumm['total']);
						$item->setAttribute('left-pay', $totalSumm['total'] - $payedBefore - $summ);
					}
				}
			}
			$text = DOMHandler::saveXML($dom);
			$bill->bill_content = $text;
			$bill->save();
		}
		return ['status' => 1];
	}

	public static function recalculateAllPower(): array
	{
		$months = Table_tariffs_power::find()->all();
		if(!empty($months)){
			foreach ($months as $month) {
				PowerHandler::recalculatePower($month->targetMonth);
			}
		}
		return ['status' => 1];
	}
	public static function recalculateAllTargets(): array
	{
		$years = Table_tariffs_target::find()->all();
		if(!empty($years)){
			foreach ($years as $year) {
				TargetHandler::recalculateTarget($year->year);
			}
		}
		return ['status' => 1];
	}

	public static function recalculateAllMemberships(): array
	{
		$quarters = Table_tariffs_membership::find()->all();
		if(!empty($quarters)){
			foreach ($quarters as $quarter) {
				MembershipHandler::recalculateMembership($quarter->quarter);
			}
		}
		return ['status' => 1];
	}
}