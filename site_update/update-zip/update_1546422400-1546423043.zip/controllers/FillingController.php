<?php

namespace app\controllers;

use app\models\Filling;
use app\models\MembershipHandler;
use app\models\PersonalTariff;
use app\models\PowerHandler;
use app\models\Table_cottages;
use app\models\TimeHandler;
use Yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use yii\web\NotFoundHttpException;
use yii\web\Response;

class FillingController extends Controller
{
    /**
     * {@inheritdoc}
     */
    public function behaviors() :array
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'denyCallback' => function ($rule, $action) {
                    //return $this->redirect('/login', 301);
                },
                'rules' => [
                    [
                        'allow' => true,
                        'actions' => ['power', 'fill', 'create', 'future-quarters', 'cancel-power'],
                        'roles' => ['writer'],
                    ],
                ],
            ],
        ];
    }

    public function actionPower()
    {
        if (!$model = Filling::getFillingInfo())
            return $this->redirect('/tariffs/index', 301);
        return $this->render('power', ['info' => $model]);
    }

    public function actionCancelPower($cottageNumber, $additional = false)
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isPost) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return PowerHandler::cancelPowerFill($cottageNumber, $additional);
        } else
            throw new NotFoundHttpException('Страница не найдена');
    }

    /**
     * @param $type string
     * @param $cottageNumber int|string
     * @return array
     * @throws NotFoundHttpException
     * @throws \yii\base\ErrorException
     */
    public function actionFill($type, $cottageNumber): array
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isPost) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $model = new PowerHandler(['scenario' => PowerHandler::SCENARIO_NEW_RECORD]);
            $model->load(Yii::$app->request->post());
            if ($model->validate()){
                return $model->insert();
            }
            return ['status' => 0,
                'errors' => $model->errors,
            ];
        }
        throw new NotFoundHttpException("Страница не найдена");
    }

    public function actionFutureQuarters($quartersNumber, $cottageNumber, $additional = false)
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isGet) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            return MembershipHandler::getFutureQuarters($quartersNumber, $cottageNumber, $additional);
            }
        throw new NotFoundHttpException("Страница не найдена");
    }
}
