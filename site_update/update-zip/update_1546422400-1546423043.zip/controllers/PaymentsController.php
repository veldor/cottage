<?php
/**
 * Created by PhpStorm.
 * User: eldor
 * Date: 18.09.2018
 * Time: 16:35
 */

namespace app\controllers;

use app\models\Cloud;
use app\models\ComplexPayment;
use app\models\Pay;
use app\models\Payments;
use app\models\SingleHandler;
use Yii;
use yii\web\Controller;
use yii\filters\AccessControl;
use yii\web\NotFoundHttpException;
use yii\web\Response;
use yii\widgets\ActiveForm;

class PaymentsController extends Controller
{
    public function behaviors(): array
    {
        return [
            'access' => [
                'class' => AccessControl::class,
                'denyCallback' => function () {
                    return $this->redirect('/login', 301);
                },
                'rules' => [
                    [
                        'allow' => true,
                        'actions' => ['index', 'form', 'save', 'history', 'invoice-show', 'show-previous', 'validate-payment', 'create-complex', 'bill-info', 'print-invoice', 'send-invoice', 'use-deposit', 'no-use-deposit', 'save-bill', 'get-bills', 'get-pay-confirm-form', 'validate-cash', 'validate-single', 'confirm-cash', 'delete-bill'],
                        'roles' => ['writer'],
                    ],
                ],
            ],
        ];
    }

    public function actionForm($type, $cottageNumber): array
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isGet) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $form = null;
            if ($type === 'single') {
                $form = new SingleHandler(['scenario' => SingleHandler::SCENARIO_NEW_DUTY, 'cottageNumber' => $cottageNumber]);
            } else if ($type === 'complex') {
                if (ComplexPayment::checkUnpayed($cottageNumber)) {
                    throw new \ErrorException('Имеется неоплаченный счёт. Создание нового невозможно до его оплаты');
                }
                $form = new ComplexPayment(['scenario' => ComplexPayment::SCENARIO_CREATE]);
                $form->loadInfo($cottageNumber);
            }
            $view = $this->renderAjax($type . 'Form', ['matrix' => $form]);
            return ['status' => 1,
                'data' => $view,
            ];
        }
        throw new NotFoundHttpException('Страница не найдена');
    }

    public function actionSave($type): array
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isPost) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            if ($type === 'single') {
                $form = new SingleHandler(['scenario' => SingleHandler::SCENARIO_NEW_DUTY]);
                $form->load(Yii::$app->request->post());
                if ($form->validate()) {
                    return $form->insert();
                }
                return ['status' => 0,
                    'errors' => $form->errors
                ];
            }
            if ($type === 'complex') {
                $form = new ComplexPayment(['scenario' => ComplexPayment::SCENARIO_CREATE]);
                $form->load(Yii::$app->request->post());
                if ($form->validate()) {
                    return $form->save();
                }
                return ['status' => 0,
                    'errors' => $form->errors
                ];
            }
        }
        throw new NotFoundHttpException('Страница не найдена');
    }

    public function actionHistory($type, $cottageNumber): array
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isGet) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $data = Payments::paymentsHistory($type, $cottageNumber);
            return ['data' => $data];
        }
        throw new NotFoundHttpException('Страница не найдена');
    }

    public function actionInvoiceShow($invoiceId): array
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isGet) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            if ($data = Payments::invoiceInfo($invoiceId)) {
                $view = $this->renderAjax('powerInvoice', ['info' => $data]);
                return ['status' => 1,
                    'data' => $view,
                ];
            }
        }
        throw new NotFoundHttpException('Страница не найдена');
    }

    public function actionValidatePayment($type, $cottageNumber)
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isPost) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $form = new Payments(['scenario' => $type]);
            $form->loadInfo($cottageNumber);
            $form->load(Yii::$app->request->post());
            return ActiveForm::validate($form);
    }
        return false;
    }

    public function actionValidateSingle()
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isPost) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $form = new SingleHandler(['scenario' => SingleHandler::SCENARIO_NEW_DUTY]);
            $form->load(Yii::$app->request->post());
            return ActiveForm::validate($form);
        }
        return false;
    }

    public function actionBillInfo($identificator): array
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isGet) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $info = ComplexPayment::getBillInfo($identificator);
            if ($info) {
                $view = $this->renderAjax('billView', ['info' => $info]);
                return ['status' => 1, 'view' => $view];
            }
            return ['status' => 2, 'errors' => 'Счёт не найден'];
        }
        throw new NotFoundHttpException('Страница не найдена');
    }

    public function actionPrintInvoice($identificator): string
    {
        return $this->renderPartial('invoice');
    }

    public function actionSendInvoice($identificator)
    {
        if (Yii::$app->request->isPost) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $info = Payments::invoiceInfo($identificator);
            return ['status' => Cloud::sendInvoice($info)];
        }
        return false;
    }

    public function actionGetBills($cottageNumber): array
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isGet) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            if ($data = ComplexPayment::getBills($cottageNumber)) {
                return ['status' => 1, 'data' => $data];
            }
            return ['status' => 2];
        }
        throw new NotFoundHttpException('Страница не найдена');
    }

    public function actionGetPayConfirmForm($identificator): array
    {

        if (Yii::$app->request->isAjax && Yii::$app->request->isGet) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $model = new Pay(['scenario' => Pay::SCENARIO_CASH]);
            if ($model->fillInfo($identificator)) {
                $view = $this->renderAjax('cashConfirmForm', ['model' => $model]);
                return ['status' => 1, 'view' => $view];
            }
            return ['status' => 2, 'errors' => $model->errors];
        }
        throw new NotFoundHttpException('Страница не найдена');
    }

    public function actionValidateCash($identificator): array
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isPost) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $model = new Pay(['scenario' => Pay::SCENARIO_CASH]);
            if ($model->fillInfo($identificator) && $model->load(Yii::$app->request->post())) {
                return ActiveForm::validate($model);
            }
        }
        throw new NotFoundHttpException('Страница не найдена');
    }

    public function actionConfirmCash($identificator): array
    {
        if (Yii::$app->request->isAjax && Yii::$app->request->isPost) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $model = new Pay(['scenario' => Pay::SCENARIO_CASH]);
            $model->fillInfo($identificator);
            $model->load(Yii::$app->request->post());
            if ($model->confirm()) {
                $session = Yii::$app->session;
                $session->addFlash('success', 'Счёт успешно оплачен.');
                return ['status' => 1];
            }
        }
        throw new NotFoundHttpException('Страница не найдена');
    }

    public function actionDeleteBill($identificator): array
    {

        if (Yii::$app->request->isAjax && Yii::$app->request->isPost) {
            Yii::$app->response->format = Response::FORMAT_JSON;
            $session = Yii::$app->session;
            if (ComplexPayment::deleteBill($identificator)) {
                $session->addFlash('success', 'Счёт успешно удалён.');
                return ['status' => 1
                ];
            }
            $session->addFlash('danger', 'Ошибка при удалении счёта.');
            return ['status' => 2
            ];
        }
        throw new NotFoundHttpException('Страница не найдена');
    }
}